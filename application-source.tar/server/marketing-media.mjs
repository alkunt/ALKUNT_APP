import {randomUUID,randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {sql,BUCKET} from './runtime.mjs';
import {MarketingError,requireOwner} from './marketing.mjs';
const digest=token=>createHash('sha256').update(String(token)).digest('hex');
const fail=(message,status=400)=>{throw new MarketingError(message,status)};
export function detectMarketingMedia(bytes){
 const b=new Uint8Array(bytes),s=String.fromCharCode(...b.slice(0,16));
 if(b[0]===137&&s.slice(1,4)==='PNG'&&b[4]===13&&b[5]===10&&b[6]===26&&b[7]===10)return 'image/png';
 if(b[0]===255&&b[1]===216&&b[2]===255)return 'image/jpeg';
 if(s.startsWith('GIF87a')||s.startsWith('GIF89a'))return 'image/gif';
 if(s.startsWith('RIFF')&&s.slice(8,12)==='WEBP')return 'image/webp';
 if(s.slice(4,8)==='ftyp'&&['avif','avis'].includes(s.slice(8,12)))return 'image/avif';
 if(s.startsWith('%PDF-'))return 'application/pdf';
 if(s.startsWith('RIFF')&&s.slice(8,12)==='WAVE')return 'audio/wav';
 if(s.startsWith('ID3')||b[0]===255&&(b[1]&224)===224)return 'audio/mpeg';
 if(s.startsWith('OggS'))return 'audio/ogg';
 if(s.slice(4,8)==='ftyp')return ['M4A ','M4B '].includes(s.slice(8,12))?'audio/mp4':'video/mp4';
 if(b[0]===26&&b[1]===69&&b[2]===223&&b[3]===163)return 'video/webm';
 return '';
}
async function boundedForm(req){
 const max=42*1024*1024;if(Number(req.headers.get('content-length'))>max)fail('الحد الأقصى للرفع 40 ميجابايت.',413);
 const reader=req.body?.getReader();if(!reader)fail('اختر ملفاً من جهازك.');let size=0;const chunks=[];
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();fail('الملف أكبر من الحد المسموح.',413);}chunks.push(value);}
 try{return await new Request(req.url,{method:'POST',headers:{'content-type':req.headers.get('content-type')||''},body:Buffer.concat(chunks)}).formData();}catch{fail('تعذر قراءة الملف المرفوع.');}
}
function mediaRecord(id){if(!/^[a-f0-9-]{36}$/i.test(String(id)))return null;const row=sql.prepare("SELECT data FROM records WHERE id=? AND kind='marketing-file'").get(id);return row?JSON.parse(row.data):null;}
const validToken=(record,token)=>typeof token==='string'&&/^[a-f0-9]{64}$/.test(token)&&timingSafeEqual(Buffer.from(record.tokenHash,'hex'),Buffer.from(digest(token),'hex'));
export async function uploadMarketingMedia(req,user){
 requireOwner(user);const form=await boundedForm(req),file=form.get('file');if(!file||typeof file.arrayBuffer!=='function'||!file.size)fail('اختر صورة أو فيديو أو ملفاً صوتياً أو PDF.');
 if(file.size>40*1024*1024)fail('الحد الأقصى للملف 40 ميجابايت.',413);
 const bytes=new Uint8Array(await file.arrayBuffer()),type=detectMarketingMedia(bytes);if(!type)fail('نوع الملف غير مدعوم. اختر صورة، MP4، WebM، MP3، WAV، OGG، M4A أو PDF.');
 if(type.startsWith('image/')&&file.size>10*1024*1024)fail('الحد الأقصى للصورة 10 ميجابايت.',413);
 const id=randomUUID(),token=randomBytes(32).toString('hex'),name=String(file.name||'media').replace(/[\u0000-\u001f\u007f]/g,'').slice(0,160),record={name,type,size:file.size,tokenHash:digest(token)};
 await BUCKET.put(id,bytes);try{sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run(id,'marketing-file',user.userId,JSON.stringify(record),new Date().toISOString());}catch(e){await BUCKET.delete(id);throw e;}
 return {id,name,type,size:file.size,url:new URL('/api/marketing/media?id='+id+'&token='+token,process.env.APP_ORIGIN).href};
}
export function normalizeMarketingMedia(input){
 if(input===null||input===undefined)return null;
 const record=mediaRecord(input.id);if(!record)fail('المرفق غير موجود. ارفعه من الجهاز مجدداً.');
 let url;try{url=new URL(input.url);}catch{fail('رابط المرفق غير صالح.');}
 if(url.origin!==new URL(process.env.APP_ORIGIN).origin||url.pathname!=='/api/marketing/media'||url.searchParams.get('id')!==input.id||!validToken(record,url.searchParams.get('token')))fail('رابط المرفق غير صالح.');
 return {id:input.id,name:record.name,type:record.type,size:record.size,url:new URL('/api/marketing/media?id='+input.id+'&token='+url.searchParams.get('token'),process.env.APP_ORIGIN).href};
}
export async function serveMarketingMedia(req,user){
 const url=new URL(req.url),id=url.searchParams.get('id')||'',record=mediaRecord(id);if(!record)return new Response(null,{status:404});
 const owner=user?.email?.toLowerCase()==='alkunt@yahoo.com';if(!owner&&!validToken(record,url.searchParams.get('token')))return new Response(null,{status:404});
 const object=await BUCKET.get(id);if(!object)return new Response(null,{status:404});const bytes=object.body;
 const headers={'Content-Type':record.type,'Content-Disposition':`inline; filename*=UTF-8''${encodeURIComponent(record.name)}`,'X-Content-Type-Options':'nosniff','Cache-Control':'private, no-store','Referrer-Policy':'no-referrer','Content-Security-Policy':"sandbox; default-src 'none'",'Accept-Ranges':'bytes'};
 const range=req.headers.get('range');if(range){const match=range.match(/^bytes=(\d*)-(\d*)$/);if(!match||!match[1]&&!match[2])return new Response(null,{status:416,headers:{...headers,'Content-Range':`bytes */${bytes.length}`}});let start=match[1]?Number(match[1]):Math.max(0,bytes.length-Number(match[2])),end=match[1]?(match[2]?Math.min(Number(match[2]),bytes.length-1):bytes.length-1):bytes.length-1;if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=bytes.length)return new Response(null,{status:416,headers:{...headers,'Content-Range':`bytes */${bytes.length}`}});return new Response(bytes.subarray(start,end+1),{status:206,headers:{...headers,'Content-Range':`bytes ${start}-${end}/${bytes.length}`,'Content-Length':String(end-start+1)}});}
 return new Response(bytes,{headers:{...headers,'Content-Length':String(bytes.length)}});
}
