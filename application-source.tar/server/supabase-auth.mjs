import {randomBytes,randomUUID} from 'node:crypto';
import {sql} from './runtime.mjs';
import {ownerEmail,passwordHash} from './auth.mjs';

export const supabaseEnabled=()=>process.env.SUPABASE_AUTH_ENABLED==='true';
export class AuthServiceError extends Error{constructor(message,status=400){super(message);this.status=status;}}
function config(){
  if(!supabaseEnabled())throw new AuthServiceError('التسجيل عبر Supabase غير مفعّل حالياً.',503);
  let base;try{base=new URL(process.env.SUPABASE_URL);}catch{throw new AuthServiceError('خدمة التسجيل غير مهيأة.',503);}
  if(base.protocol!=='https:'||base.username||base.password||base.pathname!=='/'||!process.env.SUPABASE_PUBLISHABLE_KEY)throw new AuthServiceError('خدمة التسجيل غير مهيأة.',503);
  return {base:base.origin,key:process.env.SUPABASE_PUBLISHABLE_KEY};
}
export async function supabaseRequest(path,body,accessToken,method){
  const {base,key}=config();
  let response;try{response=await fetch(base+'/auth/v1/'+path,{method:method||(body===undefined?'GET':'POST'),headers:{apikey:key,'Content-Type':'application/json',...(accessToken?{Authorization:'Bearer '+accessToken}:{})},body:body===undefined?undefined:JSON.stringify(body),cache:'no-store',redirect:'error',signal:AbortSignal.timeout(12000)});}catch{throw new AuthServiceError('تعذر الاتصال بخدمة التسجيل. حاول مجدداً.',503);}
  const data=await response.json().catch(()=>({}));
  if(!response.ok){const code=data.error_code||data.code;
    if(response.status===429)throw new AuthServiceError('محاولات كثيرة. انتظر قليلاً ثم حاول مجدداً.',429);
    if(code==='email_not_confirmed')throw new AuthServiceError('أكّد بريدك الإلكتروني أولاً، ثم سجّل الدخول.',403);
    if(response.status>=500)throw new AuthServiceError('تعذر إرسال رسالة التأكيد. حاول لاحقاً أو تواصل مع المالك.',503);
    throw new AuthServiceError('بيانات الدخول أو رابط التأكيد غير صالح. تحقق منها وحاول مجدداً.',400);
  }
  return data;
}
export async function signupSupabase(email,password,name,details={}){
  const redirect=new URL('/auth/confirm',process.env.APP_ORIGIN).href;
  await supabaseRequest('signup?redirect_to='+encodeURIComponent(redirect),{email,password,data:{...details,display_name:name}});
  // Never grant a local session from signup, including projects with auto-confirm enabled.
  return {ok:true,requiresEmailConfirmation:true,message:'تم إرسال طلب التسجيل. افتح رسالة التأكيد في بريدك ثم اضغط تأكيد البريد. تحقق من البريد غير المرغوب فيه أيضاً.'};
}
export async function resendSupabase(email){
  await supabaseRequest('resend',{type:'signup',email,email_redirect_to:new URL('/auth/confirm',process.env.APP_ORIGIN).href});
}
export async function verifiedSupabaseUser(accessToken){
  if(typeof accessToken!=='string'||accessToken.length<20||accessToken.length>12000)throw new AuthServiceError('رابط التأكيد غير صالح.',400);
  const remote=await supabaseRequest('user',undefined,accessToken);
  if(!remote.id||typeof remote.email!=='string'||!remote.email_confirmed_at||remote.is_anonymous)throw new AuthServiceError('أكّد بريدك الإلكتروني قبل الدخول.',403);
  if(remote.email.trim().toLowerCase()===ownerEmail)throw new AuthServiceError('استخدم تسجيل دخول المالك الحالي.',403);
  return remote;
}
export async function syncSupabaseUser(remote){
  const email=remote.email.trim().toLowerCase();
  if(email===ownerEmail||!remote.email_confirmed_at)throw new AuthServiceError('غير مسموح.',403);
  const hash=await passwordHash(randomBytes(48).toString('base64url'));
  sql.exec('BEGIN IMMEDIATE');
  try{
    const mapping=sql.prepare('SELECT a.* FROM accounts a JOIN supabase_accounts s ON s.account_id=a.id WHERE s.supabase_id=?').get(remote.id);
    if(mapping){if(mapping.email!==email)throw new AuthServiceError('تم تغيير البريد. تواصل مع المالك لربط الحساب بأمان.',409);sql.exec('COMMIT');return {user:mapping,created:false};}
    // Never link an existing local account by matching its email: it may own paid content.
    if(sql.prepare('SELECT id FROM accounts WHERE lower(email)=?').get(email))throw new AuthServiceError('هذا البريد مرتبط بحساب قديم. استخدم كلمة مروره الحالية للدخول.',409);
    const user={id:randomUUID(),email,name:String(remote.user_metadata?.display_name||email.split('@')[0]).slice(0,120)};
    sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run(user.id,user.email,user.name,hash);
    sql.prepare('INSERT INTO supabase_accounts VALUES(?,?,?)').run(remote.id,user.id,new Date().toISOString());
    const profile=JSON.parse(sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id).data);
    profile.emailVerified=true;profile.authProvider='supabase';
    for(const key of ['firstName','lastName','country','callingCode','phone'])if(typeof remote.user_metadata?.[key]==='string')profile[key]=remote.user_metadata[key].slice(0,80);
    sql.prepare('UPDATE records SET data=? WHERE id=?').run(JSON.stringify(profile),'profile:'+user.id);
    const notification={title:'مسجل جديد أكّد بريده: '+user.name,title_en:'New verified registration: '+user.name,userId:user.id,date:new Date().toISOString()};
    sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('registration:'+user.id,'notification','admin',JSON.stringify(notification),notification.date);
    sql.exec('COMMIT');return {user,created:true};
  }catch(error){sql.exec('ROLLBACK');throw error;}
}
