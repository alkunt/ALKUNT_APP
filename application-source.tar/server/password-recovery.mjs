import {randomBytes,createHash} from 'node:crypto';
import {sql} from './runtime.mjs';import {passwordHash} from './auth.mjs';import {sendMail} from './mail.mjs';
const digest=token=>createHash('sha256').update(token).digest('hex');
export async function requestLocalReset(account){
 const token=randomBytes(32).toString('base64url'),hash=digest(token),url=new URL('/auth/recovery',process.env.APP_ORIGIN);url.hash='reset='+token;
 sql.prepare('DELETE FROM password_resets WHERE expires<=?').run(Date.now());
 sql.prepare('INSERT INTO password_resets VALUES(?,?,?)').run(hash,account.id,Date.now()+30*60000);
 try{await sendMail(account.email,'ALKUNT — إعادة ضبط كلمة المرور', 'افتح الرابط التالي خلال 30 دقيقة لتعيين كلمة مرور جديدة. الرابط يُستخدم مرة واحدة فقط.\n\n'+url.href+'\n\nإذا لم تطلب تغيير كلمة المرور فتجاهل الرسالة.');}catch(error){sql.prepare('DELETE FROM password_resets WHERE token=?').run(hash);throw error;}
}
export async function resetLocalPassword(token,password){
 if(typeof token!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(token))return false;
 const hash=digest(token);if(!sql.prepare('SELECT user FROM password_resets WHERE token=? AND expires>?').get(hash,Date.now()))return false;
 const value=await passwordHash(password);sql.exec('BEGIN IMMEDIATE');try{const reset=sql.prepare('SELECT user FROM password_resets WHERE token=? AND expires>?').get(hash,Date.now());if(!reset){sql.exec('ROLLBACK');return false;}sql.prepare('UPDATE accounts SET password=? WHERE id=?').run(value,reset.user);sql.prepare('DELETE FROM sessions WHERE user=?').run(reset.user);sql.prepare('DELETE FROM password_resets WHERE user=?').run(reset.user);recordPasswordChange(reset.user);sql.exec('COMMIT');return true;}catch(error){sql.exec('ROLLBACK');throw error;}
}
export function recordPasswordChange(userId){const date=new Date().toISOString();sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('password-change:'+randomBytes(16).toString('hex'),'notification',userId,JSON.stringify({title:'تم تغيير كلمة مرور حسابك',title_en:'Your password was changed',date,url:'/?view=account'}),date);}
