import {createHash,randomUUID} from 'node:crypto';
import {sql,BUCKET} from './runtime.mjs';

const MAX_BYTES=40*1024*1024;
const flights=new Map();
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
const now=()=>new Date().toISOString();
const read=id=>{const row=sql.prepare('SELECT * FROM records WHERE id=?').get(id);return row?{...JSON.parse(row.data),id:row.id,kind:row.kind,owner:row.owner}:null;};
let initialized=false;
function init(){if(initialized)return;sql.exec(`CREATE TABLE IF NOT EXISTS gumroad_delivery_files(source_id TEXT PRIMARY KEY,sha256 TEXT,size INTEGER,canonical_url TEXT,state TEXT NOT NULL,lease TEXT,lease_until INTEGER NOT NULL DEFAULT 0,error_code TEXT,updated TEXT NOT NULL);`);initialized=true;}
const configured=()=>process.env.GUMROAD_ENABLED==='true'&&!!process.env.GUMROAD_ACCESS_TOKEN;

function requireEditor(user){
 if(!user?.userId)throw fail('سجّل الدخول إلى لوحة التحكم.',401);
 const account=sql.prepare('SELECT email FROM accounts WHERE id=?').get(user.userId),profile=read('profile:'+user.userId);
 if(!account||account.email.toLowerCase()!==String(user.email||'').toLowerCase()||profile?.blocked)throw fail('Forbidden',403);
 if(account.email.toLowerCase()!=='alkunt@yahoo.com'&&!['admin','editor'].includes(profile?.role))throw fail('Forbidden',403);
}
function productFor(id){const p=typeof id==='string'&&id.length<=100&&read(id);if(p?.kind!=='product')throw fail('المنتج غير موجود.',404);return p;}
function sources(p){
 const ids=[p.file,...(Array.isArray(p.lessons)?p.lessons:[]).flatMap(l=>[l.file,/^[a-f0-9-]{36}$/.test(l.video||'')?l.video:null])].filter(Boolean);
 const unique=[...new Set(ids)];if(unique.length>10)throw fail('يمكن تجهيز حتى 10 مرفقات لكل منتج. اجمع الملفات في ملف واحد عند الحاجة.',409);
 return unique.map(id=>{const f=typeof id==='string'&&read(id);if(f?.kind!=='file'||f.purpose!=='content'||!Number.isSafeInteger(f.size)||f.size<=0||f.size>MAX_BYTES)throw fail('أحد مرفقات المنتج غير صالح. أعد إرفاق الملف من لوحة التحكم.',409);return f;});
}
function storageKey(value){
 const url=new URL(value);if(url.protocol!=='https:'||url.username||url.password||url.hash||url.port)throw fail('تعذر التحقق من وجهة رفع الملف.',502);
 const pathname=decodeURIComponent(url.pathname);let key;
 if(/^(?:gumroad|gumroad-specials)\.s3(?:\.[a-z0-9-]+)?\.amazonaws\.com$/.test(url.hostname))key=pathname.slice(1);
 else if(url.hostname==='s3.amazonaws.com')key=pathname.match(/^\/(?:gumroad|gumroad-specials)\/(attachments\/.*)$/)?.[1];
 if(!key||!/^attachments\/[A-Za-z0-9_=+-]{5,150}\//.test(key)||key.split('/').some(p=>p==='..'||p==='.')||/[\u0000-\u001f\\]/.test(key))throw fail('تعذر التحقق من وجهة رفع الملف.',502);
 return key;
}
function canonical(value,expectedKey){const url=new URL(value),key=storageKey(value);if(url.search||expectedKey&&key!==expectedKey)throw fail('تعذر التحقق من ملف التسليم.',502);return url.href;}
function legacy(p){
 let manifest;try{manifest=JSON.parse(process.env.GUMROAD_DELIVERY_FILES||'{}');}catch{throw fail('إعداد تسليم الملفات غير صالح. تواصل مع المالك.',503);}
 const entry=manifest?.[p.id];if(!entry||entry.sourceFileId!==p.file||!Array.isArray(entry.urls)||!entry.urls.length||entry.urls.length>10)return null;
 try{return entry.urls.map(url=>canonical(url));}catch{throw fail('إعداد تسليم الملفات غير صالح. تواصل مع المالك.',503);}
}
function resolve(p){
 init();const files=sources(p),old=legacy(p),urls=[];
 if(!files.length)throw fail('أرفق ملف المنتج قبل تجهيز التسليم عبر Gumroad.',409);
 for(const file of files){const row=sql.prepare('SELECT * FROM gumroad_delivery_files WHERE source_id=?').get(file.id);if(row?.state==='ready'&&row.size===file.size&&row.canonical_url)urls.push(canonical(row.canonical_url));else if(file.id===p.file&&old)urls.push(...old);else throw fail('ملف المنتج قيد التجهيز أو يحتاج إعادة المحاولة من لوحة التحكم.',409);}
 return [...new Set(urls)];
}
export function deliveryURLsForProducts(items){const urls=[];for(const item of items.filter(p=>p.price>0))urls.push(...resolve(productFor(item.id)));if(!urls.length)throw fail('ملفات التسليم غير جاهزة لهذا الطلب.',409);return [...new Set(urls)];}
function stateFor(p){
 if(!(Number(p.price)>0)||p.inBundle)return {productId:p.id,state:'not-required',fileCount:0,readyCount:0};
 try{
  init();const files=sources(p);if(!files.length)return {productId:p.id,state:'missing-file',fileCount:0,readyCount:0};
  const old=legacy(p);let readyCount=0,preparing=false,failed=false;
  for(const f of files){const row=sql.prepare('SELECT * FROM gumroad_delivery_files WHERE source_id=?').get(f.id);if(row?.state==='ready'&&row.size===f.size&&row.canonical_url){canonical(row.canonical_url);readyCount++;}else if(f.id===p.file&&old)readyCount++;else if(row?.state==='uploading'&&row.lease_until>Date.now())preparing=true;else if(row?.state==='failed'||row?.state==='uploading')failed=true;}
  return {productId:p.id,state:readyCount===files.length?'ready':preparing?'preparing':failed?'failed':configured()?'pending':'unconfigured',fileCount:files.length,readyCount};
 }catch{return {productId:p.id,state:'invalid-file',fileCount:0,readyCount:0};}
}
export function deliveryStatus(user,productId){requireEditor(user);return stateFor(productFor(productId));}
async function api(route,body){
 let response;try{response=await fetch('https://api.gumroad.com/v2/files/'+route,{method:'POST',redirect:'error',headers:{Authorization:'Bearer '+process.env.GUMROAD_ACCESS_TOKEN,'Content-Type':'application/x-www-form-urlencoded'},body,signal:AbortSignal.timeout(20000)});}catch{throw fail('تعذر رفع ملف التسليم إلى Gumroad. أعد المحاولة من لوحة التحكم.',502);}
 const value=await response.json().catch(()=>null);if(!response.ok||!value?.success)throw fail(response.status===401?'رفضت Gumroad مفتاح الربط. تواصل مع المالك.':'تعذر تجهيز ملف التسليم لدى Gumroad. أعد المحاولة.',502);return value;
}
async function upload(file){
 init();const current=sql.prepare('SELECT * FROM gumroad_delivery_files WHERE source_id=?').get(file.id);
 if(current?.state==='ready'&&current.size===file.size&&current.canonical_url)return canonical(current.canonical_url);
 if(current?.state==='uploading'&&current.lease_until>Date.now())throw fail('جارٍ تجهيز هذا الملف. تحقق من الحالة بعد قليل.',409);
 const lease=randomUUID(),leaseUntil=Date.now()+5*60000;
 const claimed=sql.prepare(`INSERT INTO gumroad_delivery_files(source_id,state,lease,lease_until,updated) VALUES(?,'uploading',?,?,?) ON CONFLICT(source_id) DO UPDATE SET state='uploading',lease=excluded.lease,lease_until=excluded.lease_until,error_code=NULL,updated=excluded.updated WHERE gumroad_delivery_files.state<>'uploading' OR gumroad_delivery_files.lease_until<?`).run(file.id,lease,leaseUntil,now(),Date.now());
 if(!claimed.changes)throw fail('جارٍ تجهيز هذا الملف. تحقق من الحالة بعد قليل.',409);
 let session,completing=false;
 try{
  const stored=await BUCKET.get(file.id);if(!stored?.body)throw fail('ملف المنتج غير موجود على الخادم. أعد رفعه.',409);
  const bytes=Buffer.from(stored.body);if(bytes.length!==file.size||bytes.length>MAX_BYTES)throw fail('حجم المرفق لا يطابق الملف المحفوظ. أعد رفعه.',409);
  const sha256=createHash('sha256').update(bytes).digest('hex');
  const name=String(file.name||'download.bin').normalize('NFC').replace(/[\u0000-\u001f\u007f/\\:*?"<>|]/g,'_').slice(0,180)||'download.bin';
  session=await api('presign',new URLSearchParams({filename:name,file_size:String(bytes.length)}));
  if(typeof session.upload_id!=='string'||!session.upload_id||session.upload_id.length>2000||typeof session.key!=='string'||!Array.isArray(session.parts)||session.parts.length!==1||session.parts[0].part_number!==1)throw fail('تعذر التحقق من جلسة رفع الملف.',502);
  canonical(session.file_url,session.key);const part=new URL(session.parts[0].presigned_url);
  if(storageKey(part.href)!==session.key||part.searchParams.get('uploadId')!==session.upload_id||part.searchParams.get('partNumber')!=='1')throw fail('تعذر التحقق من وجهة رفع الملف.',502);
  let uploaded;try{uploaded=await fetch(part,{method:'PUT',redirect:'error',body:bytes,signal:AbortSignal.timeout(60000)});}catch{throw fail('تعذر نقل ملف التسليم. أعد المحاولة.',502);}
  const etag=uploaded.headers.get('etag');if(!uploaded.ok||!etag||etag.length>200||/[\r\n]/.test(etag))throw fail('لم تؤكد Gumroad استلام الملف. أعد المحاولة.',502);
  // /complete is single-use. A lost response starts a new upload on the next attempt.
  completing=true;
  const completed=await api('complete',new URLSearchParams({upload_id:session.upload_id,key:session.key,'parts[][part_number]':'1','parts[][etag]':etag}));
  const url=canonical(completed.file_url,session.key);
  const saved=sql.prepare("UPDATE gumroad_delivery_files SET sha256=?,size=?,canonical_url=?,state='ready',lease=NULL,lease_until=0,error_code=NULL,updated=? WHERE source_id=? AND lease=?").run(sha256,bytes.length,url,now(),file.id,lease);
  if(!saved.changes)throw fail('تغيرت جلسة تجهيز الملف. أعد التحقق من الحالة.',409);return url;
 }catch(error){
  if(session?.upload_id&&session?.key&&!completing){for(let attempt=0;attempt<3;attempt++){try{const aborted=await api('abort',new URLSearchParams({upload_id:session.upload_id,key:session.key}));if(aborted.status==='already_gone')break;}catch{break;}}}
  sql.prepare("UPDATE gumroad_delivery_files SET state='failed',lease=NULL,lease_until=0,error_code='UPLOAD_FAILED',updated=? WHERE source_id=? AND lease=?").run(now(),file.id,lease);
  throw error.status?error:fail('تعذر تجهيز ملف التسليم. أعد المحاولة من لوحة التحكم.',502);
 }
}
async function ensureFile(file){if(flights.has(file.id))return flights.get(file.id);const flight=upload(file);flights.set(file.id,flight);try{return await flight;}finally{flights.delete(file.id);}}
export async function prepareProductDelivery(user,productId){
 requireEditor(user);const p=productFor(productId),status=stateFor(p);if(['ready','not-required','missing-file','invalid-file'].includes(status.state))return status;
 if(!configured())return {...status,state:'unconfigured'};
 const files=sources(p),old=legacy(p);
 try{for(const file of files){if(file.id===p.file&&old)continue;await ensureFile(file);}}
 catch{const latest=stateFor(productFor(productId));return {...latest,state:latest.state==='preparing'?'preparing':'failed'};}
 // Re-read the product: a file may have changed while its older version was uploading.
 return stateFor(productFor(productId));
}
