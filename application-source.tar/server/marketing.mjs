import {normalizeRichDoc,richDocText} from '../app/rich-text.mjs';
import {normalizeMarketingMedia} from './marketing-media.mjs';
import {marketingRecipient} from '../app/marketing-audience.mjs';
import {randomUUID} from 'node:crypto';
import {sql} from './runtime.mjs';
import {ownerEmail, limit} from './auth.mjs';
import {emailTemplate,safeEmailUrl} from '../app/marketing-template.mjs';

export const CAMPAIGN_LIMIT=200;
const now=()=>new Date().toISOString();
export class MarketingError extends Error { constructor(message,status=400){super(message);this.status=status;} }
const fail=(message,status=400)=>{throw new MarketingError(message,status);};
export const configured=()=>!!(process.env.BREVO_API_KEY&&(process.env.MAIL_FROM||process.env.SMTP_FROM));
export function initMarketing(){sql.exec(`
 CREATE TABLE IF NOT EXISTS marketing_contacts(email TEXT PRIMARY KEY,name TEXT NOT NULL DEFAULT '',country TEXT NOT NULL DEFAULT '',status TEXT NOT NULL,source TEXT NOT NULL,consent_at TEXT,updated TEXT NOT NULL,pending_sync INTEGER NOT NULL DEFAULT 0,revision INTEGER NOT NULL DEFAULT 1);
 CREATE TABLE IF NOT EXISTS marketing_campaigns(id TEXT PRIMARY KEY,data TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'draft',version INTEGER NOT NULL DEFAULT 1,tested_version INTEGER NOT NULL DEFAULT 0,provider_id INTEGER,list_id INTEGER,recipients INTEGER NOT NULL DEFAULT 0,stats TEXT NOT NULL DEFAULT '{}',error TEXT NOT NULL DEFAULT '',created TEXT NOT NULL,updated TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS marketing_members(campaign TEXT NOT NULL,email TEXT NOT NULL,PRIMARY KEY(campaign,email));
 CREATE TABLE IF NOT EXISTS marketing_events(id TEXT PRIMARY KEY,campaign TEXT NOT NULL,action TEXT NOT NULL,detail TEXT NOT NULL,created TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS marketing_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
`);if(!sql.prepare('PRAGMA table_info(marketing_contacts)').all().some(c=>c.name==='revision'))sql.exec('ALTER TABLE marketing_contacts ADD COLUMN revision INTEGER NOT NULL DEFAULT 1');}
export function requireOwner(user){if(!user)fail('تسجيل الدخول مطلوب.',401);if(user.email?.toLowerCase()!==ownerEmail)fail('هذه الميزة متاحة للمالك فقط.',403);}
export function validEmail(value){const email=String(value||'').trim().toLowerCase();return email.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)?email:null;}
function recordEvent(campaign,action,detail=''){sql.prepare('INSERT INTO marketing_events VALUES(?,?,?,?,?)').run(randomUUID(),campaign,action,String(detail).slice(0,300),now());}
function row(id){const r=sql.prepare('SELECT * FROM marketing_campaigns WHERE id=?').get(String(id));if(!r)fail('الحملة غير موجودة.',404);return r;}
const publicCampaign=r=>({...JSON.parse(r.data),id:r.id,status:r.status,version:r.version,tested:r.tested_version===r.version,providerId:r.provider_id,recipients:r.recipients,stats:JSON.parse(r.stats),error:r.error,created:r.created,updated:r.updated});
export function contacts(){
 const profiles=sql.prepare("SELECT a.email,a.name,r.data FROM accounts a LEFT JOIN records r ON r.id='profile:'||a.id").all();
 const buyers=new Set(sql.prepare("SELECT DISTINCT a.email FROM accounts a JOIN records r ON r.owner=a.id AND r.kind='order' WHERE json_extract(r.data,'$.status')='confirmed'").all().map(x=>x.email.toLowerCase()));
 const map=new Map(profiles.map(p=>{const profile=p.data?JSON.parse(p.data):{};return [p.email.toLowerCase(),{email:p.email.toLowerCase(),name:p.name,country:profile.country||'',status:'registered',source:'account',registered:true,blocked:!!profile.blocked,buyer:buyers.has(p.email.toLowerCase())}];}));
 for(const c of sql.prepare('SELECT * FROM marketing_contacts ORDER BY updated DESC').all()){const old=map.get(c.email)||{};map.set(c.email,{...old,...c,name:c.name||old.name||'',country:c.country||old.country||'',registered:!!old.registered,buyer:!!old.buyer,blocked:!!old.blocked});}
 return [...map.values()];
}
export function audience(d){return contacts().filter(c=>marketingRecipient(c,d));}
export function dashboard(){initMarketing();const list=contacts(),campaigns=sql.prepare('SELECT * FROM marketing_campaigns ORDER BY created DESC LIMIT 100').all().map(publicCampaign);return {configured:configured(),sender:process.env.MAIL_FROM||process.env.SMTP_FROM||'',testRecipient:ownerEmail,limit:CAMPAIGN_LIMIT,contacts:list,campaigns,events:sql.prepare('SELECT campaign,action,detail,created FROM marketing_events ORDER BY created DESC LIMIT 100').all(),summary:{subscribers:list.filter(c=>marketingRecipient(c)).length,registered:list.filter(c=>c.registered).length,unsubscribed:list.filter(c=>c.status==='unsubscribed').length,total:list.length,campaigns:campaigns.length}};}
export function validateDraft(input){
 if(!input||typeof input!=='object'||Array.isArray(input))fail('بيانات الحملة غير صالحة.');
 const d={};for(const [key,max] of Object.entries({name:100,subject:150,preheader:180,headline:180,body:15000,buttonLabel:60,buttonUrl:2000,imageUrl:2000,signature:300,country:120})){d[key]=String(input?.[key]||'').trim();if(d[key].length>max)fail('أحد حقول الحملة أطول من الحد المسموح.');}
 try{if(input.bodyDoc){d.bodyDoc=normalizeRichDoc(input.bodyDoc);d.body=richDocText(d.bodyDoc);if(d.body.length>15000)fail('نص الرسالة يتجاوز 15000 حرف.');}}catch(e){fail(e.message);}
 d.media=normalizeMarketingMedia(input.media);
 if(!d.name||!d.subject||!d.body||d.body.length<10)fail('أدخل اسم الحملة وعنوان الرسالة ونصاً لا يقل عن 10 أحرف.');
 if(/[\r\n]/.test(d.subject))fail('عنوان الرسالة يجب أن يكون في سطر واحد.');
 for(const k of ['buttonUrl','imageUrl'])if(d[k]&&!safeEmailUrl(d[k]))fail('استخدم روابط HTTPS صحيحة دون بيانات دخول.');
 if(d.buttonUrl&&!d.buttonLabel)fail('أدخل عنوان زر الرسالة.');
 d.language=input.language==='en'?'en':'ar';d.audience=input.audience==='buyers'?'buyers':'subscribers';
 return d;
}
export function saveCampaign(input,user){requireOwner(user);initMarketing();const d=validateDraft(input),date=now();
 if(input.id){const r=row(input.id);if(r.status!=='draft'||r.version!==Number(input.version))fail('تغيّرت الحملة. حدّث الصفحة قبل تعديلها.',409);const result=sql.prepare("UPDATE marketing_campaigns SET data=?,version=version+1,tested_version=0,error='',updated=? WHERE id=? AND status='draft' AND version=?").run(JSON.stringify(d),date,r.id,r.version);if(!result.changes)fail('الحملة قيد الاستخدام.',409);recordEvent(r.id,'saved');return publicCampaign(row(r.id));}
 const id=randomUUID();sql.prepare('INSERT INTO marketing_campaigns(id,data,created,updated) VALUES(?,?,?,?)').run(id,JSON.stringify(d),date,date);recordEvent(id,'created');return publicCampaign(row(id));
}
export function cloneCampaign(id,user){requireOwner(user);const c=publicCampaign(row(id));delete c.id;c.name=c.name.slice(0,92)+' — نسخة';return saveCampaign(c,user);}
export async function brevo(path,method='GET',body){
 if(!configured())fail('خدمة Brevo غير مهيأة. يلزم مفتاح Brevo وبريد المرسل في إعدادات الخادم.',503);
 let response;try{response=await fetch('https://api.brevo.com/v3/'+path,{method,headers:{'api-key':process.env.BREVO_API_KEY,Accept:'application/json','Content-Type':'application/json'},...(body!==undefined?{body:JSON.stringify(body)}:{}),redirect:'error',signal:AbortSignal.timeout(15000)});}catch{throw new MarketingError('تعذر تأكيد استجابة خدمة البريد. راجع حالة الحملة قبل إعادة المحاولة.',502);}
 if(!response.ok){
  let problem={};try{problem=await response.json();}catch{}
  const code=/^[a-zA-Z0-9_-]{1,60}$/.test(problem?.code||'')?problem.code:'';
  let detail=typeof problem?.message==='string'?problem.message:'';
  if(process.env.BREVO_API_KEY)detail=detail.replaceAll(process.env.BREVO_API_KEY,'[redacted]');
  detail=detail.replace(/[\u0000-\u001f]/g,' ').replace(/(api[-_ ]?key|authorization|password|token)\s*[:=]\s*[^\s,;]+/gi,'$1=[redacted]').slice(0,350);
  const messages={401:'تعذر توثيق الربط مع Brevo. راجع إعداد خدمة البريد.',403:'حساب Brevo لا يسمح بهذه العملية حالياً. راجع تفعيل الحملات وصلاحيات المفتاح.',402:'رصيد البريد غير كافٍ. لم تُفعّل أي ترقية أو عملية شراء.',429:'وصلت خدمة البريد إلى حد الطلبات. انتظر ثم حدّث الحالة.'};
  let message=messages[response.status]||'رفضت خدمة البريد العملية.';
  if(response.status===400&&/dmarc/i.test(detail))message='رفض Brevo عنوان المرسل بسبب سياسة DMARC. يلزم مرسل على نطاق موثّق أو عنوان الإرسال البديل الذي يقدمه Brevo.';
  else if(response.status===400&&/sender/i.test(detail))message='رفض Brevo بيانات المرسل. تحقق من اعتماد العنوان المستخدم للحملة.';
  else if(response.status===400&&/test|recipient|contact|emailTo/i.test(detail))message='تعذر إرسال التجربة. تحقق من وجود بريد المالك في جهات اتصال وقائمة الاختبار لدى Brevo.';
  const error=new MarketingError(message+(code?' ['+code+']':'')+(detail?' '+detail:''),response.status>=500?502:400);error.providerStatus=response.status;throw error;
 }
 return response.status===204?{}:await response.json();
}
export async function connection(){const account=await brevo('account');return {ok:true,sender:process.env.MAIL_FROM||process.env.SMTP_FROM,plans:(account.plan||[]).map(p=>({type:p.type,credits:p.credits,creditsType:p.creditsType}))};}
async function syncPreference(email){
 for(let attempt=0;attempt<3;attempt++){
  const c=sql.prepare('SELECT * FROM marketing_contacts WHERE email=?').get(email);if(!c?.pending_sync)return;
  try{await brevo('contacts/'+encodeURIComponent(email),'PUT',{emailBlacklisted:c.status==='unsubscribed'});}catch(e){if(e.providerStatus!==404)throw e;}
  const done=sql.prepare('UPDATE marketing_contacts SET pending_sync=0 WHERE email=? AND revision=?').run(email,c.revision);
  if(done.changes)return;
  // A stale provider reply may have changed the remote state after a newer choice finished.
  sql.prepare('UPDATE marketing_contacts SET pending_sync=1 WHERE email=?').run(email);
 }
 fail('حُفظ التفضيل، وما زالت مزامنته مع خدمة البريد مطلوبة.',409);
}
function recordRemoteOptOut(c){
 sql.prepare("INSERT INTO marketing_contacts(email,name,status,source,updated) VALUES(?,?, 'unsubscribed','Brevo unsubscribe',?) ON CONFLICT(email) DO UPDATE SET status='unsubscribed',source='Brevo unsubscribe',updated=excluded.updated,revision=marketing_contacts.revision+1 WHERE marketing_contacts.revision=? AND pending_sync=0 AND status IN ('subscribed','registered')").run(c.email,c.name||'',now(),c.revision||0);
}
export async function syncContacts(user){
 requireOwner(user);initMarketing();const list=contacts().filter(c=>c.pending_sync||marketingRecipient(c)).sort((a,b)=>Number(!!b.pending_sync)-Number(!!a.pending_sync)||String(a.updated||'').localeCompare(String(b.updated||''))).slice(0,200);let updated=0;
 for(let i=0;i<list.length;i+=4){const results=await Promise.allSettled(list.slice(i,i+4).map(async c=>{
  if(c.pending_sync)await syncPreference(c.email);
  else {
   try{const remote=await brevo('contacts/'+encodeURIComponent(c.email));if(remote.emailBlacklisted)recordRemoteOptOut(c);else if(c.revision)sql.prepare('UPDATE marketing_contacts SET updated=? WHERE email=? AND revision=?').run(now(),c.email,c.revision);}catch(e){if(e.providerStatus!==404)throw e;}
   if(c.status==='registered'&&!c.revision)sql.prepare("INSERT OR IGNORE INTO marketing_contacts(email,name,status,source,updated) VALUES(?,?,'registered','account',?)").run(c.email,c.name||'',now());
  }
  updated++;
 }));const rejected=results.find(r=>r.status==='rejected');if(rejected)throw rejected.reason;}
 return {updated};
}
function providerName(c){return `ALKUNT ${c.id} ${c.name}`.slice(0,120);}
function campaignPayload(c,listId){return {name:providerName(c),subject:c.subject,previewText:c.preheader,sender:{name:'ALKUNT',email:process.env.MAIL_FROM||process.env.SMTP_FROM},replyTo:process.env.MAIL_FROM||process.env.SMTP_FROM,htmlContent:emailTemplate(c,process.env.APP_ORIGIN),tag:'alkunt-app',...(listId?{recipients:{listIds:[listId]}}:{})};}
async function providerCampaign(c,listId){
 const payload=campaignPayload(c,listId);let id=c.providerId;
 if(id){const remote=await brevo(`emailCampaigns/${id}?excludeHtmlContent=true`);if(remote.status!=='draft')fail('الحملة ليست مسودة لدى خدمة البريد. حدّث الحالة أولاً.',409);await brevo('emailCampaigns/'+id,'PUT',payload);}
 else{const created=await brevo('emailCampaigns','POST',payload);id=created.id;if(!Number.isInteger(id))fail('استجابة غير متوقعة من خدمة البريد.',502);sql.prepare('UPDATE marketing_campaigns SET provider_id=?,updated=? WHERE id=?').run(id,now(),c.id);}
 return id;
}
function acquire(id,version){const r=row(id);if(r.status!=='draft'||r.version!==Number(version))fail('الحملة قيد الإرسال أو تغيرت. حدّث الحالة.',409);const result=sql.prepare("UPDATE marketing_campaigns SET status='preparing',error='',updated=? WHERE id=? AND status='draft' AND version=?").run(now(),r.id,r.version);if(!result.changes)fail('توجد عملية أخرى للحملة.',409);return publicCampaign(r);}
function failedOperation(id,error,uncertain=false){sql.prepare('UPDATE marketing_campaigns SET status=?,error=?,updated=? WHERE id=?').run(uncertain?'review':'draft',error instanceof MarketingError?error.message:'تعذر إتمام العملية. حدّث الحالة قبل المتابعة.',now(),id);recordEvent(id,uncertain?'review':'error','تعذر إتمام العملية');}
export async function prepareCampaign(id,version,user){requireOwner(user);initMarketing();if(!limit('marketing:prepare',5))fail('انتظر قبل فحص الحملة مجدداً.',429);const c=acquire(id,version);try{await providerCampaign(c);sql.prepare("UPDATE marketing_campaigns SET status='draft',error='',updated=? WHERE id=?").run(now(),id);recordEvent(id,'prepared','تم تجهيز مسودة لدى Brevo دون إرسال');return publicCampaign(row(id));}catch(e){failedOperation(id,e,e.status===502);throw e;}}
export async function testCampaign(id,version,user){requireOwner(user);initMarketing();if(!limit('marketing:test',5))fail('انتظر قبل إرسال نسخة تجريبية أخرى.',429);const c=acquire(id,version);try{const pid=await providerCampaign(c);await brevo(`emailCampaigns/${pid}/sendTest`,'POST',{emailTo:[ownerEmail]});sql.prepare("UPDATE marketing_campaigns SET status='draft',tested_version=version,error='',updated=? WHERE id=?").run(now(),id);recordEvent(id,'test',ownerEmail);return publicCampaign(row(id));}catch(e){failedOperation(id,e,e.status===502);throw e;}}
async function listFor(c){
 if(c.listId)return c.listId;
 let folder=sql.prepare("SELECT value FROM marketing_meta WHERE key='folder'").get()?.value;
 if(!folder){const folders=await brevo('contacts/folders?limit=50&offset=0');folder=folders.folders?.find(f=>f.name==='ALKUNT App')?.id;if(!folder)folder=(await brevo('contacts/folders','POST',{name:'ALKUNT App'})).id;if(!Number.isInteger(Number(folder)))fail('تعذر إنشاء قائمة المستلمين.',502);sql.prepare("INSERT OR REPLACE INTO marketing_meta VALUES('folder',?)").run(String(folder));}
 const made=await brevo('contacts/lists','POST',{folderId:Number(folder),name:'ALKUNT '+c.id});if(!Number.isInteger(made.id))fail('تعذر إنشاء قائمة المستلمين.',502);sql.prepare('UPDATE marketing_campaigns SET list_id=? WHERE id=?').run(made.id,c.id);return made.id;
}
async function syncAudience(c,listId,selected){
 const emails=new Set(selected.map(x=>x.email));const old=sql.prepare('SELECT email FROM marketing_members WHERE campaign=?').all(c.id).map(x=>x.email);const removed=old.filter(e=>!emails.has(e));
 if(removed.length){await brevo(`contacts/lists/${listId}/contacts/remove`,'POST',{emails:removed});for(const email of removed)sql.prepare('DELETE FROM marketing_members WHERE campaign=? AND email=?').run(c.id,email);}
 for(let i=0;i<selected.length;i+=4){const results=await Promise.allSettled(selected.slice(i,i+4).map(async contact=>{await brevo('contacts','POST',{email:contact.email,listIds:[listId],updateEnabled:true});sql.prepare('INSERT OR IGNORE INTO marketing_members VALUES(?,?)').run(c.id,contact.email);}));const rejected=results.find(r=>r.status==='rejected');if(rejected)throw rejected.reason;}
}
export async function launchCampaign(id,version,scheduledAt,confirm,user){
 requireOwner(user);initMarketing();if(confirm!==true)fail('راجع الحملة واعتمد الإرسال أولاً.');if(!limit('marketing:launch',5))fail('محاولات كثيرة. انتظر قبل إطلاق حملة أخرى.',429);
 const existing=row(id);if(existing.tested_version!==existing.version)fail('أرسل نسخة تجريبية من آخر تعديل قبل إطلاق الحملة.');
 let schedule='';if(scheduledAt){const time=new Date(scheduledAt).getTime();if(!Number.isFinite(time)||time<Date.now()+5*60000||time>Date.now()+30*86400000)fail('اختر موعداً بين خمس دقائق وثلاثين يوماً من الآن.');schedule=new Date(time).toISOString();}
 const c=acquire(id,version);let submission=false;
 try{let selected=audience(c);if(!selected.length)fail('لا يوجد مستلمون متاحون ضمن الجمهور المحدد.');if(selected.length>CAMPAIGN_LIMIT)fail('اختر جمهوراً لا يزيد على '+CAMPAIGN_LIMIT+' مستلم في الحملة الواحدة.');
 const listId=await listFor({...c,listId:row(id).list_id});await syncAudience(c,listId,selected);
 // Recheck eligibility and opt-outs before dispatch; lists never re-enable Brevo blacklists.
 const still=audience(c);if(still.length!==selected.length||still.some(x=>!selected.some(y=>y.email===x.email)))fail('تغيّرت اشتراكات الجمهور أثناء الإعداد. أعد مراجعة الحملة.');
 const pid=await providerCampaign({...c,providerId:row(id).provider_id},listId);const finalAudience=audience(c);if(finalAudience.length!==selected.length||finalAudience.some(x=>!selected.some(y=>y.email===x.email)))fail('تغيّر الجمهور. راجع الموافقات قبل إعادة الإرسال.');sql.prepare('UPDATE marketing_campaigns SET recipients=? WHERE id=?').run(selected.length,id);
 submission=true;if(schedule)await brevo('emailCampaigns/'+pid,'PUT',{scheduledAt:schedule});else await brevo(`emailCampaigns/${pid}/sendNow`,'POST',{});
 const data={...JSON.parse(row(id).data),scheduledAt:schedule};sql.prepare('UPDATE marketing_campaigns SET status=?,data=?,error=?,updated=? WHERE id=?').run(schedule?'scheduled':'queued',JSON.stringify(data),'',now(),id);recordEvent(id,schedule?'scheduled':'queued',String(selected.length));return publicCampaign(row(id));
 }catch(e){failedOperation(id,e,submission||e.status===502);throw e;}
}
export async function refreshCampaign(id,user){requireOwner(user);initMarketing();let c=publicCampaign(row(id));if(c.status==='preparing'&&Date.now()-new Date(c.updated).getTime()<180000)fail('ما زالت عملية الحملة جارية. انتظر قليلاً.',409);
 if(!c.providerId){if(!['review','preparing'].includes(c.status))return c;const found=await brevo('emailCampaigns?limit=100&offset=0&sort=desc&excludeHtmlContent=true');const match=found.campaigns?.find(p=>p.name===providerName(c));if(!match)fail('لم يتأكد إنشاء الحملة لدى Brevo. راجع لوحة Brevo قبل إعادة الإرسال.',409);sql.prepare('UPDATE marketing_campaigns SET provider_id=? WHERE id=?').run(match.id,id);c=publicCampaign(row(id));}
 const remote=await brevo(`emailCampaigns/${c.providerId}?statistics=globalStats&excludeHtmlContent=true`);const states={draft:'draft',queued:'queued',scheduled:'scheduled',sent:'sent',suspended:'paused',archive:'archived',running:'sending',inProcess:'sending',inProgress:'sending',replicate:'review'};const status=states[remote.status]||'review';sql.prepare('UPDATE marketing_campaigns SET status=?,stats=?,error=?,updated=? WHERE id=?').run(status,JSON.stringify(remote.statistics?.globalStats||{}),'',now(),id);recordEvent(id,'refreshed',status);return publicCampaign(row(id));
}
export async function pauseCampaign(id,user){requireOwner(user);const c=publicCampaign(row(id));if(!['scheduled','queued','sending'].includes(c.status)||!c.providerId)fail('هذه الحملة لا تقبل الإيقاف.');await brevo(`emailCampaigns/${c.providerId}/status`,'PUT',{status:'suspended'});sql.prepare("UPDATE marketing_campaigns SET status='paused',updated=? WHERE id=?").run(now(),id);recordEvent(id,'paused');return publicCampaign(row(id));}
export function importContacts(rows,consent,source,user){requireOwner(user);initMarketing();if(consent!==true)fail('أكد موافقة أصحاب العناوين على استقبال الرسائل.');if(!Array.isArray(rows)||!rows.length||rows.length>1000)fail('استورد من 1 إلى 1000 عنوان في كل مرة.');const reason=String(source||'').trim();if(reason.length<3||reason.length>200)fail('أدخل مصدر موافقة القائمة.');let added=0,skipped=0,invalid=0;const date=now();sql.exec('BEGIN IMMEDIATE');try{for(const input of rows){const email=validEmail(input?.email);if(!email){invalid++;continue;}const old=sql.prepare('SELECT status FROM marketing_contacts WHERE email=?').get(email);if(old){skipped++;continue;}sql.prepare('INSERT INTO marketing_contacts(email,name,country,status,source,consent_at,updated) VALUES(?,?,?,?,?,?,?)').run(email,String(input.name||'').trim().slice(0,120),String(input.country||'').trim().slice(0,120),'subscribed','import: '+reason,date,date);added++;}sql.exec('COMMIT');}catch(e){sql.exec('ROLLBACK');throw e;}recordEvent('contacts','import',JSON.stringify({added,skipped,invalid}));return {added,skipped,invalid};}
export function recordRegistrationConsent(user,consent){
 if(consent!==true)return;
 const email=validEmail(user?.email);if(!email||!sql.prepare('SELECT id FROM accounts WHERE id=? AND lower(email)=?').get(user.id,email))fail('حساب الموافقة غير صالح.');
 initMarketing();const date=now();const inserted=sql.prepare('INSERT OR IGNORE INTO marketing_contacts(email,name,status,source,consent_at,updated) VALUES(?,?,?,?,?,?)').run(email,String(user.name||'').slice(0,120),'subscribed','registration checkbox v1',date,date);
 if(inserted.changes)recordEvent('contacts','subscribed',email);
}
export function subscription(user){if(!user)fail('تسجيل الدخول مطلوب.',401);initMarketing();const email=user.email.toLowerCase(),c=sql.prepare('SELECT status,pending_sync FROM marketing_contacts WHERE email=?').get(email),registered=!!sql.prepare('SELECT id FROM accounts WHERE email=?').get(email);return {subscribed:c?c.status==='subscribed'||c.status==='registered'&&registered:registered,pending:!!c?.pending_sync,hasChoice:!!c&&c.status!=='registered'};}
export async function setSubscription(user,subscribe,consent){if(!user)fail('تسجيل الدخول مطلوب.',401);if(typeof subscribe!=='boolean'||subscribe&&consent!==true)fail('أكّد اختيار الاشتراك.');initMarketing();const email=user.email.toLowerCase(),date=now();
 // An import or stale account metadata can never restore an unsubscribed address.
 sql.prepare('INSERT INTO marketing_contacts(email,name,status,source,consent_at,updated,pending_sync) VALUES(?,?,?,?,?,?,?) ON CONFLICT(email) DO UPDATE SET status=excluded.status,source=excluded.source,consent_at=excluded.consent_at,updated=excluded.updated,pending_sync=excluded.pending_sync,revision=marketing_contacts.revision+1').run(email,user.displayName||' ',subscribe?'subscribed':'unsubscribed','account choice',subscribe?date:null,date,configured()?1:0);
 let pending=false;if(configured()){try{await syncPreference(email);}catch{pending=true;}}
 // Only an authenticated member's explicit consent may restore a provider subscription.
 recordEvent('contacts',subscribe?'subscribed':'unsubscribed',email);return {...subscription(user),pending:pending||subscription(user).pending};
}
