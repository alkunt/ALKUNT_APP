import nodemailer from 'nodemailer';
export const mailConfigured=()=>!!((process.env.BREVO_API_KEY||process.env.RESEND_API_KEY||process.env.SMTP_HOST&&process.env.SMTP_USER&&process.env.SMTP_PASSWORD)&&(process.env.MAIL_FROM||process.env.SMTP_FROM));
export async function sendMail(to,subject,text){
 const from=process.env.MAIL_FROM||process.env.SMTP_FROM;
 if(!mailConfigured())throw Error('Mail service not configured');
 if(process.env.BREVO_API_KEY){const response=await fetch('https://api.brevo.com/v3/smtp/email',{method:'POST',headers:{'api-key':process.env.BREVO_API_KEY,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify({sender:{email:from,name:'ALKUNT'},to:[{email:to}],subject,textContent:text}),signal:AbortSignal.timeout(10000),redirect:'error'});if(!response.ok)throw Error('Mail rejected');return;}
 if(process.env.SMTP_HOST){const port=Number(process.env.SMTP_PORT||587);const transport=nodemailer.createTransport({host:process.env.SMTP_HOST,port,secure:port===465,requireTLS:port!==465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD},connectionTimeout:10000,socketTimeout:15000});const result=await transport.sendMail({from,to,subject,text});if(!result.accepted?.length)throw Error('Mail rejected');return;}
 const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+process.env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from,to:[to],subject,text}),signal:AbortSignal.timeout(10000),redirect:'error'});if(!response.ok)throw Error('Mail rejected');
}
