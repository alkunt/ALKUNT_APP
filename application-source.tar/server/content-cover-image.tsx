import {ImageResponse} from 'next/og';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {contentCoverVersion} from '../app/content-cover.mjs';
let font:Promise<Buffer>|undefined;
const images=new Map<string,Promise<ArrayBuffer>>();
const palettes:any={blue:['#061b36','#104b80','#49d5ed'],purple:['#21123d','#4b2b76','#c3a1ff'],teal:['#052f38','#096975','#68eadb']};
const labels:any={blog:'KNOWLEDGE, UNLOCKED.',prompt:'PROMPT COLLECTION',bundle:'PROMPT COLLECTION',course:'LEARN. CREATE. EVOLVE.',book:'YOUR NEXT CHAPTER',offer:'LEARN. CREATE. EVOLVE.'};
const icons:any={blog:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z M14 2v6h6 M8 13h8 M8 17h5',book:'M12 7v14 M3 3h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5v16h-5a4 4 0 0 0-4 2 4 4 0 0 0-4-2H3Z',prompt:'M8 9l-4 3 4 3 M16 9l4 3-4 3 M14 5l-4 14',course:'M2 8l10-5 10 5-10 5Z M6 10v7c4 3 8 3 12 0v-7 M22 8v8'};
export function generatedContentCover(product:any,language:string):Promise<ArrayBuffer> {
  const key=product.id+':'+contentCoverVersion(product,language);
  const saved=images.get(key);
  if(saved)return saved;
  const pending=render(product).catch(error=>{images.delete(key);throw error;});
  if(images.size>=48)images.delete(images.keys().next().value!);
  images.set(key,pending);
  return pending;
}
async function render(product:any):Promise<ArrayBuffer> {
  const [start,end,accent]=palettes[product.theme]||palettes.blue;
  font ||= readFile(path.join(process.cwd(),'public/fonts/arabic-bold.ttf'));
  // Use the same illustrated fallback in the catalog and sharing. The Arabic
  // title is included separately in the caption and social metadata.
  const response=new ImageResponse(<div style={{display:'flex',flexDirection:'column',justifyContent:'space-between',width:'100%',height:'100%',padding:'50px 64px',background:`linear-gradient(125deg,${start},${end})`,color:'#fff',fontFamily:'ALKUNT',position:'relative',overflow:'hidden'}}>
    {Array.from({length:13},(_,i)=><div key={'v'+i} style={{position:'absolute',left:i*100,top:0,height:630,borderLeft:'1px solid #ffffff0c'}}/>)}
    {Array.from({length:7},(_,i)=><div key={'h'+i} style={{position:'absolute',top:i*100,left:0,width:1200,borderTop:'1px solid #ffffff0c'}}/>)}
    <div style={{display:'flex',alignItems:'center',gap:14,fontSize:28,letterSpacing:4,color:'#dceefa'}}>ALKUNT <span style={{fontSize:17,color:accent,letterSpacing:3}}>ACADEMY</span></div>
    <div style={{display:'flex',position:'absolute',left:445,top:160,width:310,height:310,borderRadius:'50%',border:`1px solid ${accent}`,background:'#ffffff08',alignItems:'center',justifyContent:'center'}}>
      <div style={{position:'absolute',width:378,height:378,borderRadius:'50%',border:'1px solid #ffffff20'}}/>
      <svg width="170" height="170" viewBox="0 0 24 24" fill="none" stroke="#e8f8ff" strokeWidth="0.8" strokeLinecap="round" strokeLinejoin="round"><path d={icons[product.type]||icons.course}/></svg>
    </div>
    <div style={{position:'absolute',left:295,top:250,width:20,height:20,background:accent,borderRadius:'50%'}}/>
    <div style={{position:'absolute',right:285,top:420,width:12,height:12,background:accent,borderRadius:'50%'}}/>
    <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',fontSize:23,letterSpacing:4,color:'#dceefa'}}><span>{labels[product.type]||labels.blog}</span><span style={{color:accent,fontSize:28}}>+</span></div>
  </div>,{width:1200,height:630,fonts:[{name:'ALKUNT',data:await font,weight:700,style:'normal'}]});
  return response.arrayBuffer();
}
