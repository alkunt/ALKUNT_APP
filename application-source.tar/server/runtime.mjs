import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,writeFileSync,readFileSync,existsSync,unlinkSync} from 'node:fs';
import path from 'node:path';
export const dataDir=path.resolve(process.env.DATA_DIR||'./data');
mkdirSync(dataDir,{recursive:true,mode:0o700});
const key=Symbol.for('alkunt.sqlite');
export const sql=globalThis[key]||=new DatabaseSync(path.join(dataDir,'alkunt.sqlite'));
sql.exec(`PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,owner TEXT NOT NULL DEFAULT '',data TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS grants(id TEXT PRIMARY KEY,user TEXT NOT NULL,product TEXT NOT NULL,source TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS records_kind_owner ON records(kind,owner);
CREATE INDEX IF NOT EXISTS grants_user ON grants(user);
CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS auth_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);`);
// Keep the customer directory complete, including accounts created before this migration.
// INSERT OR IGNORE preserves existing roles, blocked flags and profile preferences.
sql.exec(`
CREATE TRIGGER IF NOT EXISTS accounts_create_profile AFTER INSERT ON accounts
BEGIN
  INSERT OR IGNORE INTO records(id,kind,owner,data,created)
  VALUES('profile:' || NEW.id,'profile',NEW.id,
    json_object('name',NEW.name,'email',NEW.email,'role',CASE WHEN lower(NEW.email)='alkunt@yahoo.com' THEN 'admin' ELSE 'customer' END),
    strftime('%Y-%m-%dT%H:%M:%fZ','now'));
END;
INSERT OR IGNORE INTO records(id,kind,owner,data,created)
SELECT 'profile:' || id,'profile',id,
  json_object('name',name,'email',email,'role',CASE WHEN lower(email)='alkunt@yahoo.com' THEN 'admin' ELSE 'customer' END),
  strftime('%Y-%m-%dT%H:%M:%fZ','now')
FROM accounts;
`);
function prepare(query,args=[]){return {bind(...values){return prepare(query,values)},execute(method){const st=sql.prepare(query);return method==='all'?{results:st.all(...args)}:method==='first'?st.get(...args)||null:{success:true,meta:st.run(...args)}},async all(){return this.execute('all')},async first(){return this.execute('first')},async run(){return this.execute('run')}}}
export const DB={prepare,async batch(statements){sql.exec('BEGIN IMMEDIATE');try{const result=statements.map(s=>s.execute('run'));sql.exec('COMMIT');return result}catch(e){sql.exec('ROLLBACK');throw e}}};
const uploads=path.join(dataDir,'uploads');mkdirSync(uploads,{recursive:true,mode:0o700});
function filename(id){if(!/^[a-zA-Z0-9-]{1,100}$/.test(id))throw Error('Invalid file identifier');return path.join(uploads,id)}
export const BUCKET={async put(id,bytes,options={}){writeFileSync(filename(id),bytes,{mode:0o600})},async get(id){const f=filename(id);return existsSync(f)?{body:readFileSync(f)}:null},async delete(id){const f=filename(id);if(existsSync(f))unlinkSync(f)}};
export const env={DB,BUCKET,get VAPID_PRIVATE_JWK(){return process.env.VAPID_PRIVATE_JWK},get VAPID_PUBLIC_KEY(){return process.env.VAPID_PUBLIC_KEY},get RESEND_API_KEY(){return process.env.RESEND_API_KEY},get MAIL_FROM(){return process.env.MAIL_FROM}};
