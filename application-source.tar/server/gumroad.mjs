import {isEmailRegistrationOffer} from '../app/offer-registration.mjs';
import {randomUUID,timingSafeEqual} from 'node:crypto';
import {sql} from './runtime.mjs';
import {deliveryURLsForProducts} from './gumroad-delivery.mjs';

const ownerEmail='alkunt@yahoo.com';
const currencies=new Set(['KWD','USD','SAR','AED']);
const checkoutFlights=new Map();
const deletingOrders=new Set();
const saleVerifications=new Map();
let fxFlight;
const date=()=>new Date().toISOString();
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
const email=value=>String(value||'').trim().toLowerCase();
const escape=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const read=id=>{const r=sql.prepare('SELECT * FROM records WHERE id=?').get(id);return r?{...JSON.parse(r.data),id:r.id,kind:r.kind,owner:r.owner}:null;};
function write(id,kind,owner,data){sql.prepare('INSERT INTO records(id,kind,owner,data,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data').run(id,kind,owner,JSON.stringify(data),date());}
function transaction(run){sql.exec('BEGIN IMMEDIATE');try{const result=run();sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}
// Deleted order details cannot be restored. Keep only entitlement/settlement keys
// so a genuine earlier payment or later refund can still be verified safely.
function deletionMarker(order){return {deletedAt:order.deletedAt||date(),status:order.status,items:order.items.map(item=>({id:item.id})),...(order.paymentMethod==='gumroad'?{paymentMethod:'gumroad',email:order.email,date:order.date,paymentStage:order.paymentStage}: {})};}
function settlementOrder(id){const current=read(id);if(current?.kind==='order')return current;const marker=read('deleted-order:'+id);return marker?.kind==='deleted-order'&&marker.paymentMethod==='gumroad'?{...marker,id,kind:'deleted-order'}:null;}
export function initGumroad(){sql.exec(`
CREATE TABLE IF NOT EXISTS gumroad_quotes(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,data TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS gumroad_payments(order_id TEXT PRIMARY KEY,quote_id TEXT UNIQUE NOT NULL,product_id TEXT UNIQUE,expected_cents INTEGER NOT NULL,sale_id TEXT UNIQUE,state TEXT NOT NULL,updated INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS gumroad_fx(currency TEXT PRIMARY KEY,data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS gumroad_quotes_expiry ON gumroad_quotes(expires);
`);}
export function gumroadStatus(){return {enabled:process.env.GUMROAD_ENABLED==='true'&&process.env.GUMROAD_CURRENCY_ACCEPTED==='USD'&&!!process.env.GUMROAD_ACCESS_TOKEN&&!!process.env.GUMROAD_SELLER_ID&&!!process.env.GUMROAD_WEBHOOK_SECRET,provider:'gumroad',checkoutCurrency:'USD',providerHandlesTax:true};}
function requireEnabled(){if(!gumroadStatus().enabled)throw fail('الدفع عبر Gumroad لم يُفعّل بعد.',503);}
export function requirePaymentUser(user){
 if(!user?.userId)throw fail('سجّل الدخول لمتابعة الدفع.',401);
 const account=sql.prepare('SELECT email FROM accounts WHERE id=?').get(user.userId);
 if(!account||email(account.email)!==email(user.email))throw fail('الحساب غير متاح.',403);
 const profile=read('profile:'+user.userId);if(profile?.blocked)throw fail('الحساب موقوف.',403);
 return profile||{};
}
function limit(key,max,seconds){
 const now=Date.now();
 transaction(()=>{const row=sql.prepare('SELECT * FROM auth_limits WHERE key=?').get(key);if(row&&row.expires>now&&row.count>=max)throw fail('طلبات كثيرة. انتظر قليلًا ثم حاول مجددًا.',429);sql.prepare('INSERT INTO auth_limits VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET count=excluded.count,expires=excluded.expires').run(key,row&&row.expires>now?row.count+1:1,row&&row.expires>now?row.expires:now+seconds*1000);});
}
async function provider(route,method='GET',body){
 const token=process.env.GUMROAD_ACCESS_TOKEN;if(!token)throw fail('إعدادات خدمة الدفع غير مكتملة.',503);
 if(!/^\/(products|sales)(?:[/?]|$)/.test(route))throw fail('Invalid provider route',500);
 let response;
 try{response=await fetch('https://api.gumroad.com/v2'+route,{method,redirect:'error',headers:{Authorization:'Bearer '+token,...(body?{'Content-Type':'application/x-www-form-urlencoded'}:{})},body:body instanceof URLSearchParams?body:body?new URLSearchParams(Object.entries(body).map(([k,v])=>[k,String(v)])):undefined,signal:AbortSignal.timeout(20000)});}catch{throw fail('تعذر الاتصال بخدمة الدفع. لم يتم تأكيد أي مبلغ.',502);}
 const result=await response.json().catch(()=>null);
 if(!response.ok||!result?.success)throw fail(response.status===401?'رفضت خدمة الدفع مفتاح الربط. تواصل مع المالك.':'تعذر إكمال الطلب لدى Gumroad. يمكنك متابعة حالة الطلب من حسابك.',502);
 return result;
}
function deliveryFiles(items){
 return deliveryURLsForProducts(items);
}
function productBody(values,files){
 const body=new URLSearchParams(Object.entries(values).map(([key,value])=>[key,String(value)]));
 for(const url of files)body.append('files[][url]',url);
 return body;
}
function deliveryDescription(order){
 const origin=new URL(process.env.APP_ORIGIN).origin;
 return '<h2>محتوى رقمي من ALKUNT</h2><ul>'+order.items.map(p=>'<li>'+escape(p.title_ar||p.title_en)+'</li>').join('')+'</ul><p>نزّل مرفقات طلبك مباشرة من Gumroad بعد نجاح الدفع. يظهر المحتوى أيضًا في مكتبتك على ALKUNT بعد التحقق من العملية. استخدم بريد حسابك نفسه عند الشراء.</p><p>Download your order files directly from Gumroad after successful payment. ALKUNT library access follows payment verification. Use the same email as your ALKUNT account.</p><p><a href="'+origin+'/?view=account">حساب ALKUNT</a></p>';
}
function quoteCart(user,input){
 const settings=read('settings');if(!settings?.salesEnabled)throw fail('الشراء غير متاح حاليًا.',409);
 if(!currencies.has(settings.currency))throw fail('عملة المتجر غير مدعومة.',409);
 if(!Array.isArray(input.ids)||!input.ids.length||input.ids.length>50||input.ids.some(id=>typeof id!=='string'||id.length>100))throw fail('السلة غير صالحة.');
 const ids=[...new Set(input.ids)].sort(),products=ids.map(read),now=date();
 for(const product of products){
  if(product?.kind!=='product'||product.status!=='published'||product.publishAt&&product.publishAt>now||product.inBundle||isEmailRegistrationOffer(product))throw fail('أحد المنتجات غير متاح للشراء.',409);
  if(product.oldPrice>product.price&&product.offerEnd&&product.offerEnd<now)product.price=product.oldPrice;
  if(!Number.isFinite(product.price)||product.price<0)throw fail('سعر المنتج غير صالح.',409);
  if(sql.prepare('SELECT id FROM grants WHERE user=? AND product=?').get(user.userId,product.id))throw fail('أحد المنتجات موجود في مكتبتك بالفعل.',409);
 }
 let coupon=null;const code=String(input.coupon||'').trim().toUpperCase();if(code.length>100)throw fail('رمز الخصم غير صالح.');
 if(code){
  coupon=sql.prepare("SELECT id,data FROM records WHERE kind='coupon'").all().map(row=>({...JSON.parse(row.data),id:row.id})).find(c=>c.code===code&&c.active&&(!c.expires||c.expires>now)&&(!c.maxUses||Number(c.used||0)<c.maxUses));
  if(!coupon||!['percent','fixed'].includes(coupon.type)||!Number.isFinite(coupon.value)||coupon.value<0||coupon.type==='percent'&&coupon.value>100)throw fail('رمز الخصم غير صالح أو انتهى.');
 }
 const subtotal=products.reduce((sum,p)=>sum+Math.round(p.price*1000),0);
 const eligible=coupon?products.filter(p=>!coupon.products?.length||coupon.products.includes(p.id)).reduce((sum,p)=>sum+Math.round(p.price*1000),0):0;
 const discount=coupon?Math.min(eligible,Math.round(coupon.type==='percent'?eligible*coupon.value/100:coupon.value*1000)):0;
 if(!Number.isSafeInteger(subtotal)||subtotal>1e9)throw fail('قيمة السلة غير صالحة.');
 // Gumroad is the merchant of record and calculates applicable sales taxes at its checkout.
 return {ids,products:products.map(p=>({id:p.id,title_ar:p.title_ar,title_en:p.title_en,price:p.price})),subtotal:subtotal/1000,discount:discount/1000,total:(subtotal-discount)/1000,currency:settings.currency,couponId:coupon?.id||null,couponCode:code,tax:0,providerHandlesTax:true};
}
async function exchange(currency){
 if(currency==='USD')return {rate:1,updatedAt:date(),provider:null};
 const cached=sql.prepare('SELECT data FROM gumroad_fx WHERE currency=?').get(currency),now=Date.now();const previous=cached?JSON.parse(cached.data):null;
 if(previous&&previous.nextUpdate>now&&now-previous.updated<48*3600000)return previous;
 if(fxFlight){await fxFlight;const row=sql.prepare('SELECT data FROM gumroad_fx WHERE currency=?').get(currency);if(row){const value=JSON.parse(row.data);if(now-value.updated<48*3600000)return value;}}
 fxFlight=(async()=>{
  try{
   const response=await fetch('https://open.er-api.com/v6/latest/'+currency,{redirect:'error',signal:AbortSignal.timeout(12000)});if(!response.ok)throw Error('FX unavailable');const result=await response.json();
   const rate=result.rates?.USD,updated=Number(result.time_last_update_unix)*1000;
   if(result.result!=='success'||result.base_code!==currency||!Number.isFinite(rate)||rate<=0||rate>100||!Number.isFinite(updated)||updated>now+300000||now-updated>48*3600000)throw Error('FX stale');
   const value={rate,updated,updatedAt:new Date(updated).toISOString(),nextUpdate:Math.min(now+24*3600000,Math.max(now+3600000,Number(result.time_next_update_unix)*1000||0)),provider:'https://www.exchangerate-api.com'};
   sql.prepare('INSERT INTO gumroad_fx VALUES(?,?) ON CONFLICT(currency) DO UPDATE SET data=excluded.data').run(currency,JSON.stringify(value));return value;
  }catch{if(previous&&now-previous.updated<48*3600000)return previous;throw fail('تعذر تحديث سعر الصرف. أعد المحاولة لاحقًا قبل الدفع.',503);}
 })();try{return await fxFlight;}finally{fxFlight=null;}
}
export async function createPaymentQuote(user,input){
 requirePaymentUser(user);requireEnabled();initGumroad();limit('gumroad:quote:'+user.userId,60,600);
 const cart=quoteCart(user,input);if(cart.total)deliveryFiles(cart.products);
 const fx=cart.total?await exchange(cart.currency):{rate:1,updatedAt:date(),provider:null};
 const cents=Math.round(cart.total*fx.rate*100);
 if(cart.total&&(cents<100||cents>1000000))throw fail('الدفع بالدولار متاح للسلة من 1 إلى 10,000 دولار. يمكنك تعديل السلة أو التواصل مع المالك.',409);
 const quote={...cart,id:randomUUID(),checkoutCurrency:'USD',checkoutTotal:cents/100,expectedCents:cents,fx,expiresAt:new Date(Date.now()+15*60000).toISOString()};
 sql.prepare('DELETE FROM gumroad_quotes WHERE expires<? AND id NOT IN(SELECT quote_id FROM gumroad_payments)').run(Date.now()-86400000);
 sql.prepare('INSERT INTO gumroad_quotes VALUES(?,?,?,?)').run(quote.id,user.userId,JSON.stringify(quote),Date.parse(quote.expiresAt));
 return quote;
}
function publicPayment(order){return {ok:true,id:order.id,number:order.number,status:order.status,paymentStage:order.paymentStage,paymentLink:order.paymentLink||'',checkoutTotal:order.gumroad?.expectedCents/100,checkoutCurrency:'USD'};}
function reserveCoupon(cart,orderId,userId){
 if(!cart.couponId)return;const coupon=read(cart.couponId);if(!coupon)throw fail('رمز الخصم غير متاح.',409);
 write(coupon.id,'coupon','',{...coupon,used:Number(coupon.used||0)+1});write(coupon.id+':gumroad:'+orderId,'coupon-use',userId,{order:orderId,date:date()});
}
function releaseCoupon(order){
 if(!order.coupon)return;const useId=order.coupon+':gumroad:'+order.id,use=read(useId);if(!use||use.released)return;
 const coupon=read(order.coupon);if(coupon)write(coupon.id,'coupon','',{...coupon,used:Math.max(0,Number(coupon.used||0)-1)});
 write(useId,'coupon-use',order.owner,{...use,released:true,date:date()});
}
function checkoutUrl(value){
 const url=new URL(value);const origin=new URL(process.env.GUMROAD_STORE_ORIGIN||'https://invalid.local');
 if(url.origin!==origin.origin||url.protocol!=='https:'||url.username||url.password||!/^\/l\/[a-zA-Z0-9_-]+$/.test(url.pathname))throw fail('رابط الدفع الذي أعادته الخدمة غير صالح.',502);
 url.search='';url.hash='';url.searchParams.set('wanted','true');return url.href;
}
const paymentPermalink=order=>'alkunt-'+order.id.replace(/-/g,'');
const paymentProductName=order=>('ALKUNT — '+order.items.map(p=>p.title_ar||p.title_en).join(' + ')).slice(0,180);
function matchesOrderLink(product,order){
 try{const url=new URL(product.short_url),origin=new URL(process.env.GUMROAD_STORE_ORIGIN);return url.origin===origin.origin&&url.pathname==='/l/'+paymentPermalink(order)&&!url.search&&!url.hash&&!url.username&&!url.password;}catch{return false;}
}
function validateUnboundDraft(product,order,payment){
 if(!product?.id||!matchesOrderLink(product,order)||product.name!==paymentProductName(order)||product.published!==false||product.deleted===true||product.currency!=='usd'||product.price!==payment.expected_cents||product.customizable_price!==false||product.max_purchase_count!==1||Number(product.sales_count||0)!==0)throw fail('مسودة رابط الدفع لا تطابق الطلب. لم يُفتح رابط للدفع؛ تواصل مع المالك.',409);
}
async function findUnboundDraft(order,payment){
 // A create request can persist a draft even when its response is lost or incomplete.
 // Recover only this order's exact, unpublished single-purchase draft; never POST again.
 const result=await provider('/products'),matches=(result.products||[]).filter(p=>matchesOrderLink(p,order));
 if(!matches.length)return null;
 if(matches.length!==1)throw fail('تعذر تحديد مسودة واحدة لهذا الطلب. تواصل مع المالك.',409);
 const product=(await provider('/products/'+encodeURIComponent(matches[0].id))).product;
 if(product?.id!==matches[0].id)throw fail('تعذر تأكيد هوية رابط الدفع.',502);
 validateUnboundDraft(product,order,payment);return product;
}
async function finishCheckout(orderId){
 const payment=sql.prepare('SELECT * FROM gumroad_payments WHERE order_id=?').get(orderId);let order=read(orderId);
 if(!payment||!order)throw fail('الطلب غير متاح.',404);if(order.status==='confirmed'||order.paymentLink)return publicPayment(order);
 let product;
 try{
  const files=deliveryFiles(order.items);
  if(payment.product_id)product=(await provider('/products/'+encodeURIComponent(payment.product_id))).product;
  else{
   const released=order.coupon&&read(order.coupon+':gumroad:'+order.id)?.released;
   if(released)throw fail('انتهى حجز خصم هذا الطلب. تواصل مع المالك لإعادة مراجعته قبل الدفع.',409);
   if(payment.state!=='new'){
    product=await findUnboundDraft(order,payment);
    if(!product)throw fail('لم نعثر على رابط محفوظ لهذا الطلب. لم يُنشأ رابط جديد؛ تواصل مع المالك.',409);
   }else{
    sql.prepare("UPDATE gumroad_payments SET state='creating',updated=? WHERE order_id=?").run(Date.now(),orderId);
    try{
     const result=await provider('/products','POST',productBody({draft:true,native_type:'digital',name:paymentProductName(order),price:payment.expected_cents,price_currency_type:'usd',max_purchase_count:1,customizable_price:false,custom_permalink:paymentPermalink(order),description:deliveryDescription(order),custom_summary:'تنزيل مباشر من Gumroad وإتاحة في مكتبة ALKUNT — Direct file download and ALKUNT library access'},files));
     product=result.product?.id?(await provider('/products/'+encodeURIComponent(result.product.id))).product:await findUnboundDraft(order,payment);
    }catch(error){product=await findUnboundDraft(order,payment);if(!product)throw error;}
   }
   validateUnboundDraft(product,order,payment);
   sql.prepare("UPDATE gumroad_payments SET product_id=?,state='draft',updated=? WHERE order_id=?").run(product.id,Date.now(),orderId);
  }
  if(!product?.id||product.currency!=='usd'||product.price!==payment.expected_cents||product.customizable_price===true)throw fail('بيانات رابط الدفع لا تطابق الطلب.',502);
  const expectedProductId=product.id;
  // Recover an older empty draft. Never replace files already attached to a product.
  if(!product.published&&!product.files?.length)product=(await provider('/products/'+encodeURIComponent(product.id),'PUT',productBody({description:deliveryDescription(order)},files))).product;
  if(product?.id!==expectedProductId||product.currency!=='usd'||product.price!==payment.expected_cents||product.customizable_price===true)throw fail('بيانات رابط الدفع لا تطابق الطلب.',502);
  if(!Array.isArray(product.files)||product.files.length<files.length)throw fail('لم تؤكد Gumroad إرفاق ملفات التسليم. لم يُفتح رابط الدفع.',502);
  const link=checkoutUrl(product.short_url);
  // The product/order binding is durable before the customer can pay the published link.
  if(!product.published){const enabled=(await provider('/products/'+encodeURIComponent(product.id)+'/enable','PUT')).product;if(!enabled?.published)throw fail('تعذر نشر رابط الدفع.',502);}
  transaction(()=>{order=read(orderId);if(order.status!=='pending')return;order.paymentLink=link;order.paymentStage='awaiting-payment';order.gumroad.productId=product.id;write(order.id,'order',order.owner,order);sql.prepare("UPDATE gumroad_payments SET state='ready',updated=? WHERE order_id=?").run(Date.now(),orderId);});
  return publicPayment(read(orderId));
 }catch(error){
  const saved=sql.prepare('SELECT product_id FROM gumroad_payments WHERE order_id=?').get(orderId);
  transaction(()=>{const current=read(orderId);if(current.status==='pending'){current.paymentStage=saved.product_id?'preparation-failed':'link-failed';write(orderId,'order',current.owner,current);if(!saved.product_id){releaseCoupon(current);sql.prepare("UPDATE gumroad_payments SET state='failed',updated=? WHERE order_id=?").run(Date.now(),orderId);}}});
  error.orderId=orderId;
  throw error;
 }
}
async function checkoutFlight(orderId){
 if(deletingOrders.has(orderId)||read('deleted-order:'+orderId))throw fail('حُذف هذا الطلب. أنشئ طلبًا جديدًا من السلة.',404);
 if(checkoutFlights.has(orderId))return checkoutFlights.get(orderId);
 const flight=finishCheckout(orderId);checkoutFlights.set(orderId,flight);try{return await flight;}finally{checkoutFlights.delete(orderId);}
}
export async function retryPayment(user,orderId){
 requirePaymentUser(user);requireEnabled();initGumroad();
 const order=typeof orderId==='string'&&orderId.length<=100?read(orderId):null;
 if(order?.kind!=='order'||order.owner!==user.userId||order.paymentMethod!=='gumroad')throw fail('الطلب غير متاح.',404);
 if(order.status!=='pending')return publicPayment(order);
 limit('gumroad:retry:'+user.userId,6,600);
 return checkoutFlight(orderId);
}
export async function startPayment(user,input){
 const profile=requirePaymentUser(user);requireEnabled();initGumroad();
 const record=sql.prepare('SELECT * FROM gumroad_quotes WHERE id=? AND user_id=?').get(String(input.quoteId||''),user.userId);if(!record)throw fail('أعد حساب السلة قبل الدفع.',409);
 const existing=sql.prepare('SELECT order_id FROM gumroad_payments WHERE quote_id=?').get(record.id);
 if(existing)return checkoutFlight(existing.order_id);
 if(record.expires<Date.now())throw fail('انتهت صلاحية السعر. حدّث السلة قبل الدفع.',409);
 limit('gumroad:checkout:'+user.userId,6,600);limit('gumroad:checkout:all',50,3600);
 const quote=JSON.parse(record.data),id=randomUUID(),now=date();
 transaction(()=>{
  const latest=quoteCart(user,{ids:quote.ids,coupon:quote.couponCode});
  if(latest.total!==quote.total||latest.currency!==quote.currency||JSON.stringify(latest.products)!==JSON.stringify(quote.products)||latest.discount!==quote.discount)throw fail('تغير السعر أو الخصم. حدّث السلة قبل الدفع.',409);
  if(latest.total)deliveryFiles(latest.products);
  const pending=sql.prepare("SELECT id,data FROM records WHERE kind='order' AND owner=?").all(user.userId).find(row=>{const o=JSON.parse(row.data);return o.status==='pending'&&o.paymentMethod==='gumroad'&&o.items?.some(p=>quote.ids.includes(p.id));});
  if(pending)throw Object.assign(fail('لديك طلب دفع مفتوح لهذا المحتوى. تابعه من طلباتي.',409),{orderId:pending.id});
  const order={id,number:'ALK-'+Date.now()+'-'+id.slice(0,4),buyer:{name:profile.name||user.displayName||'',email:user.email,country:profile.country||'',phone:profile.phone?(profile.callingCode||'')+' '+profile.phone:''},items:quote.products,subtotal:quote.subtotal,discount:quote.discount,total:quote.total,currency:quote.currency,tax:0,status:quote.total===0?'confirmed':'pending',country:profile.country==='Kuwait'||profile.country==='الكويت'?'KW':'OTHER',paymentMethod:quote.total===0?'coupon':'gumroad',paymentStage:quote.total===0?'free-confirmed':'preparing-link',paymentLink:'',email:user.email,payer:profile.name||user.displayName||'',phone:'',receipt:'',note:'',date:now,timeline:[{status:'pending',date:now}],coupon:quote.couponId,gumroad:{expectedCents:quote.expectedCents,currency:'usd',fx:quote.fx,providerHandlesTax:true}};
  reserveCoupon(quote,id,user.userId);write(id,'order',user.userId,order);sql.prepare('INSERT INTO gumroad_payments VALUES(?,?,?,?,?,?,?)').run(id,quote.id,null,quote.expectedCents,null,quote.total===0?'free':'new',Date.now());
  if(quote.total===0){order.timeline.push({status:'confirmed',date:now});write(id,'order',user.userId,order);for(const p of order.items)sql.prepare('INSERT OR IGNORE INTO grants VALUES(?,?,?,?)').run(user.userId+':'+p.id,user.userId,p.id,id);}
  write(randomUUID(),'audit',user.userId,{action:'gumroad:checkout',target:id,date:now});
 });
 const order=read(id);if(order.status==='confirmed')return publicPayment(order);
 return checkoutFlight(id);
}
function verifySale(sale,payment,order){
 if(!order||!sale||sale.seller_id!==process.env.GUMROAD_SELLER_ID||sale.product_id!==payment.product_id||email(sale.email||sale.purchase_email)!==email(order.email)||sale.price!==payment.expected_cents||String(sale.currency).toLowerCase()!=='usd'||Number(sale.quantity||1)!==1||sale.test===true||sale.is_test_purchase===true)throw fail('بيانات عملية الدفع لا تطابق الطلب. لم يُفعّل المحتوى.',409);
 if(!sale.id||!/^[a-zA-Z0-9_=-]{5,200}$/.test(sale.id))throw fail('معرّف عملية الدفع غير صالح.',409);
 const created=Date.parse(sale.created_at||'');if(!Number.isFinite(created)||created<Date.parse(order.date)-60000)throw fail('تاريخ عملية الدفع لا يطابق الطلب.',409);
 for(const item of order.items)if(read(item.id)?.kind!=='product')throw fail('أحد المنتجات حُذف. يحتاج الطلب إلى مراجعة المالك.',409);
}
function revokeOrderGrant(order,productId){
 const grant=sql.prepare('SELECT * FROM grants WHERE user=? AND product=?').get(order.owner,productId);if(grant?.source!==order.id)return;
 const other=sql.prepare("SELECT id,kind,data FROM records WHERE kind IN ('order','deleted-order') AND owner=? AND id NOT IN (?,?)").all(order.owner,order.id,'deleted-order:'+order.id).find(row=>{const data=JSON.parse(row.data);return data.status==='confirmed'&&data.items?.some(p=>p.id===productId);});
 if(other)sql.prepare('UPDATE grants SET source=? WHERE id=?').run(other.kind==='deleted-order'?other.id.slice('deleted-order:'.length):other.id,grant.id);else sql.prepare('DELETE FROM grants WHERE id=? AND source=?').run(grant.id,order.id);
}
async function verifySaleNow(saleId){
 initGumroad();if(!/^[a-zA-Z0-9_=-]{5,200}$/.test(String(saleId||'')))throw fail('Invalid sale identifier');
 const sale=(await provider('/sales/'+encodeURIComponent(saleId))).sale;
 if(sale?.id!==saleId)throw fail('Sale response mismatch',409);
 const payment=sql.prepare('SELECT * FROM gumroad_payments WHERE product_id=?').get(sale.product_id);if(!payment)return {ignored:true};
 const order=settlementOrder(payment.order_id);verifySale(sale,payment,order);
 // The single-sale endpoint also exposes failed/test records. Membership in the
 // successful-sales collection is required in addition to matching the sale details.
 const successful=await provider('/sales?'+new URLSearchParams({product_id:payment.product_id}));
 if(!successful.sales?.some(item=>item.id===saleId))throw fail('لم تُسجل العملية ضمن المبيعات الناجحة. لم يُفعّل المحتوى.',409);
 const refunded=sale.refunded===true||sale.chargebacked===true;
 const disputed=(sale.disputed===true||sale.chargedback===true)&&sale.dispute_won!==true;
 const revoked=sale.access_revoked===true;
 const partial=sale.partially_refunded===true;
 return transaction(()=>{
  const current=settlementOrder(order.id),saved=sql.prepare('SELECT * FROM gumroad_payments WHERE order_id=?').get(order.id);
  if(!current||!saved)throw fail('الطلب غير متاح.',404);
  if(saved.sale_id&&saved.sale_id!==saleId)throw fail('توجد عملية دفع أخرى لهذا الطلب. يحتاج إلى مراجعة المالك.',409);
  if(sql.prepare('SELECT order_id FROM gumroad_payments WHERE sale_id=? AND order_id<>?').get(saleId,order.id))throw fail('Sale already assigned',409);
  const next=refunded?'refunded':disputed?'disputed':revoked?'revoked':current.status==='refunded'?'refunded':'confirmed';
  const stage=next==='refunded'?'refunded':disputed?'disputed':revoked?'access-revoked':partial?'partial-refund-review':'verified';
  if(current.status===next&&current.paymentStage===stage&&saved.sale_id===saleId)return current.kind==='deleted-order'?{ok:true,ignored:'deleted_order',status:next}:publicPayment(current);
  current.status=next;current.paymentStage=stage;current.gumroad={...current.gumroad,saleId,verifiedAt:date()};current.timeline=[...(current.timeline||[]),{status:next,date:date()}];
  for(const p of current.items){if(next==='confirmed')sql.prepare('INSERT OR IGNORE INTO grants VALUES(?,?,?,?)').run(current.owner+':'+p.id,current.owner,p.id,current.id);else revokeOrderGrant(current,p.id);}
  if(current.kind==='deleted-order')write('deleted-order:'+current.id,'deleted-order',current.owner,deletionMarker(current));else write(current.id,'order',current.owner,current);
  sql.prepare('UPDATE gumroad_payments SET sale_id=?,state=?,updated=? WHERE order_id=?').run(saleId,next,Date.now(),current.id);
  write(randomUUID(),'audit','gumroad',{action:'gumroad:'+stage,target:current.id,date:date()});
  if(current.kind==='deleted-order')return {ok:true,ignored:'deleted_order',status:next};
  write(randomUUID(),'notification',current.owner,{title:next==='confirmed'?'تم تأكيد الدفع وإضافة المحتوى إلى مكتبتك':'تحديث حالة الدفع للطلب '+current.number,title_en:next==='confirmed'?'Payment verified — your content is available':'Payment status updated for '+current.number,order:current.id,date:date()});
  if(stage==='partial-refund-review'||next!=='confirmed')write(randomUUID(),'notification','admin',{title:'تحديث دفع Gumroad: '+current.number,title_en:'Gumroad payment update: '+current.number,order:current.id,date:date()});
  return publicPayment(current);
 });
}
export async function verifyPaymentSale(saleId){
 if(!/^[a-zA-Z0-9_=-]{5,200}$/.test(String(saleId||'')))throw fail('Invalid sale identifier');
 const previous=saleVerifications.get(saleId)||Promise.resolve();
 const current=previous.catch(()=>{}).then(()=>verifySaleNow(saleId));saleVerifications.set(saleId,current);
 try{return await current;}finally{if(saleVerifications.get(saleId)===current)saleVerifications.delete(saleId);}
}
export async function checkPayment(user,orderId){
 requirePaymentUser(user);initGumroad();limit('gumroad:check:'+user.userId,30,600);
 const order=read(String(orderId||''));if(order?.kind!=='order'||order.paymentMethod!=='gumroad'||order.owner!==user.userId&&email(user.email)!==ownerEmail)throw fail('الطلب غير متاح.',404);
 const payment=sql.prepare('SELECT * FROM gumroad_payments WHERE order_id=?').get(order.id);if(!payment)throw fail('الطلب غير متاح.',404);
 if(payment.sale_id)return verifyPaymentSale(payment.sale_id);
 if(!payment.product_id)return publicPayment(order);
 const result=await provider('/sales?'+new URLSearchParams({product_id:payment.product_id}));const sales=result.sales||[];
 if(sales.length>1)throw fail('يحتاج الطلب إلى مراجعة المالك لتعدد عمليات الدفع.',409);
 if(sales.length)return verifyPaymentSale(sales[0].id);
 return publicPayment(order);
}
export async function paymentConnection(user){requirePaymentUser(user);if(email(user.email)!==ownerEmail)throw fail('Forbidden',403);const result=await provider('/products');return {connected:true,productsCount:result.products.length,enabled:gumroadStatus().enabled};}
export async function permanentlyDeleteOrder(user,input){
 requirePaymentUser(user);if(email(user.email)!==ownerEmail)throw fail('المالك فقط يستطيع حذف الطلبات نهائيًا.',403);
 if(!input||typeof input.id!=='string'||!input.id||input.id.length>100||typeof input.confirmNumber!=='string')throw fail('رقم الطلب وتأكيده مطلوبان.');
 const order=read(input.id);if(order?.kind!=='order')throw fail('الطلب غير موجود أو حُذف سابقًا.',404);
 if(input.confirmNumber!==order.number)throw fail('اكتب رقم الطلب كاملًا كما يظهر لتأكيد الحذف.');
 if(order.paymentMethod==='payment-link'&&order.status==='pending'&&order.paymentLink&&input.confirmExternalLinkClosed!==true)throw fail('أغلق رابط الدفع الخارجي لدى موفّره أولًا، ثم أكد إغلاقه قبل حذف الطلب.',409);
 if(deletingOrders.has(order.id)||checkoutFlights.has(order.id))throw fail('جارٍ تجهيز رابط هذا الطلب. انتظر قليلًا ثم حاول الحذف مجددًا.',409);
 limit('order:delete:'+user.userId,20,600);initGumroad();deletingOrders.add(order.id);
 try{
  const payment=sql.prepare('SELECT * FROM gumroad_payments WHERE order_id=?').get(order.id);
  if(order.paymentMethod==='gumroad'&&payment?.product_id){
   const result=await provider('/products/'+encodeURIComponent(payment.product_id)+'/disable','PUT');
   if(result.product?.id!==payment.product_id||result.product.published!==false)throw fail('تعذر تأكيد إغلاق رابط الدفع؛ لم يُحذف الطلب.',502);
  }else if(order.paymentMethod==='gumroad'&&order.paymentLink)throw fail('ربط خدمة الدفع غير مكتمل؛ تعذر إغلاق الرابط، ولم يُحذف الطلب.',409);
  return transaction(()=>{
   const current=read(order.id);if(current?.kind!=='order')throw fail('الطلب غير موجود أو حُذف سابقًا.',404);
   const latest=sql.prepare('SELECT * FROM gumroad_payments WHERE order_id=?').get(order.id);
   if((latest?.product_id||null)!==(payment?.product_id||null))throw fail('تغير رابط الدفع أثناء الفحص؛ أعد المحاولة.',409);
   write('deleted-order:'+current.id,'deleted-order',current.owner,deletionMarker(current));
   sql.prepare("DELETE FROM records WHERE id=? AND kind='order'").run(current.id);
   // Remove only this order's linked notifications, not other customer content.
   sql.prepare("DELETE FROM records WHERE kind='notification' AND json_extract(data,'$.order')=?").run(current.id);
   write(randomUUID(),'audit',user.userId,{action:'permanentDeleteOrder',target:current.id,date:date()});
   return {ok:true,deleted:current.id};
  });
 }finally{deletingOrders.delete(order.id);}
}
export function authenticateWebhook(value){const secret=process.env.GUMROAD_WEBHOOK_SECRET||'';if(secret.length<32||typeof value!=='string'||Buffer.byteLength(value)!==Buffer.byteLength(secret)||!timingSafeEqual(Buffer.from(value),Buffer.from(secret)))throw fail('Forbidden',403);initGumroad();limit('gumroad:webhook',120,60);}
export async function readPaymentBody(request){const length=Number(request.headers.get('content-length')||0);if(length>32768)throw fail('Request too large',413);const reader=request.body?.getReader();if(!reader)return {};let total=0,chunks=[];for(;;){const {value,done}=await reader.read();if(done)break;total+=value.length;if(total>32768){await reader.cancel();throw fail('Request too large',413);}chunks.push(value);}const body=Buffer.concat(chunks).toString('utf8');try{return request.headers.get('content-type')?.includes('application/json')?JSON.parse(body):Object.fromEntries(new URLSearchParams(body));}catch{throw fail('Invalid request body');}}
