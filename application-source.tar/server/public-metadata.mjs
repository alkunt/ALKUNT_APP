import {sql} from './runtime.mjs';
import {publiclyListed} from '../app/page-metadata.mjs';

export function publicProductMetadata(id) {
  if (typeof id !== 'string' || !id || id.length > 200) return null;
  const row = sql.prepare('SELECT data FROM records WHERE id=? AND kind=?').get(id, 'product');
  if (!row) return null;
  let product;
  try { product = JSON.parse(row.data); } catch { return null; }
  if (!publiclyListed(product)) return null;
  return Object.fromEntries(['type', 'status', 'publishAt', 'title_ar', 'title_en', 'desc_ar', 'desc_en', 'cover']
    .map(key => [key, product[key]]).concat([['id', id]]));
}
