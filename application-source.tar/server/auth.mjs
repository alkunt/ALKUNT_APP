import {randomBytes,scrypt as scryptCallback,timingSafeEqual,createHash} from 'node:crypto';
import {promisify} from 'node:util';
import {sql} from './runtime.mjs';
const scrypt=promisify(scryptCallback);
export const ownerEmail='alkunt@yahoo.com';
export const secure=process.env.COOKIE_SECURE!=='false';
export const cookieName=secure?'__Host-alkunt-session':'alkunt-session';
export function originAllowed(req){return !!process.env.APP_ORIGIN&&req.headers.get('origin')===process.env.APP_ORIGIN}
export function safeReturn(value){return typeof value==='string'&&value.startsWith('/')&&!value.startsWith('//')&&!value.includes('\\')&&!/[\u0000-\u0020\u007f]/.test(value)&&!/^\/(signin|signout|api\/auth)/.test(value)?value:'/'}
export async function passwordHash(password){const salt=randomBytes(16).toString('hex');const hash=await scrypt(password,salt,64);return salt+':'+hash.toString('hex')}
export async function passwordMatches(password,stored){const [salt,hex]=stored.split(':');const hash=await scrypt(password,salt,64);const target=Buffer.from(hex,'hex');return target.length===hash.length&&timingSafeEqual(hash,target)}
const digest=s=>createHash('sha256').update(s).digest('hex');
export function limit(key,max=8){const now=Date.now();sql.prepare('DELETE FROM auth_limits WHERE expires<?').run(now);const record=sql.prepare('SELECT * FROM auth_limits WHERE key=?').get(key);if(record&&record.count>=max)return false;sql.prepare('INSERT INTO auth_limits VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET count=count+1').run(key,1,now+15*60*1000);return true}
export function createSession(user,seconds=7*86400){const token=randomBytes(32).toString('base64url');sql.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());sql.prepare('INSERT INTO sessions VALUES(?,?,?)').run(digest(token),user,Date.now()+seconds*1000);return token}
export function sessionUser(token){if(!token||token.length>200)return null;const u=sql.prepare('SELECT a.id,a.email,a.name FROM accounts a JOIN sessions s ON s.user=a.id WHERE s.token=? AND s.expires>?').get(digest(token),Date.now());if(!u)return null;const p=sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+u.id);if(p&&JSON.parse(p.data).blocked)return null;return {userId:u.id,email:u.email,displayName:u.name,fullName:u.name}}
export function destroySession(token){if(token)sql.prepare('DELETE FROM sessions WHERE token=?').run(digest(token))}
export function sessionCookie(token,remove=false,seconds=7*86400){return `${cookieName}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${remove?0:seconds}${secure?'; Secure':''}`}
