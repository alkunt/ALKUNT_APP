import {generateKeyPairSync} from 'node:crypto';
const {privateKey,publicKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'});const pub=publicKey.export({format:'jwk'});const raw=Buffer.concat([Buffer.from([4]),Buffer.from(pub.x,'base64url'),Buffer.from(pub.y,'base64url')]);
console.log('VAPID_PUBLIC_KEY='+raw.toString('base64url'));
console.log('VAPID_PRIVATE_JWK='+JSON.stringify(privateKey.export({format:'jwk'})));
