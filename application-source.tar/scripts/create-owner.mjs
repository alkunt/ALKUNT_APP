import {createInterface} from 'node:readline/promises';
import {randomUUID} from 'node:crypto';
import {sql} from '../server/runtime.mjs';
import {passwordHash,ownerEmail} from '../server/auth.mjs';
if(!process.stdin.isTTY){console.error('Run interactively. Passwords must not be passed as command arguments.');process.exit(1)}
const rl=createInterface({input:process.stdin,output:process.stdout});
const email=process.argv.includes('--reset-user')?(await rl.question('Account email to reset: ')).trim().toLowerCase():ownerEmail;
let existing=sql.prepare('SELECT id FROM accounts WHERE email=?').get(email);
if(process.argv.includes('--reset-user')&&!existing)throw Error('Account not found');
console.log('Enter a new password (12–128 characters; input hidden):');
rl.close();process.stdin.setRawMode(true);process.stdin.resume();
const password=await new Promise((resolve,reject)=>{let value='';const onData=chunk=>{for(const char of chunk.toString()){if(char==='\u0003'){process.exit(130)}if(char==='\r'||char==='\n'){process.stdin.removeListener('data',onData);process.stdin.setRawMode(false);process.stdin.pause();resolve(value);return}if(char==='\u007f')value=value.slice(0,-1);else value+=char}};process.stdin.on('data',onData)});
if(password.length<12||password.length>128)throw Error('Password must contain 12–128 characters');
const id=existing?.id||randomUUID();const hash=await passwordHash(password);
sql.prepare('INSERT INTO accounts VALUES(?,?,?,?) ON CONFLICT(email) DO UPDATE SET password=excluded.password').run(id,email,email===ownerEmail?'ALKUNT Owner':email,hash);
sql.prepare('DELETE FROM sessions WHERE user=?').run(id);
console.log('\nAccount ready. Previous sessions were revoked.');sql.close();
