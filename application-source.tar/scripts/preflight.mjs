import {existsSync} from 'node:fs';
import path from 'node:path';
import {sql,dataDir} from '../server/runtime.mjs';
const issues=[];let origin;try{origin=new URL(process.env.APP_ORIGIN);if(origin.protocol!=='https:'||origin.origin!==process.env.APP_ORIGIN)issues.push('APP_ORIGIN must be an HTTPS origin without trailing slash')}catch{issues.push('Set APP_ORIGIN to your domain')}
if(process.env.COOKIE_SECURE==='false')issues.push('Secure cookies must be enabled in production');
if(!sql.prepare('SELECT id FROM accounts WHERE email=?').get('alkunt@yahoo.com'))issues.push('Create the owner account');
const record=sql.prepare('SELECT data FROM records WHERE id=?').get('settings');const settings=record?JSON.parse(record.data):{};
if(!settings.salesEnabled)issues.push('Sales are disabled');if(!settings.payment)issues.push('Manual transfer instructions are missing');
for(const key of ['privacy_ar','terms_ar'])if(!settings.pages?.[key])issues.push('Owner-approved policy text missing: '+key);
if(!process.env.VAPID_PUBLIC_KEY||!process.env.VAPID_PRIVATE_JWK)issues.push('Configure new VAPID keys for device notifications');
if(!sql.prepare("SELECT count(*) AS n FROM records WHERE kind='push-subscription'").get().n)issues.push('No owner device has subscribed to push notifications');
for(const r of sql.prepare("SELECT id FROM records WHERE kind='file'").all())if(!existsSync(path.join(dataDir,'uploads',r.id)))issues.push('Missing stored file: '+r.id);
console.log(JSON.stringify({ready:issues.length===0,issues,emailConfigured:!!(process.env.RESEND_API_KEY&&process.env.MAIL_FROM)},null,2));sql.close();process.exitCode=issues.length?1:0;
