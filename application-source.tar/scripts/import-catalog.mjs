import {readFileSync,existsSync,copyFileSync} from 'node:fs';
import path from 'node:path';
import {sql,dataDir} from '../server/runtime.mjs';
const file=process.argv[2],filesDir=process.argv[3];if(!file){console.error('Usage: node scripts/import-catalog.mjs dashboard-export.json [downloaded-files-directory]');process.exit(1)}
const backup=JSON.parse(readFileSync(file,'utf8'));if(!Array.isArray(backup.products))throw Error('Expected a dashboard JSON export');
const now=new Date().toISOString();let imported=0;const missing=[];
sql.exec('BEGIN IMMEDIATE');try{
for(const p of backup.products){if(!p.id||!/^[a-zA-Z0-9-]+$/.test(p.id)||!['course','book','prompt','bundle','blog','offer'].includes(p.type))throw Error('Invalid product');if(sql.prepare('SELECT id FROM records WHERE id=?').get(p.id))continue;const references=[p.cover?.startsWith('/api/files?id=')?p.cover.slice(14):null,p.file,...(p.lessons||[]).flatMap(l=>[l.file,/^[a-f0-9-]{36}$/.test(l.video||'')?l.video:null])].filter(Boolean);for(const id of references){if(!/^[a-zA-Z0-9-]+$/.test(id))throw Error('Invalid attachment id');const source=filesDir&&path.join(filesDir,id),meta=filesDir&&path.join(filesDir,id+'.json');if(!source||!existsSync(source)||!existsSync(meta)){missing.push({product:p.title_ar,productId:p.id,file:id});continue}const f=JSON.parse(readFileSync(meta,'utf8'));if(!['content','cover'].includes(f.purpose))throw Error('Invalid file purpose');if(!existsSync(path.join(dataDir,'uploads',id)))copyFileSync(source,path.join(dataDir,'uploads',id));sql.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').run(id,'file','',JSON.stringify(f),now)}
const product=missing.some(x=>x.productId===p.id)?{...p,status:'draft'}:p;
sql.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').run(p.id,'product','',JSON.stringify(product),now);imported++;
}
if(backup.settings)sql.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').run('settings','settings','',JSON.stringify({...backup.settings,salesEnabled:false}),now);
sql.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').run('seeded','system','',JSON.stringify({done:true}),now);
sql.exec('COMMIT');console.log(JSON.stringify({imported,missingFiles:missing,salesEnabled:false},null,2));
}catch(e){sql.exec('ROLLBACK');throw e}finally{sql.close()}
