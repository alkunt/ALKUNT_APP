const {DatabaseSync}=require('node:sqlite');const ts=require('typescript');const vm=require('node:vm');const fs=require('node:fs');const assert=require('node:assert/strict');
const sql=new DatabaseSync(':memory:');sql.exec("CREATE TABLE records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,owner TEXT NOT NULL DEFAULT '',data TEXT NOT NULL,created TEXT NOT NULL);CREATE TABLE grants(id TEXT PRIMARY KEY,user TEXT NOT NULL,product TEXT NOT NULL,source TEXT NOT NULL);");
let currentUser=null;const files=new Map();
const DB={prepare(query){let args=[];const self={bind(...a){args=a;return self},async first(){return sql.prepare(query).get(...args)||null},async all(){return{results:sql.prepare(query).all(...args)}},async run(){return sql.prepare(query).run(...args)}};return self},async batch(stmts){sql.exec('BEGIN');try{const result=[];for(const st of stmts)result.push(await st.run());sql.exec('COMMIT');return result}catch(e){sql.exec('ROLLBACK');throw e}}};
const env={DB,BUCKET:{async put(id,bytes,opt){files.set(id,{body:bytes,...opt})},async get(id){return files.get(id)},async delete(id){files.delete(id)}}};
function load(path){const js=ts.transpileModule(fs.readFileSync(path,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const module={exports:{}};vm.runInNewContext(js,{module,exports:module.exports,require(name){if(name==='cloudflare:workers'||name.endsWith('/runtime'))return {env};if(name.includes('chatgpt-auth'))return {getChatGPTUser:async()=>currentUser};if(name.includes('audience-notifications'))return load('app/audience-notifications.ts');if(name.includes('owner-notifications'))return {notifyOwner:async()=>({accepted:0,failed:0,email:'not-configured'})};if(name.includes('offer-registration'))return load('app/offer-registration.mjs');if(name.includes('link-rules'))return load('app/link-rules.ts');if(name.includes('rich-text'))return load('app/rich-text.mjs');if(name.includes('content-rules'))return load('app/content-rules.ts');if(name.includes('platform-data'))return load('app/platform-data.ts');throw Error(name)},Response,Request,URL,crypto,FormData,File,Uint8Array,Date,console,process:{env:{APP_ORIGIN:"https://example.test"}}});return module.exports}
const api=load('app/api/platform/route.ts'), fileapi=load('app/api/files/route.ts');const origin='https://example.test';const owner={userId:'owner',email:'alkunt@yahoo.com',displayName:'Owner'};const buyer={userId:'buyer',email:'buyer@example.test',displayName:'Buyer'};const other={userId:'other',email:'other@example.test',displayName:'Other'};
async function post(action,body={}){const r=await api.POST(new Request(origin+'/api/platform',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify({action,...body})}));return {status:r.status,...await r.json()}}
async function get(params=''){const r=await api.GET(new Request(origin+'/api/platform'+params));return {status:r.status,...await r.json()}}
(async()=>{
assert.equal((await post('settings',{settings:{}})).status,401);
currentUser=owner;assert.equal((await get()).products.length,3);
assert.equal((await post('settings',{settings:{currency:'KWD',tax:5,payment:'Test bank',salesEnabled:true}})).status,200);
for(const p of [{id:'paid',price:10},{id:'free',price:0}])assert.equal((await post('saveProduct',{product:{...p,type:'course',title_ar:'اختبار',status:'published',body_ar:'PROTECTED',file:'asset-1',lessons:[{id:'lesson1',title_ar:'درس',video:'asset-1'}]}})).status,200);
currentUser=buyer;assert.equal((await post('saveProduct',{product:{}})).status,403);assert.equal((await get('?product=paid')).status,403);assert.equal((await get()).products.find(p=>p.id==='paid').body_ar,'');assert.equal((await post('enroll',{id:'paid'})).status,400);assert.equal((await post('enroll',{id:'free'})).status,200);assert.equal((await get('?product=free')).product.body_ar,'PROTECTED');assert.equal((await post('progress',{product:'paid',lesson:'lesson1',completed:true})).status,403);assert.equal((await post('progress',{product:'free',lesson:'lesson1',completed:true,note:'test'})).status,200);
const f=new FormData();f.set('file',new File(['%PDF-1.4\nreceipt'],'receipt.pdf',{type:'application/pdf'}));f.set('purpose','receipt');const uploaded=await fileapi.POST(new Request(origin+'/api/files',{method:'POST',headers:{origin},body:f}));assert.equal(uploaded.status,200);const receipt=(await uploaded.json()).id;
const quote=await post('quote',{ids:['paid'],total:0});assert.equal(quote.total,10.5);assert.equal(quote.tax,0.5);
const order=await post('checkout',{ids:['paid','paid'],receipt,payer:'Buyer',total:0});assert.equal(order.status,200);let o=(await get()).orders[0];assert.equal(o.total,10.5);assert.equal(o.items.length,1);assert.equal((await get('?product=paid')).status,403);
currentUser=other;assert.equal((await get()).orders.length,0);assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+receipt))).status,403);assert.equal((await post('review',{id:order.id,status:'confirmed'})).status,403);
currentUser=owner;assert.equal((await post('review',{id:order.id,status:'confirmed'})).status,200);assert.equal((await post('review',{id:order.id,status:'confirmed'})).status,400);
currentUser=buyer;assert.equal((await get('?product=paid')).status,200);assert.equal((await post('checkout',{ids:['paid'],receipt})).status,400);
currentUser=owner;assert.equal((await post('review',{id:order.id,status:'refunded'})).status,200);
currentUser=buyer;assert.equal((await get('?product=paid')).status,403);
currentUser=owner;assert.equal((await post('coupon',{data:{id:'coupon-1',code:'SAVE',type:'percent',value:10,maxUses:1,active:true}})).status,200);currentUser=buyer;assert.equal((await post('quote',{ids:['paid'],coupon:'SAVE'})).total,9.45);assert.equal((await post('checkout',{ids:['paid'],coupon:'SAVE',receipt})).status,200);assert.equal((await post('quote',{ids:['paid'],coupon:'SAVE'})).status,400);
const cross=await api.POST(new Request(origin+'/api/platform',{method:'POST',headers:{origin:'https://evil.test','content-type':'application/json'},body:'{"action":"favorite"}'}));assert.equal(cross.status,403);
// Owner targeting changes preserve coupon usage and only discount matching products.
currentUser=owner;
assert.equal((await post('saveProduct',{product:{id:'coupon-other',type:'book',title_ar:'منتج آخر',price:5,status:'published'}})).status,200);
assert.equal((await post('coupon',{data:{id:'scoped-coupon',code:'SCOPED',type:'percent',value:20,active:true,products:['paid']}})).status,200);
currentUser=buyer;
let scopedQuote=await post('quote',{ids:['paid','coupon-other'],coupon:'SCOPED'});assert.equal(scopedQuote.discount,2);assert.equal(scopedQuote.total,13.65);
assert.equal((await post('quote',{ids:['coupon-other'],coupon:'SCOPED'})).discount,0);
assert.equal((await post('coupon',{data:{id:'scoped-coupon',code:'SCOPED',type:'percent',value:20,active:true,products:[]}})).status,403);
currentUser=owner;
let scopedRecord=(await get()).coupons.find(c=>c.id==='scoped-coupon');assert.deepEqual(Array.from(scopedRecord.products),['paid']);
sql.prepare('UPDATE records SET data=? WHERE id=?').run(JSON.stringify({...scopedRecord,used:3}),'scoped-coupon');
assert.equal((await post('coupon',{data:{...scopedRecord,used:0,active:false,products:['paid','coupon-other']}})).status,200);
scopedRecord=(await get()).coupons.find(c=>c.id==='scoped-coupon');assert.equal(scopedRecord.used,3);assert.equal(scopedRecord.active,false);assert.deepEqual(Array.from(scopedRecord.products),['paid','coupon-other']);
assert.equal((await post('coupon',{data:{...scopedRecord,active:true,products:[]}})).status,200);
currentUser=buyer;scopedQuote=await post('quote',{ids:['paid','coupon-other'],coupon:'SCOPED'});assert.equal(scopedQuote.discount,3);assert.equal(scopedQuote.total,12.6);
// Coupon deletion is owner-only and never removes purchase or usage history.
currentUser=owner;
assert.equal((await post('coupon',{data:{id:'keep-coupon',code:'KEEP',type:'fixed',value:1,active:true}})).status,200);
const usedCoupon=(await get()).coupons.find(c=>c.id==='coupon-1');
assert.equal(usedCoupon.used,1);
assert.equal((await post('coupon',{data:{...usedCoupon,active:false,expires:'2000-01-01'}})).status,200);
const historicalRows=()=>JSON.stringify({records:sql.prepare("SELECT * FROM records WHERE kind IN ('order','coupon-use','product') ORDER BY id").all(),grants:sql.prepare('SELECT * FROM grants ORDER BY id').all()});
const historyBeforeCouponDelete=historicalRows(),keptCouponBefore=sql.prepare('SELECT * FROM records WHERE id=?').get('keep-coupon');
currentUser=null;assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'SAVE'})).status,401);
currentUser=buyer;assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'SAVE'})).status,403);
const otherProfileBefore=sql.prepare('SELECT * FROM records WHERE id=?').get('profile:other');
for(const role of ['editor','support','admin']){sql.prepare('UPDATE records SET data=? WHERE id=?').run(JSON.stringify({...JSON.parse(otherProfileBefore.data),role}),'profile:other');currentUser=other;assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'SAVE'})).status,403);}
sql.prepare('UPDATE records SET data=? WHERE id=?').run(otherProfileBefore.data,'profile:other');currentUser=owner;
assert.equal((await post('deleteCoupon',{id:'paid',confirmCode:'SAVE'})).status,404);
assert.equal((await post('deleteCoupon',{id:'missing-coupon',confirmCode:'SAVE'})).status,404);
assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'WRONG'})).status,400);
const crossDelete=await api.POST(new Request(origin+'/api/platform',{method:'POST',headers:{origin:'https://evil.test','content-type':'application/json'},body:JSON.stringify({action:'deleteCoupon',id:'coupon-1',confirmCode:'SAVE'})}));assert.equal(crossDelete.status,403);
assert.ok((await get()).coupons.some(c=>c.id==='coupon-1'));
assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'SAVE'})).deleted,'coupon-1');
assert.equal((await post('deleteCoupon',{id:'scoped-coupon',confirmCode:'SCOPED'})).status,200);
assert.deepEqual(Array.from((await get()).coupons,c=>c.id),['keep-coupon']);
assert.equal(historicalRows(),historyBeforeCouponDelete);
assert.deepEqual(sql.prepare('SELECT * FROM records WHERE id=?').get('keep-coupon'),keptCouponBefore);
const deletedCoupon=JSON.parse(sql.prepare("SELECT data FROM records WHERE id='deleted-coupon:coupon-1' AND kind='deleted-coupon'").get().data);assert.equal(deletedCoupon.coupon.used,1);assert.equal(deletedCoupon.coupon.code,'SAVE');
assert.equal(sql.prepare("SELECT count(*) n FROM records WHERE kind='audit' AND json_extract(data,'$.action')='deleteCoupon'").get().n,2);
assert.equal((await post('coupon',{data:usedCoupon})).status,409);
assert.equal((await post('deleteCoupon',{id:'coupon-1',confirmCode:'SAVE'})).status,404);
currentUser=buyer;assert.equal((await post('quote',{ids:['paid'],coupon:'SAVE'})).status,400);assert.equal((await post('quote',{ids:['paid'],coupon:'SCOPED'})).status,400);
// Prompt detail, upload and moderation regression tests.
currentUser=owner;
const cf=new FormData();cf.set('file',new File([new Uint8Array([137,80,78,71,13,10,26,10,0,0,0,0])],'cover.png',{type:'image/png'}));cf.set('purpose','cover');
const coverResponse=await fileapi.POST(new Request(origin+'/api/files',{method:'POST',headers:{origin},body:cf}));assert.equal(coverResponse.status,200);const coverId=(await coverResponse.json()).id;
const freePrompt={id:'prompt-free',type:'prompt',title_ar:'أمر مجاني',price:0,status:'published',cover:'/api/files?id='+coverId,body_ar:'FREE BODY',extended_ar:'FREE EXTENDED',instructions_ar:'FREE INSTRUCTIONS',tools:['ChatGPT'],about_ar:'About',reviewsEnabled:true};
assert.equal((await post('saveProduct',{product:freePrompt})).status,200);
assert.equal((await post('saveProduct',{product:{...freePrompt,id:'prompt-premium',price:0,inBundle:true,cover:'',body_ar:'SECRET BODY',extended_ar:'SECRET EXTENDED',instructions_ar:'SECRET INSTRUCTIONS'}})).status,200);
currentUser=null;
assert.equal((await get('?product=prompt-free')).product.extended_ar,'FREE EXTENDED');assert.equal((await get('?product=prompt-premium')).status,403);
const catalog=await get();const premium=catalog.products.find(p=>p.id==='prompt-premium');assert.equal(premium.extended_ar,'');assert.equal(premium.instructions_ar,'');assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+coverId))).status,200);
assert.equal((await post('submitReview',{product:'prompt-free',rating:5,comment:'Review'})).status,401);
currentUser=buyer;assert.equal((await post('submitReview',{product:'prompt-free',rating:5,comment:'Useful prompt'})).status,200);assert.equal((await get('?reviews=prompt-free')).reviews.length,0);
assert.equal((await post('moderateReview',{id:'review:buyer:prompt-free',status:'approved'})).status,403);
currentUser=owner;assert.equal((await post('moderateReview',{id:'review:buyer:prompt-free',status:'approved'})).status,200);
currentUser=null;assert.equal((await get('?reviews=prompt-free')).reviews[0].comment,'Useful prompt');
currentUser=owner;assert.equal((await post('saveProduct',{product:{...freePrompt,status:'draft'}})).status,200);
currentUser=null;assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+coverId))).status,401);assert.equal((await get('?product=prompt-free')).status,404);
currentUser=buyer;const forbiddenCover=new FormData();forbiddenCover.set('file',new File(['test'],'test.txt'));forbiddenCover.set('purpose','cover');assert.equal((await fileapi.POST(new Request(origin+'/api/files',{method:'POST',headers:{origin},body:forbiddenCover}))).status,403);
currentUser=owner;const attachment=new FormData();attachment.set('file',new File(['untrusted text'],'document.docx',{type:'application/vnd.openxmlformats-officedocument.wordprocessingml.document'}));attachment.set('purpose','content');const attachmentResponse=await fileapi.POST(new Request(origin+'/api/files',{method:'POST',headers:{origin},body:attachment}));assert.equal(attachmentResponse.status,200);const attachmentId=(await attachmentResponse.json()).id;const download=await fileapi.GET(new Request(origin+'/api/files?id='+attachmentId));assert.match(download.headers.get('Content-Disposition'),/^attachment;/);
// Permanent-delete cascade, wrong confirmation, authorization and publication regressions.
currentUser=owner;const publish=await post('saveProduct',{product:{id:'delete-course',type:'course',title_ar:'حذف الدورة',price:0,status:'published',file:attachmentId,lessons:[]}});assert.equal(publish.id,'delete-course');assert.equal(publish.status,200);
const lib=load('app/catalog-rules.ts');assert.equal(lib.visibleInLibrary({id:'delete-course'},[],true),true);assert.equal(lib.visibleInLibrary({id:'delete-course'},[],false),false);assert.equal(lib.visibleInLibrary({id:'x',type:'prompt'},['prompt-bundle'],false),true);
currentUser=buyer;assert.equal((await post('enroll',{id:'delete-course'})).status,200);await post('favorite',{id:'delete-course'});await post('cart',{ids:['delete-course']});await post('submitReview',{product:'delete-course',rating:5,comment:'Remove with course'});
assert.equal((await post('permanentDeleteProduct',{id:'delete-course',confirmTitle:'حذف الدورة'})).status,403);
currentUser=owner;assert.equal((await post('permanentDeleteProduct',{id:'delete-course',confirmTitle:'wrong'})).status,400);assert.equal((await get('?product=delete-course')).status,200);
assert.equal((await post('permanentDeleteProduct',{id:'delete-course',confirmTitle:'حذف الدورة'})).status,200);assert.equal(files.has(attachmentId),false);assert.equal((await get('?product=delete-course')).status,404);
assert.equal((await post('saveProduct',{product:{id:'delete-course',type:'course',title_ar:'resurrection',price:0,status:'published'}})).status,409);
currentUser=buyer;const cleaned=await get();assert.equal(cleaned.owned.includes('delete-course'),false);assert.equal(cleaned.favorites.includes('delete-course'),false);assert.equal(cleaned.cart.includes('delete-course'),false);
currentUser=owner;
for(const type of ['book','prompt','bundle','blog']){const id='remove-'+type;assert.equal((await post('saveProduct',{product:{id,type,title_ar:type,price:0,status:'published'}})).status,200);assert.equal((await post('deleteProduct',{id})).status,200);assert.equal((await get()).products.some(p=>p.id===id&&p.status==='archived'),true);assert.equal((await post('permanentDeleteProduct',{id,confirmTitle:type})).status,200);assert.equal((await get()).products.some(p=>p.id===id),false);}
// Shared cover remains while a second product references it.
await post('saveProduct',{product:{id:'shared-a',type:'book',title_ar:'A',price:0,status:'published',cover:'/api/files?id='+coverId}});await post('saveProduct',{product:{id:'shared-b',type:'book',title_ar:'B',price:0,status:'published',cover:'/api/files?id='+coverId}});
assert.equal((await post('permanentDeleteProduct',{id:'shared-a',confirmTitle:'A'})).status,200);assert.equal(files.has(coverId),true);
assert.ok(sql.prepare("SELECT count(*) AS n FROM records WHERE kind='order'").get().n>0);
const links=load('app/link-rules.ts');assert.equal(links.externalUrl('javascript:alert(1)'),'');assert.equal(links.externalUrl('https://user:pass@example.com'),'');assert.equal(links.externalUrl('https://example.com/path'),'https://example.com/path');assert.equal((await post('saveProduct',{product:{id:'bad-link',type:'prompt',title_ar:'bad',price:0,status:'published',externalUrl:'javascript:alert(1)'}})).status,400);
const contactApi=load('app/api/contact/route.ts');const contactReq=(body)=>new Request(origin+'/api/contact',{method:'POST',headers:{origin,'content-type':'application/json'},body:JSON.stringify(body)});
currentUser=null;assert.equal((await contactApi.POST(contactReq({}))).status,401);currentUser=buyer;assert.equal((await contactApi.POST(contactReq({name:'Person',email:'invalid',subject:'Question',message:'A sufficiently long message'}))).status,400);const sent=await contactApi.POST(contactReq({name:'Person',email:'test@example.com',subject:'Question',message:'A sufficiently long message'}));assert.equal(sent.status,200);assert.equal((await sent.json()).emailStatus,'not-configured');assert.equal((await get()).contacts.length,1);currentUser=other;assert.equal((await get()).contacts.length,0);currentUser=owner;assert.equal((await get()).contacts.length,1);
const contact=(await get()).contacts[0];currentUser=buyer;assert.equal((await post('replyContact',{id:contact.id,message:'Unauthorized reply'})).status,403);currentUser=owner;assert.equal((await post('replyContact',{id:contact.id,message:'Private support reply'})).status,200);currentUser=buyer;assert.equal((await get()).contacts[0].replies[0].message,'Private support reply');assert.ok((await get()).notifications.some(n=>n.title.includes('رد جديد')));currentUser=other;assert.equal((await get()).contacts.length,0);assert.equal((await get()).notifications.some(n=>n.title.includes('رد جديد')),false);currentUser=null;assert.equal((await get()).notifications.some(n=>n.title.includes('رد جديد')),false);
// Paid articles must follow the same protected purchase flow as other products.
currentUser=owner;
assert.equal((await post('saveProduct',{product:{id:'paid-article',type:'blog',title_ar:'مقال مدفوع',title_en:'Paid article',price:8,status:'published',body_ar:'مقال',body_en:'Article',extended_ar:'الأمر العربي',extended_en:'English prompt'}})).status,200);
currentUser=null;
assert.equal((await get('?product=paid-article')).status,403);
const articlePreview=(await get()).products.find(p=>p.id==='paid-article');
assert.equal(articlePreview.extended_ar,'');assert.equal(articlePreview.extended_en,'');
currentUser=buyer;
assert.equal((await post('quote',{ids:['paid-article']})).total,8.4);
const articleOrder=await post('checkout',{ids:['paid-article'],receipt,payer:'Buyer'});assert.equal(articleOrder.status,200);
currentUser=owner;assert.equal((await post('review',{id:articleOrder.id,status:'confirmed'})).status,200);
currentUser=buyer;const fullArticle=(await get('?product=paid-article')).product;
assert.equal(fullArticle.extended_ar,'الأمر العربي');assert.equal(fullArticle.extended_en,'English prompt');
// Kuwait link request: no receipt, restricted link delivery, no premature activation.
currentUser=owner;await post('saveProduct',{product:{id:'kuwait-product',type:'book',title_ar:'كويت',price:6,status:'published'}});
currentUser=buyer;assert.equal((await post('checkout',{ids:['kuwait-product'],country:'KW',payer:'Buyer'})).status,400);
const localOrder=await post('checkout',{ids:['kuwait-product'],country:'KW',payer:'Buyer',phone:'+96512345678'});assert.equal(localOrder.status,200);
assert.equal((await get('?product=kuwait-product')).status,403);
assert.equal((await post('paymentLink',{id:localOrder.id,url:'https://pay.example.test/order'})).status,403);
currentUser=owner;assert.equal((await post('review',{id:localOrder.id,status:'confirmed'})).status,400);
assert.equal((await post('paymentLink',{id:localOrder.id,url:'javascript:alert(1)'})).status,400);
assert.equal((await post('paymentLink',{id:localOrder.id,url:'https://pay.example.test/order'})).status,200);
currentUser=other;assert.equal((await get()).orders.some(o=>o.id===localOrder.id),false);
currentUser=buyer;const localSaved=(await get()).orders.find(o=>o.id===localOrder.id);assert.equal(localSaved.receipt,'');assert.equal(localSaved.paymentStage,'awaiting-payment');assert.equal(localSaved.paymentLink,'https://pay.example.test/order');assert.equal((await get('?product=kuwait-product')).status,403);
currentUser=owner;assert.equal((await post('review',{id:localOrder.id,status:'confirmed'})).status,200);
currentUser=buyer;assert.equal((await get('?product=kuwait-product')).status,200);
assert.equal((await post('checkout',{ids:['paid'],country:'OTHER'})).status,400);
currentUser=owner;assert.equal((await post('saveProduct',{product:{id:'standalone-offer',type:'offer',title_ar:'عرض',title_en:'Offer',price:4,status:'published',file:'offer-file'}})).status,200);
const existingSettings=(await get()).settings;assert.equal((await post('settings',{settings:{...existingSettings,pages:{about_ar:'نبذة اختبار',about_en:'Test about'},faqs:[{question_ar:'سؤال',answer_ar:'إجابة',question_en:'Question',answer_en:'Answer'}]}})).status,200);
currentUser=buyer;assert.equal((await get()).products.find(p=>p.id==='standalone-offer').type,'offer');assert.equal((await get('?product=standalone-offer')).status,403);assert.equal((await post('quote',{ids:['standalone-offer']})).total,4.2);assert.equal((await get()).settings.pages.about_en,'Test about');assert.equal((await get()).settings.faqs[0].answer_ar,'إجابة');
// Library removal is account-scoped and preserves products, entitlements and files.
currentUser=buyer;assert.equal((await post('libraryVisibility',{id:'paid-article',hidden:true})).status,200);assert.equal((await get()).hiddenLibrary.includes('paid-article'),true);assert.equal((await get()).owned.includes('paid-article'),true);assert.equal((await get('?product=paid-article')).product.body_en,'Article');
currentUser=owner;assert.equal((await get()).hiddenLibrary.includes('paid-article'),false);assert.equal((await get()).products.some(p=>p.id==='paid-article'),true);
currentUser=buyer;assert.equal((await post('libraryVisibility',{id:'paid-article',hidden:false})).status,200);assert.equal((await get()).hiddenLibrary.includes('paid-article'),false);
// Recovery only restores the exact incident's original seed records, once.
sql.prepare("DELETE FROM records WHERE id=?").run('repair:library-delete-20261018');
sql.prepare("DELETE FROM records WHERE id=?").run('course-lazy');
sql.prepare("INSERT OR REPLACE INTO records VALUES(?,?,?,?,?)").run('deleted-product:course-lazy','deleted-product','',JSON.stringify({deletedAt:'2026-10-18T03:37:15.536Z'}),'2026-10-18T03:37:15.536Z');
currentUser=owner;const restored=(await get()).products.find(p=>p.id==='course-lazy');assert.equal(restored.title_ar,'الذكاء الاصطناعي الكسول');assert.equal(restored.status,'coming');assert.equal(sql.prepare("SELECT id FROM records WHERE id=?").get('deleted-product:course-lazy'),undefined);
assert.equal((await post('permanentDeleteProduct',{id:'course-lazy',confirmTitle:restored.title_ar})).status,200);assert.equal((await get()).products.some(p=>p.id==='course-lazy'),false);
// Final audit: malformed requests and stale quoted prices must not create orders.
currentUser=buyer;assert.equal((await post('quote',{})).status,400);assert.equal((await post('quote',{ids:['standalone-offer'],coupon:12})).status,400);assert.equal((await post('checkout',{ids:['standalone-offer'],country:'KW',payer:'Buyer',phone:'+96512345678',expectedTotal:0})).status,409);
currentUser=owner;const previewUpload=new FormData();previewUpload.set('file',new File(['%PDF-1.4 preview'],'preview.pdf'));previewUpload.set('purpose','content');const pr=await fileapi.POST(new Request(origin+'/api/files',{method:'POST',headers:{origin},body:previewUpload}));const previewId=(await pr.json()).id;
await post('saveProduct',{product:{id:'preview-course',type:'course',title_ar:'Preview',price:5,status:'published',lessons:[{id:'preview',preview:true,file:previewId}]}});
currentUser=null;assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+previewId))).status,200);
currentUser=owner;await post('saveProduct',{product:{id:'preview-course',type:'course',title_ar:'Preview',price:5,status:'draft',lessons:[{id:'preview',preview:true,file:previewId}]}});
currentUser=null;assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+previewId))).status,401);
currentUser=owner;await post('saveProduct',{product:{id:'bundle-file-prompt',type:'prompt',title_ar:'Bundle prompt',price:0,inBundle:true,status:'published',file:previewId}});await post('saveProduct',{product:{id:'prompt-bundle',type:'bundle',title_ar:'Bundle',price:9,status:'published'}});await post('grant',{user:buyer.userId,product:'prompt-bundle'});
currentUser=buyer;assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+previewId))).status,200);
currentUser=other;assert.equal((await fileapi.GET(new Request(origin+'/api/files?id='+previewId))).status,403);
currentUser=owner;await post('userRole',{id:'profile:buyer',role:'customer',blocked:true});currentUser=buyer;assert.equal((await contactApi.POST(contactReq({name:'Blocked',email:'test@example.com',subject:'Test',message:'Blocked account message'}))).status,403);currentUser=owner;await post('userRole',{id:'profile:buyer',role:'customer',blocked:false});
const stamp='2026-10-21T12:30:00.000Z';sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('purchase-library-check','order','other',JSON.stringify({status:'confirmed',items:[{id:'library-owned-check',title_ar:'منتج مشترى'}],date:stamp,timeline:[{status:'confirmed',date:stamp}],buyer:{name:'Buyer snapshot',country:'Kuwait',phone:'+965 55551234',email:'other@example.test'}}),stamp);sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('library-grant-check','other','library-owned-check','purchase-library-check');sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('library-free-check','other','library-free-only','free');currentUser=other;let libraryCheck=await get();assert.ok(libraryCheck.purchased.includes('library-owned-check'));assert.equal(libraryCheck.purchased.includes('library-free-only'),false);assert.equal(libraryCheck.purchaseHistory.length,0);currentUser=owner;const purchaseRow=(await get()).purchaseHistory.find(r=>r.productId==='library-owned-check');assert.equal(purchaseRow.name,'Buyer snapshot');assert.equal(purchaseRow.phone,'+965 55551234');assert.equal(purchaseRow.date,stamp);currentUser=null;assert.equal((await get()).purchaseHistory.length,0);sql.prepare('DELETE FROM grants WHERE id IN (?,?)').run('library-grant-check','library-free-check');sql.prepare('DELETE FROM records WHERE id=?').run('purchase-library-check');console.log('PASS: purchased-only library, excluded free access, private owner purchase history and buyer snapshots.');
console.log('PASS: invalid cart validation, changed-total protection, published lesson preview access, bundle attachments and blocked contact submissions.');
console.log('PASS: independent account library removal, preserved access/catalog, restore visibility, exact one-time course recovery.');
console.log('PASS: standalone offer publishing and pricing, protected file, bilingual About and FAQ persistence.');
console.log('PASS: Kuwait link request, owner-only HTTPS link delivery, customer isolation, manual receipt required and activation only after payment confirmation.');
console.log('PASS: paid article protection, quote, purchase, grant and bilingual prompt persistence.');
console.log('PASS: safe external links, contact validation, authenticated inbox delivery and owner-only contact access.');
console.log('PASS: explicit publish response, manager library visibility, all five deletion types, archive access, confirmation/role checks, cascade cleanup, shared-file preservation and stale-save prevention.');
console.log('PASS: free/premium prompt details, sensitive-field isolation, cover upload and public visibility, draft cover restriction, moderation and arbitrary safe-download attachments.');
console.log('PASS: authentication, authorization, content protection, receipt ownership, server pricing, unique items, enrollment, progress, approval, refund and CSRF checks.');
currentUser=owner;await post('saveProduct',{product:{id:'broadcast-check',type:'book',title_ar:'اختبار إشعار عام',price:0,status:'draft'}});currentUser=null;assert.equal((await get()).notifications.some(n=>n.product==='broadcast-check'),false);currentUser=owner;await post('saveProduct',{product:{id:'broadcast-check',type:'book',title_ar:'اختبار إشعار عام',price:0,status:'published'}});await post('saveProduct',{product:{id:'broadcast-check',type:'book',title_ar:'اختبار إشعار عام',price:0,status:'published'}});currentUser=null;assert.equal((await get()).notifications.filter(n=>n.product==='broadcast-check').length,1);currentUser=owner;await post('deleteProduct',{id:'broadcast-check'});currentUser=null;assert.equal((await get()).notifications.some(n=>n.product==='broadcast-check'),false);console.log('PASS: published-only public announcements, no duplicate alerts, private contact replies and recipient isolation.');

// Removing order details preserves confirmed purchases in the customer library.
currentUser=owner;await post('saveProduct',{product:{id:'deleted-order-library',type:'book',title_ar:'Preserved purchase',price:15,status:'published'}});
sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('deleted-order:removed-order','deleted-order','buyer',JSON.stringify({deletedAt:new Date().toISOString(),status:'confirmed',items:[{id:'deleted-order-library'}]}),new Date().toISOString());
sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('deleted-library-grant','buyer','deleted-order-library','removed-order');
currentUser=buyer;assert.ok((await get()).purchased.includes('deleted-order-library'));assert.ok((await get()).owned.includes('deleted-order-library'));assert.equal((await get('?product=deleted-order-library')).status,200);assert.ok(!(await get()).orders.some(o=>o.id==='removed-order'));
currentUser=other;assert.ok(!(await get()).purchased.includes('deleted-order-library'));currentUser=owner;assert.ok(!(await get()).purchaseHistory.some(o=>o.orderId==='removed-order'));
console.log('PASS: deleted order details stay absent while confirmed customer library access and account isolation remain intact.');

currentUser=owner;
const eventOffer={id:'in-person-event',type:'offer',title_ar:'دورة حضورية',price:80,status:'published',registrationMode:'email',registrationEmail:'alkunt@yahoo.com',body_ar:'PUBLIC_EVENT_DETAILS',lessons:[]};
assert.equal((await post('saveProduct',{product:eventOffer})).status,200);
for(const extra of [{registrationEmail:'bad'},{file:'asset-1'},{externalUrl:'https://example.test'}])assert.equal((await post('saveProduct',{product:{...eventOffer,id:'invalid-event',...extra}})).status,400);
currentUser=null;
const publicEvent=(await get('?product=in-person-event')).product;
assert.equal(publicEvent.body_ar,'PUBLIC_EVENT_DETAILS');assert.equal(publicEvent.price,80);assert.equal(publicEvent.file,'');
assert.equal((await get()).products.find(p=>p.id===eventOffer.id).body_ar,'PUBLIC_EVENT_DETAILS');
assert.equal((await get('?product=paid')).status,403);
currentUser=buyer;
assert.equal((await post('quote',{ids:[eventOffer.id]})).status,400);
assert.equal((await post('checkout',{ids:[eventOffer.id],country:'KW',payer:'Buyer',phone:'+965 50000000'})).status,400);
assert.equal((await post('enroll',{id:eventOffer.id})).status,400);
currentUser=owner;
await post('saveProduct',{product:{...eventOffer,status:'draft'}});currentUser=null;
assert.equal((await get('?product=in-person-event')).status,404);
console.log('PASS: public course announcements, invalid registration rejection and digital checkout/enrollment isolation.');
})().catch(e=>{console.error(e);process.exit(1)});
