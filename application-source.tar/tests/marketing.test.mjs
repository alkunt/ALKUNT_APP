import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';

// All provider calls are intercepted. This suite must never send a real email.
const directory=mkdtempSync(path.join(tmpdir(),'alkunt-marketing-'));
process.env.DATA_DIR=directory;
process.env.APP_ORIGIN='https://example.test';
process.env.BREVO_API_KEY='test-only-not-a-real-key';
process.env.MAIL_FROM='newsletter@example.test';
const {sql}=await import('../server/runtime.mjs');
const m=await import('../server/marketing.mjs');
const {emailTemplate,safeEmailUrl}=await import('../app/marketing-template.mjs');
const {parseMarketingCsv}=await import('../app/marketing-csv.mjs');
const {readMarketingBody}=await import('../server/marketing-http.mjs');
const owner={userId:'owner',email:'alkunt@yahoo.com',displayName:'Owner'};
const buyer={userId:'buyer',email:'buyer@example.test',displayName:'Buyer'};
const visitor={userId:'visitor',email:'visitor@example.test',displayName:'Visitor'};
const fakeAdmin={userId:'admin',email:'admin@example.test',role:'admin'};
const requests=[],providerCampaigns=new Map(),providerContacts=new Map();
let counter=100,sendCalls=0,testCalls=0,intercept=null;
const originalFetch=globalThis.fetch;
const json=(data,status=200)=>new Response(status===204?null:JSON.stringify(data),{status,headers:{'content-type':'application/json'}});
globalThis.fetch=async(url,options={})=>{
 const u=new URL(url);assert.equal(u.origin,'https://api.brevo.com','Unexpected external network request');
 assert.equal(options.headers['api-key'],'test-only-not-a-real-key');
 assert.equal(options.redirect,'error');assert.ok(options.signal);
 const method=options.method||'GET',route=u.pathname.replace('/v3/',''),body=options.body?JSON.parse(options.body):undefined;
 requests.push({route,method,body});
 if(intercept){const result=await intercept({route,method,body});if(result)return result;}
 if(route==='account')return json({email:'private-account-email',plan:[{type:'free',credits:300,creditsType:'sendLimit'}],apiKey:'never-return-this'});
 if(route==='contacts/folders')return method==='GET'?json({folders:[{id:1,name:'ALKUNT App'}]}):json({id:1},201);
 if(route==='contacts/lists'&&method==='POST')return json({id:++counter},201);
 if(/^contacts\/lists\/\d+\/contacts\/remove$/.test(route))return json({},201);
 if(route==='contacts'&&method==='POST'){
  assert.equal(body.emailBlacklisted,undefined,'Audience sync must not restore an opt-out');
  assert.equal(body.smtpBlacklistSender,undefined,'Marketing must not change transactional mail');
  const old=providerContacts.get(body.email)||{};providerContacts.set(body.email,{...old,...body});return json({id:++counter},201);
 }
 if(route.startsWith('contacts/')){
  const email=decodeURIComponent(route.slice(9)),contact=providerContacts.get(email);
  if(!contact)return json({code:'document_not_found'},404);
  if(method==='PUT'){providerContacts.set(email,{...contact,...body});return json(null,204);}
  return json(contact);
 }
 if(route==='emailCampaigns'){
  if(method==='GET')return json({campaigns:[...providerCampaigns.values()]});
  assert.equal(body.scheduledAt,undefined);assert.match(body.htmlContent,/\{\{ unsubscribe \}\}/);
  const id=++counter;providerCampaigns.set(id,{...body,id,status:'draft'});return json({id},201);
 }
 const match=route.match(/^emailCampaigns\/(\d+)(?:\/(sendNow|sendTest|status))?$/);
 if(match){
  const id=Number(match[1]),campaign=providerCampaigns.get(id);assert.ok(campaign,'Unknown provider campaign');
  if(match[2]==='sendTest'){testCalls++;assert.deepEqual(body.emailTo,[owner.email]);return json(null,204);}
  if(match[2]==='sendNow'){sendCalls++;campaign.status='queued';return json(null,204);}
  if(match[2]==='status'){assert.equal(body.status,'suspended');campaign.status='suspended';return json(null,204);}
  if(method==='GET')return json(campaign);
  Object.assign(campaign,body);if(body.scheduledAt)campaign.status='scheduled';return json(null,204);
 }
 throw Error('Unmocked provider path: '+method+' '+route);
};
const draft=(extra={})=>({name:'Useful learning updates',subject:'Your next chapter',preheader:'New resources',headline:'Learn something useful',body:'A helpful message about our latest learning resources.',language:'ar',audience:'subscribers',buttonLabel:'Explore',buttonUrl:'https://example.test/?view=book',...extra});
let passed=0;
async function check(name,run){sql.prepare("DELETE FROM auth_limits WHERE key LIKE 'marketing:%'").run();intercept=null;await run();passed++;console.log('PASS: '+name);}
const fresh=extra=>m.saveCampaign(draft(extra),owner);
const tested=async extra=>{const c=fresh(extra);return m.testCampaign(c.id,c.version,owner);};

try{
 m.initMarketing();
 for(const u of [owner,buyer,visitor,fakeAdmin,{userId:'blocked',email:'blocked@example.test',displayName:'Blocked'}])sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run(u.userId,u.email,u.displayName||'Admin','unchanged-password-hash');
 sql.prepare("UPDATE records SET data=json_set(data,'$.country','Kuwait') WHERE id='profile:buyer'").run();
 sql.prepare("UPDATE records SET data=json_set(data,'$.blocked',json('true')) WHERE id='profile:blocked'").run();
 sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('order-confirmed','order','buyer',JSON.stringify({status:'confirmed',items:['book']}),new Date().toISOString());
 sql.prepare('INSERT INTO records VALUES(?,?,?,?,?)').run('order-pending','order','visitor',JSON.stringify({status:'pending'}),new Date().toISOString());
 sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('old-grant','visitor','free-product','viewed');
 const beforeAccounts=sql.prepare('SELECT * FROM accounts ORDER BY id').all(),beforeOrders=sql.prepare("SELECT * FROM records WHERE kind='order' ORDER BY id").all(),beforeGrants=sql.prepare('SELECT * FROM grants').all();

 await check('only the actual owner can manage campaigns, including when another user has the admin role',async()=>{
  assert.throws(()=>m.requireOwner(null),{status:401});assert.throws(()=>m.saveCampaign(draft(),fakeAdmin),{status:403});
  assert.throws(()=>m.importContacts([],true,'source',buyer),{status:403});assert.doesNotThrow(()=>m.requireOwner({...owner,email:'ALKUNT@YAHOO.COM'}));
 });
 await check('registered users and viewed/free grants are not silently added to marketing',async()=>{
  assert.equal(m.audience(draft()).length,0);assert.equal(m.subscription(buyer).subscribed,false);
  assert.equal(m.contacts().find(c=>c.email===buyer.email).buyer,true);assert.equal(m.contacts().find(c=>c.email===visitor.email).buyer,false);
 });
 await check('CSV consent is required; invalid addresses and duplicate or opted-out imports are skipped',async()=>{
  assert.throws(()=>m.importContacts([{email:buyer.email}],false,'Consent form',owner),{status:400});
  await m.setSubscription(visitor,false,false);
  const result=m.importContacts([{email:buyer.email.toUpperCase(),name:'Buyer'},{email:buyer.email},{email:visitor.email},{email:'bad'},null,{email:'blocked@example.test'},{email:'external@example.test',country:'UAE'}],true,'Existing newsletter consent',owner);
  assert.deepEqual(result,{added:3,skipped:2,invalid:2});
  assert.equal(m.subscription(visitor).subscribed,false);assert.equal(m.audience(draft()).length,2);
  assert.deepEqual(m.audience(draft({audience:'buyers'})).map(c=>c.email),[buyer.email]);
  assert.deepEqual(m.audience(draft({country:'Kuwait'})).map(c=>c.email),[buyer.email]);
  assert.ok(m.contacts().find(c=>c.email===buyer.email).consent_at);
 });
 await check('explicit member opt-in and opt-out leave recovery mail and other accounts unchanged',async()=>{
  providerContacts.set(visitor.email,{email:visitor.email,emailBlacklisted:true});
  await assert.rejects(m.setSubscription(visitor,true,false),{status:400});
  await m.setSubscription(visitor,true,true);assert.equal(providerContacts.get(visitor.email).emailBlacklisted,false);
  await m.setSubscription(visitor,false,false);assert.equal(providerContacts.get(visitor.email).emailBlacklisted,true);
  const preference=await m.setSubscription(buyer,true,true);assert.deepEqual(preference,{subscribed:true,pending:false,hasChoice:true});
  assert.equal(requests.some(r=>r.body?.smtpBlacklistSender),false);
 });
 await check('provider outages retain the opt-out locally and leave a retryable synchronization record',async()=>{
  intercept=({route,method})=>route===`contacts/${encodeURIComponent(buyer.email)}`&&method==='PUT'?Promise.reject(Error('Network down')):undefined;
  const result=await m.setSubscription(buyer,false,false);assert.equal(result.pending,true);assert.equal(m.audience(draft()).some(c=>c.email===buyer.email),false);
  intercept=null;await m.syncContacts(owner);assert.equal(m.subscription(buyer).pending,false);
  await m.setSubscription(buyer,true,true);
 });
 await check('an older provider response cannot overwrite a newer member opt-out',async()=>{
  providerContacts.set(visitor.email,{email:visitor.email,emailBlacklisted:false});
  let release,entered;const waiting=new Promise(r=>release=r),started=new Promise(r=>entered=r);let first=true;
  intercept=async({route,method,body})=>{
   if(first&&route===`contacts/${encodeURIComponent(visitor.email)}`&&method==='PUT'&&!body.emailBlacklisted){first=false;entered();await waiting;providerContacts.set(visitor.email,{emailBlacklisted:false});return json(null,204);}
  };
  const old=m.setSubscription(visitor,true,true);await started;await m.setSubscription(visitor,false,false);release();await old;
  assert.equal(m.subscription(visitor).subscribed,false);assert.equal(providerContacts.get(visitor.email).emailBlacklisted,true);
 });
 await check('templates escape user content, forbid executable URLs, and retain the native unsubscribe link',async()=>{
  assert.equal(safeEmailUrl('javascript:alert(1)'), '');assert.equal(safeEmailUrl('https://user:secret@example.test'), '');
  const html=emailTemplate(draft({body:'<script>alert(1)</script> {{ contact.SECRET }}',subject:'<img onerror=1>',imageUrl:'javascript:alert(1)'}));
  assert.ok(!html.includes('<script>'));assert.ok(!html.includes('{{ contact.SECRET }}'));assert.match(html,/&lt;script&gt;/);assert.match(html,/href="\{\{ unsubscribe \}\}"/);assert.match(html,/dir="rtl"/);
  assert.match(emailTemplate(draft({language:'en'})),/dir="ltr"/);
  assert.throws(()=>fresh({buttonUrl:'http://unsafe.test'}),{status:400});assert.throws(()=>m.saveCampaign(null,owner),{status:400});assert.throws(()=>fresh({subject:'one\ntwo'}),{status:400});
 });
 await check('saved versions and mandatory tests prevent stale or accidental launches',async()=>{
  const c=fresh();await assert.rejects(m.launchCampaign(c.id,c.version,'',false,owner),{status:400});await assert.rejects(m.launchCampaign(c.id,c.version,'',true,owner),{status:400});
  const t=await m.testCampaign(c.id,c.version,owner);assert.equal(t.tested,true);
  const saved=m.saveCampaign({...t,body:'Changed message content for a new version.'},owner);assert.equal(saved.tested,false);
  assert.throws(()=>m.saveCampaign({...t,body:'Another stale edit that must be rejected.'},owner),{status:409});
  await assert.rejects(m.launchCampaign(saved.id,saved.version,'',true,owner),{status:400});
 });
 await check('test copies are sent exclusively to the owner, and duplicate launch requests dispatch only once',async()=>{
  const c=await tested({audience:'buyers'}),before=sendCalls;
  const outcomes=await Promise.allSettled([m.launchCampaign(c.id,c.version,'',true,owner),m.launchCampaign(c.id,c.version,'',true,owner)]);
  assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,1);assert.equal(sendCalls,before+1);
  const campaign=outcomes.find(x=>x.status==='fulfilled').value;assert.equal(campaign.status,'queued');assert.equal(campaign.recipients,1);
  assert.ok(testCalls>0);assert.equal(requests.filter(r=>r.route==='contacts'&&r.method==='POST').some(r=>r.body.email===visitor.email||r.body.email==='blocked@example.test'),false);
 });
 await check('scheduling uses native provider scheduling, pauses safely, and reports only actual metrics',async()=>{
  const c=await tested({audience:'buyers'}),date=new Date(Date.now()+3600000).toISOString(),before=sendCalls;
  await assert.rejects(m.launchCampaign(c.id,c.version,new Date(Date.now()-60000).toISOString(),true,owner),{status:400});
  const scheduled=await m.launchCampaign(c.id,c.version,date,true,owner);assert.equal(scheduled.status,'scheduled');assert.equal(sendCalls,before);
  assert.equal(providerCampaigns.get(scheduled.providerId).scheduledAt,date);
  const paused=await m.pauseCampaign(c.id,owner);assert.equal(paused.status,'paused');
  Object.assign(providerCampaigns.get(scheduled.providerId),{status:'sent',statistics:{globalStats:{sent:1,delivered:1,uniqueViews:0,uniqueClicks:0}}});
  const report=await m.refreshCampaign(c.id,owner);assert.equal(report.status,'sent');assert.deepEqual(report.stats,{sent:1,delivered:1,uniqueViews:0,uniqueClicks:0});
  const copy=m.cloneCampaign(c.id,owner);assert.equal(copy.status,'draft');assert.equal(copy.providerId,null);assert.equal(copy.tested,false);
 });
 await check('ambiguous send failures lock the campaign until its provider state has been reviewed',async()=>{
  const c=await tested({audience:'buyers'});let attempts=0;
  intercept=({route})=>{if(route===`emailCampaigns/${c.providerId}/sendNow`){attempts++;providerCampaigns.get(c.providerId).status='queued';throw Error('Response lost');}};
  await assert.rejects(m.launchCampaign(c.id,c.version,'',true,owner),{status:502});
  assert.equal(m.dashboard().campaigns.find(x=>x.id===c.id).status,'review');
  await assert.rejects(m.launchCampaign(c.id,c.version,'',true,owner),{status:409});assert.equal(attempts,1);
  intercept=null;assert.equal((await m.refreshCampaign(c.id,owner)).status,'queued');
  await assert.rejects(m.launchCampaign(c.id,c.version,'',true,owner),{status:409});
 });
 await check('credit failures do not purchase or upgrade a plan',async()=>{
  const c=await tested({audience:'buyers'}),offset=requests.length;
  intercept=({route})=>route.endsWith('/sendNow')?json({code:'not_enough_credits'},402):undefined;
  await assert.rejects(m.launchCampaign(c.id,c.version,'',true,owner),e=>e.status===400&&e.message.includes('رصيد'));
  assert.equal(requests.slice(offset).some(r=>/billing|purchase|upgrade|payment/.test(r.route)),false);
 });
 await check('native unsubscribe synchronization never silently resubscribes contacts',async()=>{
  providerContacts.set(buyer.email,{email:buyer.email,emailBlacklisted:true});await m.syncContacts(owner);
  assert.equal(m.subscription(buyer).subscribed,false);assert.equal(m.audience(draft({audience:'buyers'})).length,0);
  assert.equal(m.importContacts([{email:buyer.email}],true,'Re-import of prior consent',owner).skipped,1);
 });
 await check('empty and oversized audiences are rejected before any provider dispatch',async()=>{
  const empty=await tested({audience:'buyers'}),before=sendCalls;
  await assert.rejects(m.launchCampaign(empty.id,empty.version,'',true,owner),{status:400});
  const stamp=new Date().toISOString();
  for(let i=0;i<201;i++)sql.prepare('INSERT INTO marketing_contacts(email,status,source,consent_at,updated) VALUES(?,?,?,?,?)').run(`cap-${i}@example.test`,'subscribed','test consent',stamp,stamp);
  const tooMany=await tested();await assert.rejects(m.launchCampaign(tooMany.id,tooMany.version,'',true,owner),{status:400});assert.equal(sendCalls,before);
  sql.prepare("DELETE FROM marketing_contacts WHERE email LIKE 'cap-%@example.test'").run();
 });
 await check('CSV parsing handles Arabic headers, quoted commas/newlines and malformed inputs',async()=>{
  assert.deepEqual(parseMarketingCsv('\uFEFFemail,name,country\r\na@example.test,"Doe, Jane",Kuwait'),[{email:'a@example.test',name:'Doe, Jane',country:'Kuwait'}]);
  assert.equal(parseMarketingCsv('البريد;الاسم;البلد\na@example.test;"A\nB";الكويت')[0].name,'A\nB');
  assert.throws(()=>parseMarketingCsv('name\nSomeone'));assert.throws(()=>parseMarketingCsv('email\n"not closed'));assert.throws(()=>parseMarketingCsv('x'.repeat(80001)));
 });
 await check('bounded request parsing rejects oversized or malformed bodies',async()=>{
  assert.deepEqual(await readMarketingBody(new Request('https://example.test',{method:'POST',body:'{"action":"save"}'})),{action:'save'});
  await assert.rejects(readMarketingBody(new Request('https://example.test',{method:'POST',body:'not JSON'})),{status:400});
  await assert.rejects(readMarketingBody(new Request('https://example.test',{method:'POST',body:'x'.repeat(100001)})),{status:413});
 });
 await check('dashboard and connection checks reveal no API key and preserve accounts, orders and entitlements',async()=>{
  const state=m.dashboard(),connection=await m.connection();assert.ok(!JSON.stringify({state,connection}).includes(process.env.BREVO_API_KEY));
  assert.equal(connection.apiKey,undefined);assert.equal(connection.email,undefined);
  assert.deepEqual(sql.prepare('SELECT * FROM accounts ORDER BY id').all(),beforeAccounts);
  assert.deepEqual(sql.prepare("SELECT * FROM records WHERE kind='order' ORDER BY id").all(),beforeOrders);
  assert.deepEqual(sql.prepare('SELECT * FROM grants').all(),beforeGrants);
 });
 console.log(`PASS: ${passed} marketing checks; all email/provider requests mocked, no real messages sent.`);
}finally{globalThis.fetch=originalFetch;sql.close();rmSync(directory,{recursive:true,force:true});}
