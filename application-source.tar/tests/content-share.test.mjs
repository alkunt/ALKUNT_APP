import assert from 'node:assert/strict';
import {contentShareUrl,contentShareData,contentShareHtml} from '../app/content-share.mjs';

const product={id:'lesson & 1',type:'offer',title_ar:'تعليم <تفاعلي> & "واضح"',title_en:'Interactive learning',cover:'/api/files?id=public-cover',body_ar:'PAID_PROMPT_MUST_NOT_BE_COPIED',file:'PRIVATE_ATTACHMENT'};
const data=contentShareData(product,'ar','https://example.test/admin?session=not-a-share-url');
assert.equal(data.url,'https://example.test/?view=offers&item=lesson+%26+1');
assert.equal(data.image,'https://example.test/api/files?id=public-cover');
assert.equal(data.text,product.title_ar+'\n'+data.url);
assert.equal(data.language,'ar');
assert.equal(contentShareUrl({...product,type:'prompt'},'https://example.test'),'https://example.test/?view=prompt&item=lesson+%26+1');
assert.equal(contentShareData(product,'en','https://example.test').title,product.title_en);
for(const cover of ['',null,'javascript:alert(1)','https://user:secret@example.test/image.png','http://untrusted.test/image.png'])
  assert.equal(contentShareData({...product,cover},'ar','https://example.test').image,'https://example.test/alkunt-logo.png');
assert.equal(contentShareData({...product,cover:'https://cdn.example.test/image.jpg'},'ar','https://example.test').image,'https://cdn.example.test/image.jpg');
const image='data:image/png;base64,aW1hZ2U=';
const html=contentShareHtml(data,image);
assert.ok(html.includes('dir="rtl"'));
assert.ok(html.includes('تعليم &lt;تفاعلي&gt; &amp; &quot;واضح&quot;'));
assert.ok(html.includes('href="https://example.test/?view=offers&amp;item=lesson+%26+1"'));
assert.ok(html.includes('src="'+image+'"'));
assert.ok(!JSON.stringify({data,html}).includes('PAID_PROMPT'));
assert.ok(!JSON.stringify({data,html}).includes('PRIVATE_ATTACHMENT'));
assert.ok(!JSON.stringify({data,html}).includes('session='));
assert.throws(()=>contentShareHtml(data,'javascript:alert(1)'));
console.log('Content sharing checks passed: canonical links, cover safety, escaped rich content, and no protected content in the clipboard.');
