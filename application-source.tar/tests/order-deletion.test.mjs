import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import ts from 'typescript';

const directory=mkdtempSync(path.join(tmpdir(),'alkunt-delete-order-tests-'));
Object.assign(process.env,{DATA_DIR:directory,APP_ORIGIN:'https://example.test',GUMROAD_ACCESS_TOKEN:'mock-token',GUMROAD_SELLER_ID:'mock-seller',GUMROAD_STORE_ORIGIN:'https://test-store.gumroad.com',GUMROAD_ENABLED:'true',GUMROAD_CURRENCY_ACCEPTED:'USD',GUMROAD_WEBHOOK_SECRET:'mock-secret-123456789012345678901234567890'});
const {sql,BUCKET}=await import('../server/runtime.mjs');
const payments=await import('../server/gumroad.mjs');payments.initGumroad();
const owner={userId:'owner',email:'alkunt@yahoo.com',displayName:'Owner'},buyer={userId:'buyer',email:'buyer@example.test',displayName:'Buyer'},other={userId:'other',email:'other@example.test',displayName:'Other'};
for(const u of [owner,buyer,other])sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run(u.userId,u.email,u.displayName,'unchanged-password');
const accountSnapshot=sql.prepare('SELECT * FROM accounts ORDER BY id').all();
const originalFetch=globalThis.fetch;let mode='',requests=[],products=new Map(),sales=new Map(),checks=0;
globalThis.fetch=async(input,options={})=>{
 const url=new URL(input);assert.equal(url.origin,'https://api.gumroad.com');assert.equal(options.headers.Authorization,'Bearer mock-token');assert.equal(options.redirect,'error');assert.ok(options.signal);requests.push({path:url.pathname,method:options.method});
 if(mode==='network')throw Error('offline');
 const disable=url.pathname.match(/^\/v2\/products\/([^/]+)\/disable$/);
 if(disable){assert.equal(options.method,'PUT');const product=products.get(decodeURIComponent(disable[1]));assert.ok(product);if(mode==='mismatch')return Response.json({success:true,product:{id:'wrong',published:false}});if(mode==='still-published')return Response.json({success:true,product:{...product,published:true}});product.published=false;return Response.json({success:true,product});}
 if(url.pathname==='/v2/sales')return Response.json({success:true,sales:[...sales.values()].filter(s=>s.product_id===url.searchParams.get('product_id'))});
 const sale=url.pathname.match(/^\/v2\/sales\/([^/]+)$/);if(sale)return Response.json({success:true,sale:sales.get(decodeURIComponent(sale[1]))});
 throw Error('Unexpected request: '+url.pathname);
};
function write(id,kind,owner,data){sql.prepare('INSERT OR REPLACE INTO records VALUES(?,?,?,?,?)').run(id,kind,owner,JSON.stringify(data),new Date().toISOString());}
function record(id){const row=sql.prepare('SELECT * FROM records WHERE id=?').get(id);return row?{...JSON.parse(row.data),id:row.id,owner:row.owner,kind:row.kind}:null;}
function seed(id,{provider=false,status='pending'}={}){
 const order={number:'ALK-'+id,status,paymentMethod:provider?'gumroad':'manual-transfer',paymentStage:status==='confirmed'?'verified':'awaiting-payment',email:buyer.email,date:new Date().toISOString(),payer:'PRIVATE NAME',phone:'PRIVATE PHONE',note:'PRIVATE NOTE',receipt:'private-receipt',items:[{id:'book',title_ar:'PRIVATE TITLE',price:15}],total:15,paymentLink:provider?'https://test-store.gumroad.com/l/'+id:'',timeline:[{status,date:new Date().toISOString()}],gumroad:{expectedCents:4829}};
 write(id,'order',buyer.userId,order);write('note-'+id,'notification',buyer.userId,{order:id,title:'PRIVATE NOTIFICATION'});
 if(provider){const productId='product-'+id;products.set(productId,{id:productId,published:true});sql.prepare('INSERT INTO gumroad_quotes VALUES(?,?,?,?)').run('quote-'+id,buyer.userId,'{}',Date.now()+60000);sql.prepare('INSERT INTO gumroad_payments VALUES(?,?,?,?,?,?,?)').run(id,'quote-'+id,productId,4829,null,'ready',Date.now());}
 return order;
}
async function check(name,run){await run();checks++;console.log('PASS:',name);}
let currentUser=owner;
const module={exports:{}};
vm.runInNewContext(ts.transpileModule(readFileSync('app/api/orders/permanent-delete/route.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,{module,exports:module.exports,Response,Request,process,require(name){if(name.includes('chatgpt-auth'))return {getChatGPTUser:async()=>currentUser};if(name.includes('gumroad.mjs'))return payments;throw Error(name);}});
const post=(body,origin='https://example.test')=>module.exports.POST(new Request('https://example.test/api/orders/permanent-delete',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify(body)}));
try{
 write('book','product','',{type:'book',status:'published',price:15,title_ar:'Book'});
 await BUCKET.put('private-receipt',Buffer.from('existing file preserved'));
 await check('owner-only route, login, origin, blocked account and exact confirmation fail before side effects',async()=>{
  const o=seed('auth');currentUser=null;assert.equal((await post({id:'auth',confirmNumber:o.number})).status,401);
  for(const user of [buyer,other]){currentUser=user;assert.equal((await post({id:'auth',confirmNumber:o.number})).status,403);}
  currentUser=owner;assert.equal((await post({id:'auth',confirmNumber:o.number},'https://evil.test')).status,403);
  for(const value of ['',o.number+' ',o.number.toLowerCase(),123])assert.equal((await post({id:'auth',confirmNumber:value})).status,400);
  write('profile:owner','profile',owner.userId,{blocked:true});assert.equal((await post({id:'auth',confirmNumber:o.number})).status,403);write('profile:owner','profile',owner.userId,{});
  assert.equal((await post({id:'book',confirmNumber:o.number})).status,404);assert.equal((await post(null)).status,400);assert.equal(requests.length,0);assert.ok(record('auth'));
 });
 await check('permanent order removal is scoped and strips details while preserving accounts, products and files',async()=>{
  const o=record('auth');const response=await post({id:o.id,confirmNumber:o.number});assert.equal(response.status,200);assert.equal(record(o.id),null);assert.equal(record('note-auth'),null);
  const marker=record('deleted-order:auth');assert.equal(marker.status,'pending');for(const field of ['payer','phone','note','receipt','total','timeline','number','email','paymentLink'])assert.equal(marker[field],undefined);
  assert.deepEqual(marker.items,[{id:'book'}]);assert.ok(record('book'));assert.equal((await BUCKET.get('private-receipt')).body.toString(),'existing file preserved');assert.equal((await post({id:o.id,confirmNumber:o.number})).status,404);
 });
 await check('confirmed purchases and an unrelated order survive deletion without refunds or grant removal',async()=>{
  const o=seed('manual-paid',{status:'confirmed'});seed('unrelated');sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('buyer:book',buyer.userId,'book','manual-paid');
  assert.equal((await post({id:'manual-paid',confirmNumber:o.number})).status,200);assert.equal(sql.prepare('SELECT source FROM grants WHERE id=?').get('buyer:book').source,'manual-paid');assert.equal(record('deleted-order:manual-paid').status,'confirmed');assert.ok(record('unrelated'));assert.ok(record('note-unrelated'));assert.equal(requests.length,0);
 });
 await check('external manual links require explicit closure acknowledgment',async()=>{
  const o=seed('external-link');o.paymentMethod='payment-link';o.paymentLink='https://external-provider.example.test/pay';write('external-link','order',buyer.userId,o);
  assert.equal((await post({id:'external-link',confirmNumber:o.number})).status,409);assert.ok(record('external-link'));
  assert.equal((await post({id:'external-link',confirmNumber:o.number,confirmExternalLinkClosed:true})).status,200);assert.equal(record('external-link'),null);
 });
 await check('provider failure, mismatched disable response and unclosed links keep the order intact',async()=>{
  const o=seed('disable-failure',{provider:true});
  for(const failure of ['network','mismatch','still-published']){mode=failure;assert.equal((await post({id:'disable-failure',confirmNumber:o.number})).status,502);assert.ok(record('disable-failure'));assert.equal(record('deleted-order:disable-failure'),null);assert.ok(record('note-disable-failure'));}mode='';
 });
 await check('Gumroad link is disabled before deletion and stale checkout cannot recreate the order',async()=>{
  const o=seed('pending-provider',{provider:true});assert.equal((await post({id:'pending-provider',confirmNumber:o.number})).status,200);assert.equal(products.get('product-pending-provider').published,false);assert.equal(record('pending-provider'),null);
  await assert.rejects(()=>payments.startPayment(buyer,{quoteId:'quote-pending-provider'}),{status:404});assert.equal(record('pending-provider'),null);
 });
 await check('a genuine delayed sale and later refund reconcile without resurrecting deleted order details',async()=>{
  sql.prepare('DELETE FROM grants WHERE user=? AND product=?').run(buyer.userId,'book');
  // This test uses another account so the unrelated preserved purchase cannot supply access.
  const o=seed('delayed-sale',{provider:true});sql.prepare("UPDATE records SET owner=? WHERE id=?").run(other.userId,'delayed-sale');o.email=other.email;write('delayed-sale','order',other.userId,o);
  assert.equal((await post({id:'delayed-sale',confirmNumber:o.number})).status,200);
  const sale={id:'sale-delayed',seller_id:'mock-seller',product_id:'product-delayed-sale',email:other.email,price:4829,currency:'usd',quantity:1,created_at:new Date().toISOString()};sales.set(sale.id,sale);
  let result=await payments.verifyPaymentSale(sale.id);assert.equal(result.ignored,'deleted_order');assert.equal(record('delayed-sale'),null);assert.equal(record('deleted-order:delayed-sale').status,'confirmed');assert.equal(sql.prepare('SELECT source FROM grants WHERE user=? AND product=?').get(other.userId,'book').source,'delayed-sale');
  assert.equal(record('note-delayed-sale'),null);const marker=record('deleted-order:delayed-sale');assert.equal(marker.number,undefined);assert.equal(marker.phone,undefined);assert.equal(marker.total,undefined);
  sale.refunded=true;result=await payments.verifyPaymentSale(sale.id);assert.equal(result.status,'refunded');assert.equal(sql.prepare('SELECT id FROM grants WHERE user=? AND product=?').get(other.userId,'book'),undefined);assert.equal(record('delayed-sale'),null);assert.equal(record('deleted-order:delayed-sale').status,'refunded');
 });
 await check('deleting a confirmed provider order preserves its grant and later refund preserves other confirmed purchases',async()=>{
  const o=seed('provider-paid',{provider:true,status:'confirmed'});sql.prepare('INSERT OR REPLACE INTO grants VALUES(?,?,?,?)').run('buyer:book',buyer.userId,'book','provider-paid');assert.equal((await post({id:'provider-paid',confirmNumber:o.number})).status,200);assert.equal(sql.prepare('SELECT source FROM grants WHERE id=?').get('buyer:book').source,'provider-paid');
  const sale={id:'sale-paid',seller_id:'mock-seller',product_id:'product-provider-paid',email:buyer.email,price:4829,currency:'usd',quantity:1,created_at:new Date().toISOString(),refunded:true};sales.set(sale.id,sale);await payments.verifyPaymentSale(sale.id);assert.equal(sql.prepare('SELECT source FROM grants WHERE id=?').get('buyer:book').source,'manual-paid');assert.equal(record('provider-paid'),null);
 });
 assert.deepEqual(sql.prepare('SELECT * FROM accounts ORDER BY id').all(),accountSnapshot);assert.ok(!requests.some(r=>/refund|revoke_access|enable/.test(r.path)));console.log(`${checks} order deletion checks passed; no real network or production data used.`);
}finally{globalThis.fetch=originalFetch;sql.close();rmSync(directory,{recursive:true,force:true});}
