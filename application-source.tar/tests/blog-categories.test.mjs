import assert from 'node:assert/strict';
import {blogCategory, blogCategories, matchesBlogCategory} from '../app/blog-categories.mjs';

const article = (id, category, category_en) => ({id, type:'blog', category, category_en});
const ai = [
  article('gemini', 'أدوات الذكاء الاصطناعي', 'AI tools'),
  article('voice', 'أدوات الصوت بالذكاء الاصطناعي', 'AI voice tools'),
  article('design', 'أدوات التصميم بالذكاء الاصطناعي', 'AI design tools'),
  article('code', 'أدوات البرمجة بالذكاء الاصطناعي', 'AI coding tools'),
  article('video', 'أدوات الفيديو والتسويق بالذكاء الاصطناعي', 'AI video and marketing tools'),
  article('work', 'أدوات الإنتاجية بالذكاء الاصطناعي', 'AI productivity tools'),
];
assert.equal(blogCategories(ai).length, 1);
const aiId = blogCategory(ai[0]).id;
assert.equal(blogCategory(article('explicit-general', 'تعلّم وتطوّر')).id, blogCategory(article('default-general', '')).id);
assert.ok(ai.every(product => matchesBlogCategory(product, aiId)));
assert.equal(blogCategory(article('future', '  أَدواتُ  الكتابة بالذكاء الإصطناعي\u200f ')).id, aiId);
assert.equal(blogCategory(article('english', '', 'AI learning tools')).id, aiId);

const others = [article('news', 'أخبار الكونت'), article('news2', '  اخبارُ\u200f   الكونت  ', 'ALKUNT news'),
  article('event', 'إعلانات الدورات'), article('scisim', 'أدوات التعليم التفاعلي'),
  article('general', ''), article('general2', undefined)];
const before = JSON.stringify([...ai, ...others]);
const categories = blogCategories([...ai, ...others, {id:'course', type:'course', category:'دورة جديدة'}]);
assert.equal(categories.length, 5);
assert.equal(new Set(categories.map(category => category.id)).size, categories.length);
assert.equal(categories.find(category => category.id === blogCategory(others[0]).id).en, 'ALKUNT news');
assert.deepEqual(others.filter(product => matchesBlogCategory(product, blogCategory(others[0]).id)).map(p => p.id), ['news','news2']);
assert.equal(others.some(product => matchesBlogCategory(product, aiId)), false);
assert.ok([...ai, ...others].every(product => matchesBlogCategory(product, 'all')));
assert.equal(blogCategories([...ai, ...others, article('new', 'تجارب تعليمية'), article('new2', 'تجارب تعليمية')]).length, 6);
assert.equal(JSON.stringify([...ai, ...others]), before, 'Grouping must not change the stored articles');
console.log('PASS: blog categories group AI subtopics, normalize duplicate Arabic labels, filter every matching article, preserve distinct/new types and leave records unchanged.');
