import assert from 'node:assert/strict';
import {mkdtempSync,mkdirSync} from 'node:fs';
import path from 'node:path';
import {buildPageMetadata, publiclyListed} from '../app/page-metadata.mjs';
import {localizedText} from '../app/localized-text.mjs';
import {defaultFaqs, resolvedFaqs, sitePageText} from '../app/site-copy.mjs';

const now = Date.parse('2026-10-30T06:00:00Z');
const origin = 'https://example.test';
const product = {id:'public-article',type:'blog',status:'published',title_ar:'مقال عربي',title_en:'English article',
  desc_ar:'وصف <strong>عام</strong> للمقال',desc_en:'Public description',cover:'/api/files?id=public-cover',
  body_ar:'PRIVATE_BODY_DO_NOT_EXPOSE',file:'PRIVATE_PAID_FILE'};
const metadata = buildPageMetadata({view:'blog',item:product.id},product,{origin,now});
assert.equal(metadata.title,'مقال عربي | ALKUNT');
assert.equal(metadata.description,'وصف عام للمقال');
assert.equal(metadata.alternates.canonical,'https://example.test/?view=blog&item=public-article');
assert.equal(metadata.openGraph.url,metadata.alternates.canonical);
assert.equal(metadata.openGraph.type,'article');
assert.equal(metadata.openGraph.images[0].url,'https://example.test/api/files?id=public-cover');
assert.equal(metadata.twitter.title,metadata.title);
assert.equal(metadata.robots.index,true);
assert.equal(JSON.stringify(metadata).includes('PRIVATE_'),false);
assert.equal(buildPageMetadata({view:'blog',item:product.id,lang:'en'},product,{origin,now}).title,'English article | ALKUNT');
assert.equal(buildPageMetadata({view:'blog',item:product.id},{...product,desc_ar:'',desc_en:''},{origin,now}).description,'مقال عربي | ALKUNT');
assert.equal(buildPageMetadata({view:'blog',item:product.id},{...product,cover:'javascript:alert(1)'},{origin,now}).openGraph.images[0].url,origin+'/alkunt-logo.png');
assert.equal(buildPageMetadata({view:'blog',item:product.id},{...product,cover:'https://user:pass@example.test/private'},{origin,now}).openGraph.images[0].url,origin+'/alkunt-logo.png');

for (const patch of [{status:'draft'},{status:'archived'},{publishAt:'2026-11-01T00:00:00Z'},{publishAt:'invalid date'},{id:'different-id'},{type:'book'}]) {
  const result = buildPageMetadata({view:'blog',item:product.id},{...product,...patch,title_ar:'SECRET DRAFT TITLE'},{origin,now});
  assert.equal(result.robots.index,false);
  assert.equal(JSON.stringify(result).includes('SECRET DRAFT TITLE'),false);
}
assert.equal(publiclyListed({...product,status:'coming'},now),true);
for (const view of ['admin','account','checkout','cart','library','favorites','search','unrecognized'])
  assert.equal(buildPageMetadata({view},null,{origin,now}).robots.index,false);
assert.equal(buildPageMetadata({view:'book'},null,{origin,now}).title,'الكتيبات | ALKUNT');
const offerMetadata = buildPageMetadata({view:'offers',item:product.id},{...product,type:'offer'},{origin,now});
assert.equal(offerMetadata.title,metadata.title);
assert.equal(offerMetadata.alternates.canonical,'https://example.test/?view=offers&item=public-article');
assert.equal(buildPageMetadata({view:['blog','admin'],item:[product.id,'other']},product,{origin,now}).title,metadata.title);

const savedPages = {terms_ar:'شروط المالك المخصصة',privacy_en:'Custom owner privacy text'};
assert.equal(sitePageText(savedPages,'terms','ar'),savedPages.terms_ar);
assert.equal(sitePageText(savedPages,'privacy','en'),savedPages.privacy_en);
assert.match(sitePageText({},'terms','ar'),/Gumroad/);
assert.match(sitePageText({privacy_ar:'سيُضاف النص المعتمد من إدارة المنصة هنا.'},'privacy','ar'),/تفضيلات البريد/);
const custom = [{id:'custom',question_ar:'سؤالي',answer_ar:'جوابي المخصص'}];
assert.deepEqual(resolvedFaqs(custom),custom);
assert.deepEqual(resolvedFaqs([]),[]);
const legacy = [{id:'legacy',question_ar:'كيف أشتري من خارج الكويت؟',question_en:'Custom question',
  answer_ar:'اختر خارج الكويت عند إتمام الطلب، واتبع تعليمات التحويل اليدوي ثم ارفع الإيصال للمراجعة.',answer_en:'Custom answer'}];
const upgraded = resolvedFaqs(legacy);
assert.equal(upgraded[0].answer_ar,defaultFaqs[1].answer_ar);
assert.equal(upgraded[0].answer_en,'Custom answer');
assert.equal(upgraded[0].id,'legacy');
assert.notEqual(upgraded[0].answer_ar,legacy[0].answer_ar);
assert.equal(localizedText({category:'تصميم',category_en:'Design'},'ar','category'),'تصميم');
assert.equal(localizedText({category:'تصميم',category_en:'Design'},'en','category'),'Design');

// Exercise the production metadata reader against an isolated database, never live data.
const temporaryRoot = process.env.ALKUNT_TEST_TMP || path.resolve('.test-tmp');
mkdirSync(temporaryRoot,{recursive:true});
process.env.DATA_DIR = mkdtempSync(path.join(temporaryRoot,'metadata-'));
const {sql} = await import('../server/runtime.mjs');
const {publicProductMetadata} = await import('../server/public-metadata.mjs');
const insert = sql.prepare('INSERT INTO records(id,kind,owner,data,created) VALUES(?,?,?,?,?)');
insert.run(product.id,'product','',JSON.stringify(product),new Date(now).toISOString());
insert.run('draft','product','',JSON.stringify({...product,status:'draft',title_ar:'PRIVATE TITLE'}),new Date(now).toISOString());
insert.run('profile-only','profile','someone',JSON.stringify(product),new Date(now).toISOString());
insert.run('broken','product','','not json',new Date(now).toISOString());
const preview = publicProductMetadata(product.id);
assert.equal(preview.title_ar,product.title_ar);
assert.equal(preview.id,product.id);
assert.equal('file' in preview,false);
assert.equal('body_ar' in preview,false);
assert.equal(publicProductMetadata('draft'),null);
assert.equal(publicProductMetadata('profile-only'),null);
assert.equal(publicProductMetadata('broken'),null);
assert.equal(publicProductMetadata("' OR 1=1 --"),null);
assert.equal(publicProductMetadata('missing'),null);
sql.close();
console.log('Site audit regression checks passed: public metadata, protected content, localization, and preservation of owner copy.');
