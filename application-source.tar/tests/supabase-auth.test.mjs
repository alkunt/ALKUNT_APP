import assert from 'node:assert/strict';
import {mkdtempSync,rmSync,readFileSync} from 'node:fs';import {tmpdir} from 'node:os';import path from 'node:path';import vm from 'node:vm';import ts from 'typescript';
const directory=mkdtempSync(path.join(tmpdir(),'alkunt-supabase-test-'));
process.env.DATA_DIR=directory;process.env.APP_ORIGIN='https://app.example.test';process.env.COOKIE_SECURE='false';process.env.SUPABASE_URL='https://auth.example.test';process.env.SUPABASE_PUBLISHABLE_KEY='test-publishable';process.env.SUPABASE_AUTH_ENABLED='true';
const runtime=await import('../server/runtime.mjs'),auth=await import('../server/auth.mjs'),remote=await import('../server/supabase-auth.mjs');const {sql}=runtime;const mail=await import('../server/mail.mjs'),recovery=await import('../server/password-recovery.mjs');
let remoteUser={id:'remote-new',email:'new@example.test',email_confirmed_at:new Date().toISOString(),user_metadata:{display_name:'New user',role:'admin',firstName:'Test',lastName:'Customer',country:'Kuwait',callingCode:'+965',phone:'55551234'}};
let calls=[],deliveries=0;
const originalFetch=globalThis.fetch;
globalThis.fetch=async(url,options)=>{calls.push({url,options});const pathname=new URL(url).pathname;
 if(pathname.endsWith('/signup'))return Response.json({user:{id:'pending'},access_token:'should-never-establish-session'});
 if(pathname.endsWith('/user')){if(options.headers.Authorization==='Bearer '+'invalid'.repeat(8))return Response.json({error_code:'bad_jwt'},{status:401});return Response.json(remoteUser);}
 if(pathname.endsWith('/token')||pathname.endsWith('/verify'))return Response.json({access_token:'verified-access-token-123456789'});
 if(pathname.endsWith('/resend'))return Response.json({});throw Error('Unexpected request');};
const mod={exports:{}};const js=ts.transpileModule(readFileSync('app/api/auth/route.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
vm.runInNewContext(js,{exports:mod.exports,module:mod,require(name){if(name.includes('server/runtime'))return runtime;if(name.includes('server/mail'))return mail;if(name.includes('password-recovery'))return recovery;if(name.includes('server/auth'))return auth;if(name.includes('supabase-auth'))return remote;if(name.includes('owner-notifications'))return {notifyOwner:async()=>{deliveries++;}};if(name==='next/headers')return {cookies:async()=>({get:()=>undefined})};if(name==='node:crypto')return {randomUUID:crypto.randomUUID};throw Error(name);},Response,Request,URL,console,process});
async function post(body){const response=await mod.exports.POST(new Request(process.env.APP_ORIGIN+'/api/auth',{method:'POST',headers:{origin:process.env.APP_ORIGIN,'Content-Type':'application/json'},body:JSON.stringify(body)}));return {status:response.status,body:await response.json(),cookie:response.headers.get('set-cookie')};}
const password='local password unchanged 123';
try{
 const hash=await auth.passwordHash(password);sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('owner',auth.ownerEmail,'Owner',hash);sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('old','old@example.test','Old user',hash);sql.prepare('INSERT INTO grants VALUES(?,?,?,?)').run('owned','old','paid-product','purchase');
 const owner=await post({action:'login',email:auth.ownerEmail,password});assert.equal(owner.status,200);assert.ok(owner.cookie);assert.equal(calls.length,0);
 assert.equal((await post({action:'login',email:'old@example.test',password})).status,200);assert.equal(calls.length,0);
 const pending=await post({action:'register',firstName:'Test',lastName:'Customer',country:'Kuwait',callingCode:'+965',phone:'55551234',email:'new@example.test',password,name:'New user'});assert.equal(pending.status,200);assert.equal(pending.body.requiresEmailConfirmation,true);assert.equal(pending.cookie,null);assert.equal(sql.prepare('SELECT id FROM accounts WHERE email=?').get('new@example.test'),undefined);
 const registered=await post({action:'confirm-session',accessToken:'verified-access-token-123456789'});assert.equal(registered.status,200);assert.ok(registered.cookie.includes('Max-Age=3600'));assert.equal(deliveries,1);
 const user=sql.prepare('SELECT * FROM accounts WHERE email=?').get('new@example.test');const profile=JSON.parse(sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id).data);assert.equal(profile.role,'customer');assert.equal(profile.emailVerified,true);assert.equal(profile.firstName,'Test');assert.equal(profile.country,'Kuwait');assert.equal(profile.phone,'55551234');const metadata=JSON.parse(calls.find(c=>c.url.includes('/signup')).options.body).data;assert.equal(metadata.callingCode,'+965');assert.equal((await post({action:'register',email:'invalid@example.test',password,name:'Missing fields'})).status,400);
 assert.equal(sql.prepare("SELECT count(*) AS n FROM records WHERE kind='notification' AND owner='admin'").get().n,1);
 assert.equal((await post({action:'confirm-session',accessToken:'verified-access-token-123456789'})).status,200);assert.equal(deliveries,1);
 remoteUser={...remoteUser,email_confirmed_at:null};assert.equal((await post({action:'confirm-session',accessToken:'verified-access-token-123456789'})).status,403);
 remoteUser={...remoteUser,id:'attacker',email:'old@example.test',email_confirmed_at:new Date().toISOString()};assert.equal((await post({action:'confirm-session',accessToken:'verified-access-token-123456789'})).status,409);assert.equal(sql.prepare('SELECT product FROM grants WHERE user=?').get('old').product,'paid-product');assert.equal(sql.prepare('SELECT password FROM accounts WHERE id=?').get('old').password,hash);
 remoteUser={...remoteUser,email:auth.ownerEmail};assert.equal((await post({action:'confirm-session',accessToken:'verified-access-token-123456789'})).status,403);
 assert.equal((await post({action:'confirm-session',accessToken:'invalid'.repeat(8)})).status,400);
 process.env.SUPABASE_AUTH_ENABLED='false';const count=calls.length;assert.equal((await post({action:'login',email:auth.ownerEmail,password})).status,200);assert.equal(calls.length,count);assert.equal((await post({action:'confirm-session',accessToken:'verified-access-token-123456789'})).status,503);
 assert.equal((await post(null)).status,400);
 console.log('PASS: confirmation required, verified-only sessions, owner/legacy login and purchases preserved, no email takeover, no metadata role escalation, profiles, notification idempotency and feature gate.');
}finally{globalThis.fetch=originalFetch;sql.close();assert.ok(path.resolve(directory).startsWith(path.resolve(tmpdir())+path.sep+'alkunt-supabase-test-'));rmSync(directory,{recursive:true,force:true});}
