const {DatabaseSync}=require('node:sqlite');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const ts=require('typescript');
const sql=new DatabaseSync(':memory:');
sql.exec("CREATE TABLE records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,owner TEXT NOT NULL DEFAULT '',data TEXT NOT NULL,created TEXT NOT NULL);CREATE TABLE grants(id TEXT PRIMARY KEY,user TEXT NOT NULL,product TEXT NOT NULL,source TEXT NOT NULL);");
let currentUser=null;
const DB={prepare(query){let args=[];const statement={bind(...values){args=values;return statement},async first(){return sql.prepare(query).get(...args)||null},async all(){return {results:sql.prepare(query).all(...args)}},run(){return sql.prepare(query).run(...args)}};return statement},async batch(statements){sql.exec('BEGIN');try{const results=statements.map(statement=>statement.run());sql.exec('COMMIT');return results}catch(error){sql.exec('ROLLBACK');throw error}}};
const env={DB};
const cache=new Map();
function load(file){
 if(cache.has(file))return cache.get(file);
 const module={exports:{}};
 const js=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 vm.runInNewContext(js,{module,exports:module.exports,Response,Request,URL,crypto,console,process:{env:{APP_ORIGIN:'https://example.test'}},require(name){
  if(name.endsWith('/runtime'))return {env};
  if(name.includes('chatgpt-auth'))return {getChatGPTUser:async()=>currentUser};
  if(name.includes('audience-notifications'))return load('app/audience-notifications.ts');
  if(name.includes('owner-notifications'))return {notifyOwner:async()=>({}),validPushEndpoint:()=>false};
  if(name.includes('offer-registration'))return load('app/offer-registration.mjs');
  if(name.includes('rich-text'))return load('app/rich-text.mjs');
  if(name.includes('link-rules'))return load('app/link-rules.ts');
  if(name.includes('content-rules'))return load('app/content-rules.ts');
  if(name.includes('platform-data'))return load('app/platform-data.ts');
  throw Error('Unexpected dependency: '+name);
 }});
 cache.set(file,module.exports);return module.exports;
}
const api=load('app/api/platform/route.ts');
const owner={userId:'owner',email:'alkunt@yahoo.com',displayName:'Owner'};
const buyer={userId:'buyer',email:'buyer@example.test',displayName:'Buyer'};
const other={userId:'other',email:'other@example.test',displayName:'Other'};
const write=(id,kind,account,data,date='2026-11-05T01:00:00.000Z')=>sql.prepare('INSERT OR REPLACE INTO records VALUES(?,?,?,?,?)').run(id,kind,account,JSON.stringify(data),date);
const post=async(action,ids,origin='https://example.test')=>{
 const response=await api.POST(new Request('https://example.test/api/platform',{method:'POST',headers:{origin,'Content-Type':'application/json'},body:JSON.stringify({action,ids,user:other.userId})}));
 return {status:response.status,...await response.json()};
};
const inbox=async()=>{
 const response=await api.GET(new Request('https://example.test/api/platform'));
 assert.equal(response.status,200);return (await response.json()).notifications;
};
const unread=items=>items.filter(n=>!n.read).length;
const businessSnapshot=()=>JSON.stringify({records:sql.prepare("SELECT * FROM records WHERE kind NOT IN ('notification-state','profile') ORDER BY id").all(),grants:sql.prepare('SELECT * FROM grants ORDER BY id').all()});

(async()=>{try{
 write('seeded','system','',{done:true});write('repair:library-delete-20261018','system','',{done:true});
 for(const user of [owner,buyer,other])write('profile:'+user.userId,'profile',user.userId,{name:user.displayName,email:user.email,role:user===owner?'admin':'customer'});
 write('published','product','',{type:'blog',title_ar:'Public post',price:0,status:'published'});
 write('announcement:published','announcement','public',{title:'Public announcement',product:'published',date:'2026-11-05T01:00:00.000Z'});
 write('owner-note','notification','admin',{title:'Owner notification',date:'2026-11-05T02:00:00.000Z'});
 write('buyer-note','notification',buyer.userId,{title:'Buyer notification',date:'2026-11-05T02:00:00.000Z'});
 write('other-note','notification',other.userId,{title:'Other notification',date:'2026-11-05T02:00:00.000Z'});
 const snapshot=businessSnapshot();

 assert.equal((await post('readNotifications',['announcement:published'])).status,401);
 currentUser=buyer;
 assert.equal((await post('clearNotifications',['buyer-note'],'https://evil.test')).status,403);
 for(const ids of [null,'buyer-note',[1],[''],Array(101).fill('buyer-note')])assert.equal((await post('readNotifications',ids)).status,400);
 write('profile:buyer','profile',buyer.userId,{email:buyer.email,blocked:true});
 assert.equal((await post('clearNotifications',['buyer-note'])).status,403);
 write('profile:buyer','profile',buyer.userId,{email:buyer.email,role:'customer'});

 currentUser=owner;
 let items=await inbox();assert.equal(items.length,2);assert.equal(unread(items),2);
 assert.equal((await post('readNotifications',items.map(n=>n.id))).updated,2);
 items=await inbox();assert.equal(items.length,2);assert.equal(unread(items),0);
 // A fresh handler instance sees the same persisted read state.
 cache.delete('app/api/platform/route.ts');const reloadedApi=load('app/api/platform/route.ts');
 assert.equal(unread((await (await reloadedApi.GET(new Request('https://example.test/api/platform'))).json()).notifications),0);
 currentUser=buyer;assert.equal(unread(await inbox()),2);
 assert.equal((await post('clearNotifications',['owner-note','other-note'])).updated,0);
 assert.equal(unread(await inbox()),2);

 currentUser=owner;
 const seen=(await inbox()).map(n=>n.id);
 write('new-owner-note','notification','admin',{title:'Arrived after open',date:'2026-11-05T03:00:00.000Z'});
 assert.equal((await post('readNotifications',seen)).status,200);
 assert.deepEqual((await inbox()).filter(n=>!n.read).map(n=>n.id),['new-owner-note']);
 const allIds=(await inbox()).map(n=>n.id);
 const results=await Promise.all([post('clearNotifications',allIds),post('readNotifications',allIds)]);
 assert.ok(results.every(r=>r.status===200));assert.deepEqual(await inbox(),[]);
 assert.equal((await post('clearNotifications',allIds)).status,200);assert.deepEqual(await inbox(),[]);
 currentUser=buyer;assert.equal(unread(await inbox()),2);
 currentUser=null;assert.equal(unread(await inbox()),1);
 // Clearing keeps all original notification and business records intact.
 sql.prepare('DELETE FROM records WHERE id=?').run('new-owner-note');
 assert.equal(businessSnapshot(),snapshot);

 currentUser=owner;
 for(let i=0;i<105;i++)write('history-'+i,'notification','admin',{title:'History '+i,date:new Date(Date.UTC(2026,10,5,4,0,i)).toISOString()});
 items=await inbox();assert.equal(items.length,100);
 assert.equal((await post('clearNotifications',items.map(n=>n.id))).updated,100);
 assert.deepEqual(await inbox(),[],'Older history must not refill the cleared latest-100 inbox');
 write('after-clear','notification','admin',{title:'New after clear',date:'2026-11-05T05:00:00.000Z'});
 items=await inbox();assert.equal(items.length,1);assert.equal(items[0].id,'after-clear');assert.equal(unread(items),1);
 currentUser=other;assert.equal(unread(await inbox()),2);
 assert.equal((await post('clearNotifications',(await inbox()).map(n=>n.id))).status,200);
 currentUser=buyer;assert.equal(unread(await inbox()),2,'Another account clearing shared announcements must not affect this account');
 console.log('Notification API checks passed: persistent reads, clear, new arrivals, account isolation, bounded history, concurrency, authorization and preserved business records.');
}finally{sql.close();}})().catch(error=>{console.error(error);process.exitCode=1});
