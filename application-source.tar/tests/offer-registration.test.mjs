import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import ts from 'typescript';
import * as registration from '../app/offer-registration.mjs';

const offer = {type:'offer',status:'published',price:80,title_ar:'صناعة المحتوى بالذكاء الاصطناعي',registrationMode:'email',registrationEmail:'alkunt@yahoo.com',body_ar:'تفاصيل الحضور',bodyDoc_ar:{type:'doc',content:[]},file:'PRIVATE_FILE',extended_ar:'PRIVATE',instructions_ar:'PRIVATE',lessons:[{id:'private',file:'PRIVATE_LESSON'}]};
assert.equal(registration.isEmailRegistrationOffer(offer),true);
for (const email of ['bad','a@b.test\r\nBcc:stolen@example.test','a@b.test?cc=x','mailto:a@b.test']) assert.equal(registration.registrationEmail(email),'');
assert.equal(registration.isEmailRegistrationOffer({...offer,type:'book'}),false);
assert.throws(()=>registration.validateOfferRegistration(offer));
for (const extra of [{file:'secret'},{lessons:[{file:'secret'}]},{inBundle:true},{externalUrl:'https://example.test'}]) assert.throws(()=>registration.validateOfferRegistration({...offer,file:'',lessons:[],...extra}));
const valid = {...offer,file:'',lessons:[]};
registration.validateOfferRegistration(valid);
const request = registration.emailRegistrationRequest(valid,{name:'اسم اختباري',email:'reader@example.test',phone:'+965 50000000'});
const url = new URL(request.href);
assert.equal(url.protocol,'mailto:');
assert.equal(decodeURIComponent(url.pathname),'alkunt@yahoo.com');
assert.deepEqual([...url.searchParams.keys()],['subject','body']);
assert.match(url.searchParams.get('body'),/reader@example.test/);
assert.match(request.body,/يرجى تأكيد التسجيل/);
assert.match(request.subject,/صناعة المحتوى/);
assert.throws(()=>registration.emailRegistrationRequest(valid,{name:'Test\r\nBcc:evil',email:'x@example.test',phone:'+965 50000000'}));
assert.throws(()=>registration.emailRegistrationRequest(valid,{name:'Test',email:'invalid',phone:'+965 50000000'}));
assert.throws(()=>registration.emailRegistrationRequest(valid,{name:'Test',email:'x@example.test',phone:'not-phone'}));

const code=ts.transpileModule(fs.readFileSync('app/content-rules.ts','utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText;
const module={exports:{}};
vm.runInNewContext(code,{module,exports:module.exports,require:()=>registration,Date});
const {publicProduct,isPublicContent}=module.exports;
assert.equal(publicProduct(offer).body_ar,offer.body_ar);
assert.equal(publicProduct(offer).bodyDoc_ar.type,'doc');
assert.equal(publicProduct(offer).file,'');
assert.equal(publicProduct(offer).lessons[0].file,undefined);
assert.equal(publicProduct(offer).extended_ar,'');
assert.equal(isPublicContent(offer),false,'registration must not broaden file-download entitlements');
for (const patch of [{status:'draft'},{status:'archived'},{publishAt:'2099-01-01T00:00:00Z'},{type:'book'},{registrationMode:'digital'},{registrationEmail:'invalid'}]) {
  assert.equal(publicProduct({...offer,...patch}).body_ar,'');
  assert.equal(publicProduct({...offer,...patch}).bodyDoc_ar,null);
}
console.log('PASS: registration recipient validation, encoded mailto requests, public announcement boundaries and private file protection.');
