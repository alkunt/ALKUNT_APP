import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const dir=mkdtempSync(path.join(tmpdir(),'alkunt-test-'));process.env.DATA_DIR=dir;process.env.APP_ORIGIN='https://example.test';
const {sql,DB,BUCKET}=await import('../server/runtime.mjs');const auth=await import('../server/auth.mjs');
try{
const hash=await auth.passwordHash('Long password test 123!');assert.notEqual(hash,'Long password test 123!');assert.equal(await auth.passwordMatches('Long password test 123!',hash),true);assert.equal(await auth.passwordMatches('wrong',hash),false);
sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('u','customer@example.test','Customer',hash);
const token=auth.createSession('u');assert.equal(auth.sessionUser(token).userId,'u');assert.equal(auth.sessionUser(token+'x'),null);assert.ok(auth.sessionCookie(token).includes('HttpOnly'));assert.ok(auth.sessionCookie(token).includes('Secure'));auth.destroySession(token);assert.equal(auth.sessionUser(token),null);
assert.equal(auth.safeReturn('//evil.test'),'/');assert.equal(auth.safeReturn('/\\evil.test'),'/');assert.equal(auth.safeReturn('/?view=checkout'),'/?view=checkout');
assert.equal(auth.originAllowed(new Request('https://example.test/api/auth',{headers:{origin:'https://evil.test'}})),false);
for(let i=0;i<8;i++)assert.equal(auth.limit('test'),true);assert.equal(auth.limit('test'),false);
await assert.rejects(DB.batch([DB.prepare('INSERT INTO grants VALUES(?,?,?,?)').bind('g','u','p','x'),DB.prepare('INSERT INTO grants VALUES(?,?,?,?)').bind('g','u','p','x')]));assert.equal(sql.prepare('SELECT count(*) AS n FROM grants').get().n,0);
await BUCKET.put('safe-file',Buffer.from('hello'));assert.equal((await BUCKET.get('safe-file')).body.toString(),'hello');await assert.rejects(BUCKET.get('../outside'));await BUCKET.delete('safe-file');assert.equal(await BUCKET.get('safe-file'),null);
console.log('PASS: self-host password hashing, sessions, logout, CSRF origin, redirects, rate limits, transaction rollback and protected local file storage.');
}finally{sql.close();rmSync(dir,{recursive:true,force:true})}
