import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
const directory=mkdtempSync(path.join(tmpdir(),'alkunt-rich-media-'));
process.env.DATA_DIR=directory;process.env.APP_ORIGIN='https://app.example.test';delete process.env.BREVO_API_KEY;
const {sql}=await import('../server/runtime.mjs');
const {normalizeRichDoc,richDocHtml,richDocText,plainTextDoc,richLink}=await import('../app/rich-text.mjs');
const {emailTemplate}=await import('../app/marketing-template.mjs');
const m=await import('../server/marketing.mjs');
const media=await import('../server/marketing-media.mjs');
const owner={userId:'owner',email:'alkunt@yahoo.com'},member={userId:'member',email:'member@example.test'};
const uploadRequest=(bytes,name='sample.pdf',type='application/pdf')=>{const form=new FormData();form.set('file',new File([bytes],name,{type}));return new Request(process.env.APP_ORIGIN+'/api/marketing/media',{method:'POST',body:form});};
const document={type:'doc',content:[{type:'heading',attrs:{level:2,textAlign:'right'},content:[{type:'text',text:'معرفة عملية',marks:[{type:'textStyle',attrs:{fontFamily:'Tahoma',fontSize:'24px',color:'#073478'}}]}]},{type:'paragraph',content:[{type:'text',text:'نص مهم ',marks:[{type:'bold'},{type:'underline'}]},{type:'text',text:'<script>alert(1)</script> {{ contact.SECRET }}'}]},{type:'bulletList',content:[{type:'listItem',content:[{type:'paragraph',content:[{type:'text',text:'خطوة أولى'}]}]}]},{type:'blockquote',content:[{type:'paragraph',content:[{type:'text',text:'فكرة تستحق التطبيق'}]}]}]};
try{
 sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('owner',owner.email,'Owner','unchanged-owner-hash');sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('member',member.email,'Member','unchanged-member-hash');
 const original=sql.prepare('SELECT * FROM accounts ORDER BY id').all();
 assert.equal(richDocText(plainTextDoc('أول سطر\nسطر ثانٍ\n\nفقرة أخيرة')),'أول سطر\nسطر ثانٍ\n\nفقرة أخيرة');
 const html=richDocHtml(document);assert.match(html,/<h2/);assert.match(html,/<ul>/);assert.match(html,/<blockquote>/);assert.match(html,/font-family:Tahoma/);assert.match(html,/<strong>/);assert.match(html,/<u>/);assert.equal(html.includes('<script>'),false);assert.equal(html.includes('{{ contact.SECRET }}'),false);
 assert.equal(richLink('javascript:alert(1)'),'');assert.equal(richLink('//evil.test'),'');assert.equal(richLink('https://name:password@example.test'),'');assert.equal(richLink('/?view=blog'),'/?view=blog');
 const malicious={type:'doc',content:[{type:'paragraph',attrs:{textAlign:'right; background:url(javascript:alert(1))'},content:[{type:'text',text:'safe',marks:[{type:'link',attrs:{href:'data:text/html,<script>'}},{type:'textStyle',attrs:{fontFamily:'X;position:fixed',fontSize:'9999px',color:'url(evil)'}}]}]}]};
 assert.equal(richDocHtml(malicious),'<p>safe</p>');assert.throws(()=>normalizeRichDoc({type:'doc',content:[{type:'script',content:[]}]}));assert.throws(()=>normalizeRichDoc(plainTextDoc('x'.repeat(60001))));
 console.log('PASS: legacy text preservation, headings, fonts, lists, links and rich-text XSS/style limits.');

 await assert.rejects(media.uploadMarketingMedia(uploadRequest('%PDF-1.4'),null),{status:401});await assert.rejects(media.uploadMarketingMedia(uploadRequest('%PDF-1.4'),member),{status:403});
 await assert.rejects(media.uploadMarketingMedia(uploadRequest('<html><script>bad</script>','fake.png','image/png'),owner),{status:400});
 assert.equal(media.detectMarketingMedia(Buffer.from('ID3'+'\0'.repeat(20))),'audio/mpeg');assert.equal(media.detectMarketingMedia(Buffer.from('RIFF0000WAVE0000')),'audio/wav');assert.equal(media.detectMarketingMedia(Buffer.from('OggS0000')),'audio/ogg');assert.equal(media.detectMarketingMedia(Buffer.from('0000ftypM4A 0000')),'audio/mp4');assert.equal(media.detectMarketingMedia(Buffer.from('0000ftypisom0000')),'video/mp4');
 const pdf=await media.uploadMarketingMedia(uploadRequest('%PDF-1.4\nSample document','learning\n-guide.pdf'),owner);assert.equal(pdf.type,'application/pdf');assert.equal(pdf.name.includes('\n'),false);assert.equal(new URL(pdf.url).searchParams.get('token').length,64);
 assert.equal((await media.serveMarketingMedia(new Request(process.env.APP_ORIGIN+'/api/marketing/media?id='+pdf.id),null)).status,404);
 const wrong=new URL(pdf.url);wrong.searchParams.set('token','0'.repeat(64));assert.equal((await media.serveMarketingMedia(new Request(wrong),member)).status,404);
 const publicResponse=await media.serveMarketingMedia(new Request(pdf.url),null);assert.equal(publicResponse.status,200);assert.equal(publicResponse.headers.get('x-content-type-options'),'nosniff');assert.match(publicResponse.headers.get('cache-control'),/no-store/);assert.match(await publicResponse.text(),/^%PDF-/);
 assert.equal((await media.serveMarketingMedia(new Request(pdf.url,{headers:{range:'bytes=0-4'}}),null)).status,206);assert.equal((await media.serveMarketingMedia(new Request(pdf.url,{headers:{range:'bytes=99999-'}}),null)).status,416);
 assert.equal(media.normalizeMarketingMedia(pdf).id,pdf.id);assert.throws(()=>media.normalizeMarketingMedia({...pdf,url:pdf.url.replace('app.example.test','evil.test')}),{status:400});assert.throws(()=>media.normalizeMarketingMedia({...pdf,url:wrong.href}),{status:400});
 console.log('PASS: owner-only upload, real file signatures, audio/video/PDF support, capability isolation and byte ranges.');

 const campaign=m.saveCampaign({name:'Rich campaign',subject:'Learn with ALKUNT',body:'Intentionally ignored plain text',bodyDoc:document,media:pdf},owner);
 assert.equal(campaign.body,richDocText(document));assert.equal(campaign.media.id,pdf.id);
 const email=emailTemplate(campaign,process.env.APP_ORIGIN);assert.match(email,/<h2/);assert.match(email,/افتح ملف PDF/);assert.ok(email.includes('token='));assert.equal(email.includes('<script>'),false);assert.equal(email.includes('<video'),false);assert.match(email,/\{\{ unsubscribe \}\}/);
 const png=await media.uploadMarketingMedia(uploadRequest(new Uint8Array([137,80,78,71,13,10,26,10,0,0,0,0]),'cover.png','image/png'),owner);
 const imageEmail=emailTemplate({...campaign,media:png},process.env.APP_ORIGIN);assert.match(imageEmail,/<img /);assert.ok(imageEmail.includes(png.id));assert.equal(imageEmail.includes(pdf.id),false);
 assert.equal(sql.prepare("SELECT count(*) n FROM records WHERE kind='marketing-file'").get().n,2);assert.equal(m.dashboard().campaigns[0].status,'draft');
 console.log('PASS: safe rich campaign HTML, inline images and attachment links without sending any real mail.');

 m.recordRegistrationConsent({id:'member',email:member.email,name:'Member'},false);assert.equal(m.subscription(member).hasChoice,false);
 m.recordRegistrationConsent({id:'member',email:member.email,name:'Member'},'true');assert.equal(m.subscription(member).subscribed,false);
 m.recordRegistrationConsent({id:'member',email:member.email,name:'Member'},true);assert.equal(m.subscription(member).subscribed,true);assert.equal(m.subscription(owner).subscribed,false);
 await m.setSubscription(member,false,false);m.recordRegistrationConsent({id:'member',email:member.email,name:'Member'},true);assert.equal(m.subscription(member).subscribed,false);
 assert.deepEqual(sql.prepare('SELECT * FROM accounts ORDER BY id').all(),original);
 console.log('PASS: optional registration consent, no automatic enrollment and no restoration of an opt-out; credentials unchanged.');
}finally{sql.close();assert.ok(path.resolve(directory).startsWith(path.resolve(tmpdir())+path.sep+'alkunt-rich-media-'));rmSync(directory,{recursive:true,force:true});}
