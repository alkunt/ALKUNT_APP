import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
import assert from 'node:assert/strict';
const directory=mkdtempSync(path.join(tmpdir(),'alkunt-http-'));process.env.DATA_DIR=directory;process.env.COOKIE_SECURE='false';const port=31871,origin='http://127.0.0.1:'+port;process.env.APP_ORIGIN=origin;
const {sql}=await import('../server/runtime.mjs');const {passwordHash}=await import('../server/auth.mjs');const password=randomBytes(24).toString('base64url');
sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run('owner','alkunt@yahoo.com','Owner',await passwordHash(password));
const child=spawn(process.execPath,['node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port',String(port)],{env:{...process.env,NODE_ENV:'production'},stdio:['ignore','pipe','pipe']});let logs='';child.stdout.on('data',d=>logs+=d);child.stderr.on('data',d=>logs+=d);
async function request(url,body,cookie,headers={}){const r=await fetch(origin+url,{method:body?'POST':'GET',headers:{...(body?{'content-type':'application/json',origin}:{}),...(cookie?{cookie}:{}),...headers},body:body?JSON.stringify(body):undefined});const data=await r.json();return {r,data,cookie:r.headers.get('set-cookie')?.split(';')[0]}}
try{
let ready=false;for(let i=0;i<100;i++){try{const r=await fetch(origin);if(r.ok){ready=true;break}}catch{}await new Promise(r=>setTimeout(r,100))}assert.ok(ready,'Production server failed to start: '+logs);
const spoof=await request('/api/platform',null,null,{'oai-authenticated-user-email':'alkunt@yahoo.com','oai-authenticated-user-id':'owner'});assert.equal(spoof.data.user,null);
const denied=await request('/api/auth',{action:'login',email:'alkunt@yahoo.com',password},null,{origin:'https://evil.test'});assert.equal(denied.r.status,403);
const admin=await request('/api/auth',{action:'login',email:'alkunt@yahoo.com',password});assert.equal(admin.r.status,200);assert.ok(admin.cookie);
const profile=await request('/api/platform',null,admin.cookie);assert.equal(profile.data.user.role,'admin');
assert.equal((await request('/api/platform',{action:'settings',settings:{currency:'KWD',tax:0,payment:'Test transfer instructions',salesEnabled:true}},admin.cookie)).r.status,200);
assert.equal((await request('/api/platform',{action:'saveProduct',product:{id:'http-course',type:'course',title_ar:'اختبار',price:8,status:'published',body_ar:'PRIVATE LESSON'}},admin.cookie)).r.status,200);
const buyer=await request('/api/auth',{action:'register',email:'buyer@example.test',password,name:'Buyer'});assert.equal(buyer.r.status,200);
assert.equal((await request('/api/platform?product=http-course',null,buyer.cookie)).r.status,403);
const order=await request('/api/platform',{action:'checkout',ids:['http-course'],country:'KW',payer:'Buyer',phone:'+96512345678',expectedTotal:8},buyer.cookie);assert.equal(order.r.status,200);
assert.equal((await request('/api/platform',{action:'paymentLink',id:order.data.id,url:'https://pay.example.test/1'},buyer.cookie)).r.status,403);
assert.equal((await request('/api/platform',{action:'paymentLink',id:order.data.id,url:'https://pay.example.test/1'},admin.cookie)).r.status,200);
assert.equal((await request('/api/platform',{action:'review',id:order.data.id,status:'confirmed'},admin.cookie)).r.status,200);
assert.equal((await request('/api/platform?product=http-course',null,buyer.cookie)).data.product.body_ar,'PRIVATE LESSON');
await request('/api/platform',{action:'libraryVisibility',id:'http-course',hidden:true},buyer.cookie);assert.equal((await request('/api/platform',null,buyer.cookie)).data.hiddenLibrary.includes('http-course'),true);assert.equal((await request('/api/platform?product=http-course',null,buyer.cookie)).r.status,200);
await request('/api/auth',{action:'logout'},buyer.cookie);assert.equal((await request('/api/platform',null,buyer.cookie)).data.user,null);
console.log('PASS: production HTTP server, untrusted-header rejection, owner login, customer registration, cookie sessions, CSRF, Kuwait payment-link flow, authorization, purchase grants, independent library removal and logout.');
}finally{child.kill('SIGTERM');await new Promise(resolve=>child.once('exit',resolve));sql.close();rmSync(directory,{recursive:true,force:true})}
