import assert from 'node:assert/strict';
import {catalogCategory, catalogCategories, catalogItems, matchesCatalogCategory, isCatalogView} from '../app/catalog-categories.mjs';

const item = (id, type, category, extra={}) => ({id,type,category,price:5,status:'published',...extra});
for (const [type,view] of [['course','course'],['book','book'],['prompt','prompt'],['offer','offers']]) {
  const records = [
    item('one',type,'صناعة المحتوى',{category_en:'Content creation'}),
    item('two',type,'  صِناعَةُ\u200f  المحتوى  '),
    item('ai-one',type,'أدوات الصوت بالذكاء الاصطناعي'),
    item('ai-two',type,'أدوات التصميم بالذكاء الإصطناعي'),
    item('new-one',type,'برمجة المواقع'),
    item('new-two',type,'برمجة المواقع'),
    item('empty',type,''),
    item('other-section',type==='course'?'book':'course','نوع من قسم آخر')
  ];
  const before=JSON.stringify(records);
  const categories=catalogCategories(records,view);
  assert.equal(categories.length,4,view+' has one chip per distinct category');
  assert.equal(new Set(categories.map(c=>c.ar)).size,categories.length);
  const key=catalogCategory(records[0]).id;
  assert.deepEqual(catalogItems(records,view).filter(p=>matchesCatalogCategory(p,key)).map(p=>p.id),['one','two']);
  assert.equal(catalogItems(records,view).filter(p=>matchesCatalogCategory(p,catalogCategory(records[2]).id)).length,2);
  assert.equal(catalogCategories([...records,item('new-type',type,'تعلّم اللغات')],view).length,5);
  assert.equal(catalogCategories(records,view).find(c=>c.id===key).en,'Content creation');
  assert.equal(JSON.stringify(records),before,'Category grouping does not rewrite products or prices');
}

const now=Date.parse('2026-11-02T06:00:00Z');
const offers=[
  item('standalone','offer','التصميم'),
  item('discount-course','course','  التَصميم  ',{oldPrice:10}),
  item('discount-book','book','الكتابة',{oldPrice:15,offerEnd:'2026-11-03T09:00:00+03:00'}),
  item('discount-prompt','prompt','الكتابة',{oldPrice:9}),
  item('regular-book','book','نوع غير معروض'),
  item('expired-offer','offer','عرض منته',{offerEnd:'2026-11-02T09:00:00+03:00'}),
  item('invalid-offer','offer','موعد غير صالح',{offerEnd:'not-a-date'})
];
assert.deepEqual(catalogItems(offers,'offers',now).map(p=>p.id),['standalone','discount-course','discount-book','discount-prompt']);
assert.equal(catalogCategories(offers,'offers',now).length,2,'Offer categories include discounted courses/books/prompts and use the same expiry rule as the results');
assert.deepEqual(catalogItems(offers,'offers',now).filter(p=>matchesCatalogCategory(p,catalogCategory(offers[0]).id)).map(p=>p.id),['standalone','discount-course']);
assert.deepEqual(catalogCategories([],'offers',now),[]);
assert.equal(catalogCategory({category_ar:'أخبار المنصة',category:'قيمة قديمة'}).ar,'أخبار المنصة');
assert.equal(catalogCategory({category_en:'AI voice tools'}).id,catalogCategory({category:'أدوات البرمجة بالذكاء الاصطناعي'}).id);
assert.ok(['blog','course','book','prompt','offers'].every(isCatalogView));
assert.equal(isCatalogView('library'),false);
console.log('PASS: all four catalogs merge repeated types, preserve new types and translations, scope categories to displayed products, include discounted products in offers, and leave product records unchanged.');
