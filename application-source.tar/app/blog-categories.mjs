import {catalogCategory, catalogCategories, matchesCatalogCategory} from './catalog-categories.mjs';

export const blogCategory = catalogCategory;
export const blogCategories = products => catalogCategories(products, 'blog');
export const matchesBlogCategory = matchesCatalogCategory;
