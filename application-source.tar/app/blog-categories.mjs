const clean = value => typeof value === 'string'
  ? value.normalize('NFKC').replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '').replace(/\s+/g, ' ').trim()
  : '';

function categoryKey(value) {
  return clean(value).replace(/[\u0640\u064B-\u065F\u0670]/g, '').replace(/[أإآٱ]/g, 'ا').toLowerCase();
}

export function blogCategory(product) {
  const ar = clean(product?.category_ar) || clean(product?.category);
  const en = clean(product?.category_en);
  const name = ar || en;
  const key = categoryKey(name);
  if (!name || key === 'تعلم وتطور' || key === 'learn & grow') {
    return {id:'blog:general', ar:'تعلّم وتطوّر', en:'Learn & grow'};
  }
  // Existing AI subtopics belong to one type in the blog's category bar.
  if (/^ادوات .*الذكاء الاصطناعي(?: |$)/u.test(key)
    || /^(?:ai|artificial intelligence)(?: .+)? tools$/.test(key)) {
    return {id:'blog:ai-tools', ar:'أدوات الذكاء الاصطناعي', en:'AI tools'};
  }
  return {id:'blog:'+key, ar:name, en:en || name};
}

export function blogCategories(products) {
  const groups = new Map();
  for (const product of products) {
    if (product.type !== 'blog') continue;
    const category = blogCategory(product);
    const existing = groups.get(category.id);
    if (!existing) groups.set(category.id, category);
    else if (clean(product.category_en)) existing.en = category.en;
  }
  return [...groups.values()];
}

export function matchesBlogCategory(product, selected) {
  return selected === 'all' || blogCategory(product).id === selected;
}
