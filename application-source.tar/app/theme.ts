export const THEME_STORAGE_KEY = 'alkunt-theme';

// Runs before hydration so returning visitors see their chosen theme immediately.
export const THEME_INIT_SCRIPT = `(function(){var theme='light';try{if(localStorage.getItem(${JSON.stringify(THEME_STORAGE_KEY)})==='dark')theme='dark'}catch{}document.documentElement.dataset.theme=theme})()`;
