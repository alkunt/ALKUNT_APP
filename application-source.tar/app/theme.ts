export const THEME_STORAGE_KEY = 'alkunt-theme';
export type Theme = 'light' | 'dark';
export const DEFAULT_THEME:Theme = 'dark';

export function resolveTheme(value:string|null|undefined):Theme {
  return value==='light' || value==='dark' ? value : DEFAULT_THEME;
}

// Runs before hydration so returning visitors see their chosen theme immediately.
export const THEME_INIT_SCRIPT = `(function(){var theme=${JSON.stringify(DEFAULT_THEME)};try{var saved=localStorage.getItem(${JSON.stringify(THEME_STORAGE_KEY)});if(saved==='light'||saved==='dark')theme=saved}catch{}document.documentElement.dataset.theme=theme})()`;
