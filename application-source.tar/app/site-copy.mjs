export const defaultAbout = {
  ar: 'الكونت ALKUNT منصة للمحتوى التعليمي حول الذكاء الاصطناعي وصناعة المحتوى. تجمع الدورات والكتيبات ومكتبة الأوامر والمقالات في مكان واحد، مع محتوى مجاني ومنتجات مدفوعة.\n\nيمكنك تصفّح المحتوى، ونسخ الأوامر المتاحة، وإضافة المنتجات المدفوعة إلى السلة، ومتابعة طلباتك ومحتواك من حسابك.\n\nللتواصل: alkunt@yahoo.com',
  en: 'ALKUNT is a learning platform focused on artificial intelligence and content creation. It brings together courses, booklets, prompts and articles, including free content and paid products.\n\nBrowse resources, copy available prompts, add paid products to your cart, and track your orders and learning content from your account.\n\nContact: alkunt@yahoo.com'
};

const legacyFaqs = [
  {question_ar: 'كيف أشتري من داخل الكويت؟', question_en: 'How do I purchase from Kuwait?',
    answer_ar: 'أضف المنتج إلى السلة، ثم اختر داخل الكويت وأكّد طلب رابط الدفع. يرسل المالك الرابط إلى حسابك ضمن طلباتي، ويُفعّل المحتوى بعد التحقق من الدفع.',
    answer_en: 'Add the product to your cart, select Kuwait, and confirm the payment link request. The owner adds the link to My orders. Content unlocks after payment is verified.'},
  {question_ar: 'كيف أشتري من خارج الكويت؟', question_en: 'How do I purchase from outside Kuwait?',
    answer_ar: 'اختر خارج الكويت عند إتمام الطلب، واتبع تعليمات التحويل اليدوي ثم ارفع الإيصال للمراجعة.',
    answer_en: 'Select Outside Kuwait at checkout, follow the manual transfer instructions, and upload your receipt for review.'},
  {question_ar: 'أين أجد المحتوى بعد تفعيل الشراء؟', question_en: 'Where do I find my purchased content?',
    answer_ar: 'بعد تأكيد استلام الدفع، يظهر المحتوى في قسم مكتبتي داخل حسابك.',
    answer_en: 'After payment is confirmed, the content becomes available in My library.'},
  {question_ar: 'كيف أنسخ الأوامر؟', question_en: 'How do I copy prompts?',
    answer_ar: 'افتح صفحة الأمر أو المقال، ثم اضغط نسخ الأمر بجانب النسخة العربية أو الإنجليزية المتاحة.',
    answer_en: 'Open the prompt or article page and select Copy prompt for the available Arabic or English version.'}
];

export const defaultFaqs = legacyFaqs.map((question, index) => ({...question, ...[
  {answer_ar: 'أضف المنتج إلى السلة وسجّل الدخول إلى ALKUNT. راجع السعر بالدينار الكويتي ومبلغ الدفع المقابل بالدولار، ثم تابع إلى Gumroad باستخدام بريد حساب ALKUNT نفسه. تظهر الضرائب المطبقة في صفحة Gumroad قبل تأكيد الدفع، ويُتاح المحتوى بعد التحقق من نجاح العملية.',
    answer_en: 'Add the product to your cart and sign in to ALKUNT. Review the KWD price and the USD checkout amount, then continue to Gumroad using the same email as your ALKUNT account. Applicable taxes appear on Gumroad before payment confirmation. Content unlocks after successful payment is verified.'},
  {answer_ar: 'تستخدم عملية الشراء المسار نفسه داخل الكويت وخارجها: راجع مبلغ الدفع بالدولار في ALKUNT، ثم أكمل لدى Gumroad بوسيلة الدفع المتاحة لك. لا يلزم طلب رابط يدوي من المالك أو رفع إيصال تحويل لهذا المسار. قد يفرض بنكك رسوم تحويل عملة إضافية.',
    answer_en: 'The same checkout flow is used inside and outside Kuwait: review the USD amount in ALKUNT, then pay on Gumroad using an available payment method. This flow does not require a manually issued payment link or an uploaded bank-transfer receipt. Your bank may charge currency conversion fees.'},
  {answer_ar: 'بعد التحقق من الدفع، يظهر المنتج في «مكتبتي» داخل حساب ALKUNT. يرسل Gumroad إيصال الشراء ورابط المحتوى الذي يسلّمه عبره. إذا لم تظهر مشترياتك، تحقق من استخدام بريد الحساب نفسه ثم افتح طلبك أو تواصل مع alkunt@yahoo.com وأرفق رقم الطلب فقط، دون بيانات البطاقة.',
    answer_en: 'After payment is verified, the product appears in My library in your ALKUNT account. Gumroad sends a receipt and access to the content it delivers. If a purchase is missing, check that you used the same account email, then open your order or contact alkunt@yahoo.com with the order number, without card details.'},
  {}
][index]}));

export function resolvedFaqs(saved) {
  if (!Array.isArray(saved)) return defaultFaqs;
  return saved.map(question => {
    const result = {...question};
    // Update only exact obsolete defaults, preserving owner-authored content.
    for (const language of ['ar', 'en']) {
      const index = legacyFaqs.findIndex(old => old['question_' + language] === question['question_' + language]
        && old['answer_' + language] === question['answer_' + language]);
      if (index >= 0) result['answer_' + language] = defaultFaqs[index]['answer_' + language];
    }
    return result;
  });
}

export const defaultPolicies = {
  terms_ar: `آخر تحديث: 30 أكتوبر 2026

1. عن المنصة والمحتوى
تقدم ALKUNT محتوى رقميًا حول الذكاء الاصطناعي والتعلم وصناعة المحتوى، بما في ذلك المقالات والأوامر والكتيبات والدورات. توضح صفحة كل منتج وصفه وسعره وصيغته وحالة إتاحته. المحتوى الرقمي لا يتطلب شحنًا ماديًا، والمحتوى الموسوم «قريبًا» لا يعني أنه متاح للشراء أو التسليم الآن.

2. الحساب واستخدام المحتوى
استخدم بيانات صحيحة وبريدًا تملك الوصول إليه، وحافظ على سرية بيانات الدخول. راجع وصف المنتج ومتطلبات فتح ملفاته قبل الشراء. يخضع استخدام الملفات والأعمال للترخيص المبين معها ولحقوق أصحابها؛ ولا ينقل شراء نسخة ملكية حقوق التأليف أو يمنح إذنًا بإعادة بيعها أو نشرها دون ترخيص.

3. السعر والدفع
تعرض المنصة الأسعار بالدينار الكويتي، وتوضح مبلغ الدفع المقابل بالدولار الأمريكي قبل الانتقال إلى Gumroad. يعرض Gumroad الضرائب المطبقة والمبلغ المطلوب قبل تأكيد العملية، وقد يفرض بنك المشتري رسوم تحويل عملة. تُدخل بيانات الدفع في صفحة Gumroad ولا تُحفظ بيانات البطاقة في ALKUNT. راجع المبلغ النهائي المعروض لدى مزود الدفع قبل تأكيده.

4. التسليم وإتاحة المشتريات
استخدم بريد حساب ALKUNT نفسه عند الدفع لتسهيل ربط الشراء بحسابك. بعد التحقق من نجاح الدفع يُتاح المحتوى المرتبط في «مكتبتي»، ويرسل Gumroad إيصال الشراء وإمكانية الوصول إلى الملفات التي يسلّمها عبره. إغلاق صفحة الدفع أو ظهور رابط طلب وحده لا يؤكد نجاح السداد. إذا لم يظهر المحتوى، تواصل مع الدعم برقم الطلب وبريد الشراء.

5. مشكلات الشراء وطلبات الاسترجاع
إذا تعذر تنزيل الملف، أو لم يصلك المحتوى، أو تكرر الخصم، أو لم يطابق المنتج وصفه، راسل alkunt@yahoo.com أو رد على إيصال Gumroad مع رقم الطلب ووصف المشكلة. تُراجع الطلبات وفق حالة الشراء والسياسة المعروضة للمنتج لدى Gumroad والحقوق الواجبة التطبيق. تُعالج المبالغ المسترجعة المعتمدة عبر مزود الدفع. لا تضع هذه الصفحة مدة استرجاع موحدة بدل سياسة المنتج، ولا تحد الحقوق التي لا يجوز تقييدها نظامًا.

6. الدعم والتحديثات
للاستفسار عن حسابك أو مشترياتك استخدم صفحة التواصل أو البريد alkunt@yahoo.com. لا ترسل كلمات المرور أو رموز التحقق أو أرقام البطاقات. قد نحدّث هذه الصفحة عند تغير الخدمة، ويظهر تاريخ التحديث أعلاها. تُقرأ هذه الشروط مع وصف المنتج وسياسة الخصوصية وتعليمات Gumroad ذات الصلة.`,
  terms_en: `Last updated: 30 October 2026

1. Platform and content
ALKUNT provides digital content about AI, learning and content creation, including articles, prompts, booklets and courses. Each product page describes its content, price, format and availability. Digital products do not require physical shipping. A “coming soon” label does not mean that purchase or delivery is currently available.

2. Account and content use
Provide accurate details and an email address you can access, and keep your sign-in details secure. Review the product description and file requirements before buying. Use is subject to the license provided with the work and the rights of its owners. Buying a copy does not transfer copyright or grant permission to resell or republish it without a license.

3. Prices and payment
Prices are displayed in Kuwaiti dinars, with the equivalent US-dollar checkout amount shown before continuing to Gumroad. Gumroad displays applicable taxes and the amount payable before confirmation. Your bank may charge currency conversion fees. Payment details are entered on Gumroad; ALKUNT does not store card details. Review the final amount displayed by the payment provider before confirming it.

4. Delivery and purchase access
Use the same email as your ALKUNT account at checkout to help link the purchase to your account. After successful payment is verified, the associated content becomes available in My library. Gumroad sends a receipt and access to files delivered through its service. Closing checkout or receiving an order link alone does not confirm payment. If content is missing, contact support with the order number and purchase email.

5. Purchase problems and refund requests
If a file cannot be downloaded, content is missing, a charge is duplicated, or a product does not match its description, contact alkunt@yahoo.com or reply to the Gumroad receipt with your order number and a description of the issue. Requests are reviewed according to the purchase circumstances, the product policy shown on Gumroad and applicable rights. Approved refunds are processed through the payment provider. This page does not substitute a uniform refund period for the product policy or limit rights that cannot lawfully be restricted.

6. Support and updates
For account or purchase support, use the contact page or alkunt@yahoo.com. Do not send passwords, verification codes or card numbers. This page may be updated when the service changes; its revision date appears above. Read these terms together with the product description, privacy policy and relevant Gumroad instructions.`,
  privacy_ar: `آخر تحديث: 30 أكتوبر 2026

1. نطاق السياسة والتواصل
تشرح هذه الصفحة معالجة البيانات عند استخدام موقع ALKUNT وحساباته ومحتواه ونماذج التواصل والشراء. للاستفسار أو تقديم طلب متعلق ببياناتك، راسل alkunt@yahoo.com. تنطبق سياسات الخدمات الخارجية على البيانات التي تدخلها مباشرة لديها.

2. البيانات التي تقدمها
قد تشمل البيانات الاسم والبريد الإلكتروني والبلد ومفتاح الاتصال ورقم الهاتف وبيانات الحساب، إضافة إلى طلبات الشراء وحالتها ومعرّفات الدفع. تُحفظ كذلك اختياراتك مثل السلة والمفضلة والمكتبة وتقدم التعلم وتفضيلات الرسائل، وما ترسله عبر نماذج التواصل والتقييمات أو ترفعه من مرفقات. تُعالج بيانات تسجيل الدخول بواسطة نظام التوثيق المستخدم في المنصة؛ ولا تطلب منك الإدارة مشاركة كلمة المرور في الرسائل.

3. لماذا نستخدم البيانات؟
نستخدمها لتسجيل الدخول وحماية الحساب، ومعالجة الطلبات وربط المشتريات بمكتبتك، وتسليم المحتوى، والرد على الاستفسارات، وإدارة التقييمات والتفضيلات، وإرسال رسائل الخدمة والأخبار والعروض بحسب تفضيلاتك. قد تنتج بيانات تقنية وسجلات تشغيل عند استخدام الموقع، وتُستخدم لتشغيل الخدمة وتشخيص الأعطال والحد من إساءة الاستخدام.

4. الدفع ومزودو الخدمة
تتم عملية الدفع في صفحة Gumroad، حيث تدخل بيانات وسيلة الدفع وفق سياسته. لا تُحفظ بيانات البطاقة في ALKUNT. تتلقى المنصة بيانات العملية اللازمة للتحقق من الشراء وربطه بالحساب، مثل بريد الشراء ومعرّف العملية والمنتج وحالتها وقيمتها. تُحفظ نسخ ملفات المنتجات المدفوعة المجهزة للتسليم لدى Gumroad أيضًا. وتستعين المنصة بخدمات الاستضافة والتوثيق وإرسال البريد اللازمة لتشغيلها، وفق إعداداتها. سياسة Gumroad: https://gumroad.com/privacy

5. تخزين المتصفح وتفضيلات البريد
تستخدم المنصة ملفات الجلسة وتخزين المتصفح لتسجيل الدخول وتذكر اللغة والسلة وبعض تفضيلات الاستخدام. يمكنك إدارة تخزين الموقع من إعدادات متصفحك، وقد تحتاج إلى تسجيل الدخول مجددًا بعد مسحه. يمكنك إيقاف رسائل الأخبار والعروض من تفضيلات البريد في حسابك أو من رابط إلغاء الاشتراك في الرسالة. تبقى رسائل الحساب والطلبات الضرورية مرتبطة بالخدمة.

6. الاحتفاظ بالبيانات وطلباتك
تُحفظ البيانات لتشغيل الحساب وتوفير المحتوى وسجل المشتريات والدعم وحماية الخدمة. قد يلزم الاحتفاظ ببعض سجلات المعاملات أو التشغيل لمعالجة النزاعات أو المتطلبات الواجبة التطبيق. يمكنك طلب الاستفسار عن بياناتك أو تصحيحها أو مراجعة إمكانية حذفها عبر بريد الدعم؛ وقد نحتاج إلى التحقق من ملكية الحساب قبل تنفيذ الطلب، مع توضيح ما يمكن معالجته وما يلزم الاحتفاظ به.

7. حماية معلوماتك والتحديثات
شارك فقط المعلومات اللازمة لطلبك، ولا تُرسل بيانات بطاقة أو رمز تحقق أو كلمة مرور عبر نماذج التواصل أو البريد. قد تُحدّث هذه الصفحة عند تغير الخدمات أو طريقة معالجة البيانات، ويظهر تاريخ آخر تحديث أعلاها.`,
  privacy_en: `Last updated: 30 October 2026

1. Scope and contact
This page explains data processing when you use ALKUNT, its accounts, content, contact forms and checkout. Contact alkunt@yahoo.com with questions or requests about your data. External services apply their own policies to information you enter directly with them.

2. Information you provide
Information may include your name, email, country, calling code, phone number and account details, together with purchase records, statuses and payment identifiers. We also store choices such as your cart, favorites, library, learning progress and message preferences, and information or attachments submitted through contact forms and reviews. Sign-in information is processed by the authentication system used by the platform. Support does not ask you to share passwords in messages.

3. Purposes
We use information to sign you in and protect your account, process orders and link purchases to your library, deliver content, answer questions, manage reviews and preferences, and send service messages, news and offers according to your preferences. Technical information and operational logs may be generated when you use the site to operate the service, diagnose failures and limit misuse.

4. Payments and service providers
Payments take place on Gumroad, where you enter payment-method information under its policy. ALKUNT does not store card details. The platform receives transaction information needed to verify a purchase and link it to an account, such as purchase email, transaction and product identifiers, status and amount. Copies of paid-product files prepared for delivery are also stored with Gumroad. The platform uses hosting, authentication and email services needed to operate it according to its configuration. Gumroad privacy policy: https://gumroad.com/privacy

5. Browser storage and email preferences
The platform uses session cookies and browser storage to sign you in and remember language, cart and some usage preferences. You can manage site storage in your browser settings; clearing it may require signing in again. Stop news and offer emails using account email preferences or the unsubscribe link in a message. Necessary account and order messages remain part of the service.

6. Retention and your requests
Information is retained to operate accounts, provide content and purchase history, support customers and protect the service. Some transaction or operational records may need to be retained for disputes or applicable requirements. Contact support to ask about your data, correct it or request a review of deletion options. We may need to verify account ownership before acting and explain what can be processed and what must be retained.

7. Protecting your information and updates
Share only information needed for your request. Do not send card details, verification codes or passwords through contact forms or email. This page may be updated when services or data processing change. Its revision date appears above.`
};

export function sitePageText(pages, view, language = 'ar') {
  const saved = pages?.[view + '_' + language];
  const placeholders = ['سيُضاف النص المعتمد من إدارة المنصة هنا.', 'Approved platform information will appear here.'];
  if (typeof saved === 'string' && saved.trim() && !placeholders.includes(saved.trim())) return saved;
  return view === 'about' ? defaultAbout[language] || defaultAbout.ar
    : defaultPolicies[view + '_' + language] || '';
}
