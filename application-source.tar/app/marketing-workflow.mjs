export function campaignSendBlock(campaign,{configured,dirty,recipientCount,limit=200}){
 if(!configured)return 'connection';
 if(!campaign?.id||dirty)return 'save';
 if(campaign.status&&campaign.status!=='draft')return 'readonly';
 if(!campaign.tested)return 'test';
 if(!recipientCount)return 'audience';
 if(recipientCount>limit)return 'limit';
 return '';
}

// Keep the saved ID/version even if the provider rejects the subsequent test.
export async function prepareCampaignTest(campaign,dirty,{save,test,onSaved}){
 let current=campaign;
 if(!current.id||dirty){
  current=await save(current);
  if(!current)return null;
  onSaved(current);
 }
 return test(current);
}
