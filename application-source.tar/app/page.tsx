import Platform from './platform';
import type {Metadata} from 'next';
import {buildPageMetadata,siteOrigin} from './page-metadata.mjs';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

type Search = {[key:string]:string|string[]|undefined};
export async function generateMetadata({searchParams}:{searchParams:Promise<Search>}):Promise<Metadata> {
  const params = await searchParams;
  const id = Array.isArray(params.item) ? params.item[0] : params.item;
  let product = null;
  if (id) {
    try { product = (await import('../server/public-metadata.mjs')).publicProductMetadata(id); }
    catch { /* An unavailable item receives generic, non-indexable metadata. */ }
  }
  return buildPageMetadata(params, product, {origin: process.env.APP_ORIGIN}) as Metadata;
}

export default function Page(){return <Platform siteOrigin={siteOrigin(process.env.APP_ORIGIN)}/>}
