'use client';
import {useEffect,useState} from 'react';
import {Mail} from 'lucide-react';
export default function MarketingConsentInvite({userId,lang,onOpen}:{userId:string;lang:string;onOpen:()=>void}){
 const [visible,setVisible]=useState(false),t=(a:string,b:string)=>lang==='ar'?a:b;
 useEffect(()=>{let active=true;const key='marketing-consent-later:'+userId;try{if(sessionStorage.getItem(key))return;}catch{}fetch('/api/marketing/preferences',{cache:'no-store'}).then(async r=>{if(!r.ok)return;const d=await r.json();if(active&&d.subscribed&&!d.hasChoice)setVisible(true)}).catch(()=>{});return()=>{active=false}},[userId]);
 if(!visible)return null;
 return <aside className="marketing-consent-invite" aria-label={t('تفضيلات أخبار المنصة','Platform email preferences')}><Mail size={23}/><div><strong>{t('جديد ALKUNT وعروضه يصل إلى بريد حسابك','ALKUNT news and offers reach your account email')}</strong><p>{t('حسابك مشمول برسائل المنصة. يمكنك إيقافها أو إعادة تفعيلها من تفضيلات البريد في أي وقت.','Your registered account is included. You can stop or resume these emails in your email preferences at any time.')}</p></div><button className="secondary" onClick={onOpen}>{t('تفضيلات البريد','Email preferences')}</button><button className="text-link" onClick={()=>{try{sessionStorage.setItem('marketing-consent-later:'+userId,'1');}catch{}setVisible(false)}}>{t('إخفاء','Dismiss')}</button></aside>;
}
