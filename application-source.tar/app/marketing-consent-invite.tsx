'use client';
import {useEffect,useState} from 'react';
import {Mail} from 'lucide-react';
export default function MarketingConsentInvite({userId,lang,onOpen}:{userId:string;lang:string;onOpen:()=>void}){
 const [visible,setVisible]=useState(false),t=(a:string,b:string)=>lang==='ar'?a:b;
 useEffect(()=>{let active=true;const key='marketing-consent-later:'+userId;try{if(sessionStorage.getItem(key))return;}catch{}fetch('/api/marketing/preferences',{cache:'no-store'}).then(async r=>{if(!r.ok)return;const d=await r.json();if(active&&!d.hasChoice)setVisible(true)}).catch(()=>{});return()=>{active=false}},[userId]);
 if(!visible)return null;
 return <aside className="marketing-consent-invite" aria-label={t('دعوة اختيارية للنشرة البريدية','Optional newsletter invitation')}><Mail size={23}/><div><strong>{t('هل ترغب في جديد ALKUNT وعروضه؟','Would you like ALKUNT news and offers?')}</strong><p>{t('اختر موافقتك من إعدادات حسابك. الاشتراك اختياري ويمكن إلغاؤه في أي وقت.','Choose in your account settings. Subscription is optional and can be canceled at any time.')}</p></div><button className="secondary" onClick={onOpen}>{t('تفضيلات البريد','Email preferences')}</button><button className="text-link" onClick={()=>{try{sessionStorage.setItem('marketing-consent-later:'+userId,'1');}catch{}setVisible(false)}}>{t('لاحقاً','Later')}</button></aside>;
}
