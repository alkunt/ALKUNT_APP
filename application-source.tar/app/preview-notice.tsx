'use client';
import {useEffect,useState} from 'react';
export default function PreviewNotice(){const [preview,setPreview]=useState(false);useEffect(()=>{fetch('/api/auth').then(r=>r.json()).then(d=>setPreview(d.preview===true)).catch(()=>{});},[]);return preview?<aside className="preview-notice" dir="rtl">معاينة محلية للتصميم — حساباتك ومشترياتك في <a href="https://alkunt-app-production.up.railway.app/">الموقع العام</a>.</aside>:null;}
