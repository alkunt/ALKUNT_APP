import {env} from './runtime';
import {validPushEndpoint,vapidAuthorization} from './owner-notifications';
import {isPublished} from './content-rules';
async function records(kind:string){return (await env.DB!.prepare('SELECT * FROM records WHERE kind=?').bind(kind).all()).results.map((r:any)=>({...JSON.parse(r.data),id:r.id,owner:r.owner,created:r.created}));}
export async function deliverAudiencePush(userId?:string){
 const e=env as any;if(!e.VAPID_PRIVATE_JWK||!e.VAPID_PUBLIC_KEY)return {accepted:0,failed:0};let accepted=0,failed=0;
 const subscriptions=(await records('visitor-subscription')).filter((s:any)=>!userId||s.owner===userId);
 await Promise.all(subscriptions.map(async(s:any)=>{if(!validPushEndpoint(s.endpoint))return;try{const response=await fetch(s.endpoint,{method:'POST',headers:{Authorization:await vapidAuthorization(s.endpoint,e.VAPID_PRIVATE_JWK,e.VAPID_PUBLIC_KEY),TTL:'86400',Urgency:'normal'},redirect:'error',signal:AbortSignal.timeout(7000)});if(response.ok)accepted++;else{failed++;if([404,410].includes(response.status))await env.DB!.prepare('DELETE FROM records WHERE id=? AND kind=?').bind(s.id,'visitor-subscription').run();}}catch{failed++;}}));return {accepted,failed};
}
export async function announceProduct(product:any){
 if(!isPublished(product))return;
 const url='/?view='+(product.type==='bundle'?'prompt':product.type==='offer'?'offers':product.type)+'&item='+encodeURIComponent(product.id),date=new Date().toISOString();
 const notice={title:'محتوى جديد: '+product.title_ar,title_en:'New content: '+(product.title_en||product.title_ar),product:product.id,url,date};
 const inserted:any=await env.DB!.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').bind('announcement:'+product.id,'announcement','public',JSON.stringify(notice),date).run();
 if((inserted.meta?.changes??inserted.changes)===0)return;
 await deliverAudiencePush();
}
export async function notifyAccount(userId:string,title:string,titleEn:string,url='/?view=account'){
 const id=crypto.randomUUID(),date=new Date().toISOString();await env.DB!.prepare('INSERT INTO records VALUES(?,?,?,?,?)').bind(id,'notification',userId,JSON.stringify({title,title_en:titleEn,url,date}),date).run();await deliverAudiencePush(userId);
}
export async function notificationsFor(user:any){
 const products=await records('product'),published=new Set(products.filter(isPublished).map((p:any)=>p.id));
 const announcements=(await records('announcement')).filter((n:any)=>published.has(n.product));
 const personal=user?(await records('notification')).filter((n:any)=>n.owner===user.userId||user.email?.toLowerCase()==='alkunt@yahoo.com'&&n.owner==='admin'):[];
 return [...announcements,...personal].sort((a:any,b:any)=>(b.date||b.created).localeCompare(a.date||a.created)).slice(0,100).map(({owner,...n}:any)=>n);
}
