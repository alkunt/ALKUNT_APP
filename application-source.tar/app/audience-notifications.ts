import {env} from './runtime';
import {validPushEndpoint,vapidAuthorization} from './owner-notifications';
import {isPublished} from './content-rules';
async function records(kind:string,owner?:string){const query=owner===undefined?env.DB!.prepare('SELECT * FROM records WHERE kind=?').bind(kind):env.DB!.prepare('SELECT * FROM records WHERE kind=? AND owner=?').bind(kind,owner);return (await query.all()).results.map((r:any)=>({...JSON.parse(r.data),id:r.id,owner:r.owner,created:r.created}));}
export async function deliverAudiencePush(userId?:string){
 const e=env as any;if(!e.VAPID_PRIVATE_JWK||!e.VAPID_PUBLIC_KEY)return {accepted:0,failed:0};let accepted=0,failed=0;
 const subscriptions=(await records('visitor-subscription')).filter((s:any)=>!userId||s.owner===userId);
 await Promise.all(subscriptions.map(async(s:any)=>{if(!validPushEndpoint(s.endpoint))return;try{const response=await fetch(s.endpoint,{method:'POST',headers:{Authorization:await vapidAuthorization(s.endpoint,e.VAPID_PRIVATE_JWK,e.VAPID_PUBLIC_KEY),TTL:'86400',Urgency:'normal'},redirect:'error',signal:AbortSignal.timeout(7000)});if(response.ok)accepted++;else{failed++;if([404,410].includes(response.status))await env.DB!.prepare('DELETE FROM records WHERE id=? AND kind=?').bind(s.id,'visitor-subscription').run();}}catch{failed++;}}));return {accepted,failed};
}
export async function announceProduct(product:any){
 if(!isPublished(product))return;
 const url='/?view='+(product.type==='bundle'?'prompt':product.type==='offer'?'offers':product.type)+'&item='+encodeURIComponent(product.id),date=new Date().toISOString();
 const notice={title:'محتوى جديد: '+product.title_ar,title_en:'New content: '+(product.title_en||product.title_ar),product:product.id,url,date};
 const inserted:any=await env.DB!.prepare('INSERT OR IGNORE INTO records VALUES(?,?,?,?,?)').bind('announcement:'+product.id,'announcement','public',JSON.stringify(notice),date).run();
 if((inserted.meta?.changes??inserted.changes)===0)return;
 await deliverAudiencePush();
}
export async function notifyAccount(userId:string,title:string,titleEn:string,url='/?view=account'){
 const id=crypto.randomUUID(),date=new Date().toISOString();await env.DB!.prepare('INSERT INTO records VALUES(?,?,?,?,?)').bind(id,'notification',userId,JSON.stringify({title,title_en:titleEn,url,date}),date).run();await deliverAudiencePush(userId);
}
async function availableNotifications(user:any){
 const products=await records('product'),published=new Set(products.filter(isPublished).map((p:any)=>p.id));
 const announcements=(await records('announcement')).filter((n:any)=>published.has(n.product));
 const personal=user?(await records('notification')).filter((n:any)=>n.owner===user.userId||user.email?.toLowerCase()==='alkunt@yahoo.com'&&n.owner==='admin'):[];
 return [...announcements,...personal].sort((a:any,b:any)=>(b.date||b.created).localeCompare(a.date||a.created)).slice(0,100).map(({owner,...n}:any)=>n);
}
export async function notificationsFor(user:any){
 const available=await availableNotifications(user);
 const state=new Map<string,any>();
 for(const record of user?await records('notification-state',user.userId):[])state.set(record.notification,record);
 return available.filter((n:any)=>!state.get(n.id)?.dismissed).map((n:any)=>({...n,read:!!state.get(n.id)?.read}));
}
export async function updateNotificationState(user:any,ids:string[],dismiss=false){
 const allowed=new Set((await availableNotifications(user)).map((n:any)=>n.id));
 const selected=[...new Set(ids)].filter(id=>allowed.has(id));
 const date=new Date().toISOString();
 // Merge flags atomically so a late read request cannot undo a concurrent clear.
 const commands=selected.map(notification=>env.DB!.prepare("INSERT INTO records(id,kind,owner,data,created) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=json_patch(records.data,excluded.data) WHERE records.kind='notification-state' AND records.owner=excluded.owner").bind(
  'notification-state:'+encodeURIComponent(user.userId)+':'+encodeURIComponent(notification),
  'notification-state',user.userId,JSON.stringify({notification,read:true,...(dismiss?{dismissed:true}:{})}),date
 ));
 if(commands.length)await env.DB!.batch(commands);
 return selected.length;
}
