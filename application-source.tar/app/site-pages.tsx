'use client';
import {useState} from 'react';
import {Plus,Trash2} from 'lucide-react';
import {resolvedFaqs,sitePageText} from './site-copy.mjs';
export {defaultAbout,defaultFaqs} from './site-copy.mjs';

export function SitePagesForm({t,data,act,busy,notify}:any) {
  const [pages,setPages] = useState<any>(() => Object.fromEntries(
    ['about','terms','privacy'].flatMap(view => ['ar','en'].map(language =>
      [view + '_' + language, sitePageText(data.settings.pages, view, language)]))));
  const [faqs,setFaqs] = useState<any[]>(() => resolvedFaqs(data.settings.faqs));
  const updatePage = (key:string,value:string) => setPages((current:any) => ({...current,[key]:value}));
  return <form className="panel form-grid" onSubmit={async event => {
    event.preventDefault();
    if (await act('settings',{settings:{...data.settings,pages:{...data.settings.pages,...pages},faqs}}))
      notify(t('تم حفظ الصفحات والأسئلة الشائعة ونشرها','Pages and frequently asked questions saved and published'));
  }}>
    {(['about','terms','privacy'] as const).map(view => <section key={view}>
      <h2>{view === 'about' ? t('من نحن','About us') : view === 'terms'
        ? t('شروط الاستخدام والشراء','Terms of use and purchase') : t('سياسة الخصوصية','Privacy policy')}</h2>
      <div className="two-fields">{['ar','en'].map(language => {
        const key = view + '_' + language;
        return <label key={key}>{language === 'ar' ? 'المحتوى بالعربية' : 'English content'}
          <textarea className="large-text" dir={language === 'ar' ? 'rtl' : 'ltr'} value={pages[key]}
            onChange={event => updatePage(key,event.target.value)}/>
        </label>;
      })}</div>
    </section>)}
    <h2>{t('الأسئلة الشائعة','Frequently asked questions')}</h2>
    {faqs.map((question,index) => <div className="reader-editor-fields" key={index}>
      <div className="two-fields">{['ar','en'].map(language => <div key={language}>
        <label>{language === 'ar' ? 'السؤال بالعربية' : 'Question in English'}
          <input value={question['question_' + language] || ''} onChange={event => setFaqs(faqs.map((item,i) =>
            i === index ? {...item,['question_' + language]:event.target.value} : item))}/>
        </label>
        <label>{language === 'ar' ? 'الإجابة بالعربية' : 'Answer in English'}
          <textarea value={question['answer_' + language] || ''} onChange={event => setFaqs(faqs.map((item,i) =>
            i === index ? {...item,['answer_' + language]:event.target.value} : item))}/>
        </label>
      </div>)}</div>
      <button className="small-btn" type="button" onClick={() => setFaqs(faqs.filter((_,i) => i !== index))}>
        <Trash2 size={16}/>{t('حذف السؤال','Delete question')}
      </button>
    </div>)}
    <button className="secondary" type="button" onClick={() => setFaqs([...faqs,
      {question_ar:'',answer_ar:'',question_en:'',answer_en:''}])}>
      <Plus size={16}/>{t('إضافة سؤال وإجابة','Add question and answer')}
    </button>
    <button className="primary" disabled={busy}>{t('حفظ ونشر المحتوى','Save & publish content')}</button>
  </form>;
}
