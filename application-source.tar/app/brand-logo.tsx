import Image from 'next/image';

type BrandLogoProps = {width: number; height: number; priority?: boolean};

export default function BrandLogo({width, height, priority = false}: BrandLogoProps) {
  const props = {alt: 'ALKUNT', width, height, fetchPriority: priority ? 'high' as const : 'auto' as const};
  return <>
    <Image {...props} className="theme-logo-light" src="/alkunt-logo.png"/>
    <Image {...props} className="theme-logo-dark" src="/alkunt-logo-dark.png"/>
  </>;
}
