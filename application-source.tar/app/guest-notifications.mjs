export const GUEST_NOTIFICATION_STATE_KEY='alkunt-guest-notifications';

function readState(storage){
 try{
  const value=JSON.parse(storage.getItem(GUEST_NOTIFICATION_STATE_KEY)||'{}');
  const ids=list=>Array.isArray(list)?list.filter(id=>typeof id==='string').slice(-1000):[];
  return {read:ids(value?.read),dismissed:ids(value?.dismissed)};
 }catch{return {read:[],dismissed:[]};}
}

export function guestNotifications(notifications,storage){
 const state=readState(storage),read=new Set(state.read),dismissed=new Set(state.dismissed);
 return notifications.filter(n=>!dismissed.has(n.id)).map(n=>({...n,read:read.has(n.id)}));
}

export function updateGuestNotifications(storage,ids,dismiss=false){
 const state=readState(storage);
 state.read=[...new Set([...state.read,...ids])].slice(-1000);
 if(dismiss)state.dismissed=[...new Set([...state.dismissed,...ids])].slice(-1000);
 storage.setItem(GUEST_NOTIFICATION_STATE_KEY,JSON.stringify(state));
}
