// Registration makes an account eligible; an explicit opt-out always takes precedence.
export function marketingRecipient(contact,campaign={}){
 const eligible=contact.status==='subscribed'||contact.status==='registered'&&contact.registered;
 return !!(eligible&&!contact.blocked&&!contact.pending_sync&&(campaign.audience!=='buyers'||contact.buyer)&&(!campaign.country||contact.country===campaign.country));
}
