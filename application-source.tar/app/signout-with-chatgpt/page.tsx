'use client';
import {useState} from 'react';
export default function SignOut(){const [error,setError]=useState('');return <main className="shell page-section"><h1>تسجيل الخروج / Sign out</h1><button className="primary" onClick={async()=>{try{const r=await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:'{"action":"logout"}'});if(!r.ok)throw Error('تعذر تسجيل الخروج');location.assign('/')}catch(e:any){setError(e.message)}}}>تسجيل الخروج من هذا الجهاز</button><p role="alert">{error}</p></main>}
