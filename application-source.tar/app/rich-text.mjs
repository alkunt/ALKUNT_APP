export const RICH_FONTS=['Plex','Tahoma','Arial','Georgia','Courier New'];
export const RICH_SIZES=['14px','16px','18px','20px','24px','28px','32px','40px'];
const nodeTypes=new Set(['doc','paragraph','heading','text','hardBreak','bulletList','orderedList','listItem','blockquote','codeBlock','horizontalRule']);
export const escapeRichText=value=>String(value??'').replace(/[&<>"'{}]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;','{':'&#123;','}':'&#125;'}[c]));
export function richLink(value){try{if(typeof value!=='string'||/[\s\\]/.test(value)||value.length>2000)return '';if(value.startsWith('/')&&!value.startsWith('//'))return value;const u=new URL(value);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
export function plainTextDoc(text=''){return {type:'doc',content:String(text).split(/\n\s*\n/).map(p=>({type:'paragraph',content:p.split('\n').flatMap((line,i)=>[...(i?[{type:'hardBreak'}]:[]),...(line?[{type:'text',text:line}]:[])])}))};}
export function normalizeRichDoc(input){
 if(!input||input.type!=='doc'||!Array.isArray(input.content)||JSON.stringify(input).length>250000)throw Error('تنسيق النص غير صالح أو أكبر من الحد المسموح.');
 let nodes=0,characters=0;
 function visit(n,depth=0){
  if(!n||!nodeTypes.has(n.type)||++nodes>3000||depth>16)throw Error('تنسيق النص غير صالح أو معقد أكثر من المسموح.');
  const out={type:n.type};
  if(n.type==='text'){if(typeof n.text!=='string')throw Error('نص غير صالح.');characters+=n.text.length;if(characters>60000)throw Error('النص يتجاوز 60000 حرف.');out.text=n.text;}
  const attrs={};
  if(['paragraph','heading'].includes(n.type)&&['left','center','right','justify'].includes(n.attrs?.textAlign))attrs.textAlign=n.attrs.textAlign;
  if(n.type==='heading')attrs.level=[2,3,4].includes(n.attrs?.level)?n.attrs.level:2;
  if(n.type==='orderedList'&&Number.isInteger(n.attrs?.start)&&n.attrs.start>0&&n.attrs.start<=999)attrs.start=n.attrs.start;
  if(Object.keys(attrs).length)out.attrs=attrs;
  if(Array.isArray(n.marks)&&n.type==='text'){
   out.marks=n.marks.slice(0,8).flatMap(mark=>{
    if(['bold','underline','code'].includes(mark?.type))return [{type:mark.type}];
    if(mark?.type==='link'){const href=richLink(mark.attrs?.href);return href?[{type:'link',attrs:{href}}]:[];}
    if(mark?.type==='textStyle'){const a={};if(RICH_FONTS.includes(mark.attrs?.fontFamily))a.fontFamily=mark.attrs.fontFamily;if(RICH_SIZES.includes(mark.attrs?.fontSize))a.fontSize=mark.attrs.fontSize;if(/^#[0-9a-f]{6}$/i.test(mark.attrs?.color||''))a.color=mark.attrs.color;return Object.keys(a).length?[{type:'textStyle',attrs:a}]:[];}
    return [];
   });
  }
  if(n.type!=='text'&&Array.isArray(n.content))out.content=n.content.map(c=>visit(c,depth+1));
  return out;
 }
 return visit(input);
}
export function richDocText(input){const doc=normalizeRichDoc(input);const walk=n=>n.type==='text'?n.text:n.type==='hardBreak'?'\n':(n.content||[]).map(walk).join('')+(['paragraph','heading','listItem','codeBlock','blockquote'].includes(n.type)?'\n\n':'');return walk(doc).trim();}
export function richDocHtml(input,{email=false,origin='https://alkunt-app-production.up.railway.app'}={}){
 const doc=normalizeRichDoc(input),e=escapeRichText;
 function render(n){
  if(n.type==='text')return (n.marks||[]).reduce((s,m)=>{
   if(m.type==='bold')return `<strong>${s}</strong>`;if(m.type==='underline')return `<u>${s}</u>`;if(m.type==='code')return `<code>${s}</code>`;
   if(m.type==='link')return `<a href="${e(email&&m.attrs.href.startsWith('/')?new URL(m.attrs.href,origin).href:m.attrs.href)}" target="_blank" rel="noopener noreferrer" style="color:#075ab8;text-decoration:underline">${s}</a>`;
   if(m.type==='textStyle'){const a=m.attrs,style=[a.fontFamily&&'font-family:'+(email&&a.fontFamily==='Plex'?'Tahoma':a.fontFamily),a.fontSize&&'font-size:'+a.fontSize,a.color&&'color:'+a.color].filter(Boolean).join(';');return `<span style="${e(style)}">${s}</span>`;}return s;
  },e(n.text));
  if(n.type==='hardBreak')return '<br>';if(n.type==='horizontalRule')return '<hr>';
  const inner=(n.content||[]).map(render).join(''),alignment=n.attrs?.textAlign?'text-align:'+n.attrs.textAlign+';':'';
  const tags={paragraph:'p',heading:'h'+(n.attrs?.level||2),bulletList:'ul',orderedList:'ol',listItem:'li',blockquote:'blockquote',codeBlock:'pre'};
  if(n.type==='doc')return inner;
  const tag=tags[n.type],extra=n.type==='orderedList'&&n.attrs?.start?` start="${n.attrs.start}"`:'';
  const styles=alignment+(email?(n.type==='paragraph'?'margin:0 0 18px;line-height:1.95;':n.type==='blockquote'?'border-inline-start:3px solid #02a8be;padding:12px 18px;background:#f1f6fb;':n.type==='heading'?'line-height:1.6;margin:24px 0 14px;color:#102b51;':''):'');
  return `<${tag}${extra}${styles?` style="${e(styles)}"`:''}>${inner||'<br>'}</${tag}>`;
 }
 return render(doc);
}
