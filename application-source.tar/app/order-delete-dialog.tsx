'use client';
import {useState} from 'react';
import {Trash2} from 'lucide-react';

export default function OrderDeleteDialog({order,lang,onDeleted,onCancel}:{order:any,lang:string,onDeleted:()=>Promise<void>,onCancel:()=>void}){
 const t=(ar:string,en:string)=>lang==='ar'?ar:en;
 const [confirmation,setConfirmation]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState(''),[externalLinkClosed,setExternalLinkClosed]=useState(false);
 const externalLink=order.paymentMethod==='payment-link'&&order.status==='pending'&&!!order.paymentLink;
 return <><h2>{t('حذف الطلب نهائيًا','Permanently delete order')}</h2><p><strong dir="ltr">{order.number}</strong></p>
 <p>{t('سيُحذف سجل الطلب وتفاصيله من لوحة التحكم وحساب العميل، ولا يمكن استعادته. لا ينفّذ الحذف استردادًا ماليًا ولا يلغي وصول العميل إلى مشترياته المؤكدة.','The order and its details will be removed from the dashboard and customer account and cannot be restored. Deletion does not issue a refund or remove access to confirmed purchases.')}</p>
 {order.paymentMethod==='gumroad'&&<p>{t('سيُغلق رابط Gumroad الخاص بهذا الطلب قبل الحذف. تبقى معلومات التسوية الأساسية لمعالجة أي دفع سابق أو استرداد لاحق، دون إعادة إظهار الطلب.','This order’s Gumroad checkout will be closed before deletion. Minimal reconciliation data remains for earlier payments or later refunds without restoring the order.')}</p>}
 <form className="form-grid" onSubmit={async e=>{e.preventDefault();if(confirmation!==order.number||busy||externalLink&&!externalLinkClosed)return;setBusy(true);setError('');try{const response=await fetch('/api/orders/permanent-delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:order.id,confirmNumber:confirmation,confirmExternalLinkClosed:externalLinkClosed})});const result=await response.json();if(!response.ok)throw Error(result.error||t('تعذر حذف الطلب.','Unable to delete order.'));await onDeleted();}catch(err:any){setError(err.message||t('تعذر الاتصال. حاول مجددًا.','Connection failed. Try again.'));}finally{setBusy(false);}}}>
 {externalLink&&<label className="order-delete-external"><input type="checkbox" checked={externalLinkClosed} onChange={e=>setExternalLinkClosed(e.target.checked)} disabled={busy}/><span>{t('أؤكد أنني أغلقت رابط الدفع الخارجي لهذا الطلب لدى موفّره. لا يستطيع ALKUNT إغلاق هذا الرابط تلقائيًا.','I confirm this order’s external payment link is closed with its provider. ALKUNT cannot close that external link automatically.')}</span></label>}
 <label>{t('اكتب رقم الطلب كاملًا لتأكيد الحذف','Type the full order number to confirm deletion')}<input name="confirmNumber" dir="ltr" autoComplete="off" spellCheck={false} value={confirmation} onChange={e=>setConfirmation(e.target.value)} disabled={busy} required/></label>
 {error&&<p className="notice" role="alert">{error}</p>}
 <div className="row-actions"><button type="submit" className="primary destructive" disabled={busy||confirmation!==order.number||externalLink&&!externalLinkClosed}><Trash2 size={18} aria-hidden="true"/>{busy?t('جارٍ الحذف…','Deleting…'):t('تأكيد الحذف النهائي','Confirm permanent deletion')}</button><button type="button" className="secondary" disabled={busy} onClick={onCancel}>{t('إلغاء','Cancel')}</button></div>
 </form></>;
}
