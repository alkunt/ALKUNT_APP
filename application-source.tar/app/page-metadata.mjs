import {localizedText} from './localized-text.mjs';
import {contentCoverUrl,contentCoverVersion} from './content-cover.mjs';

export const DEFAULT_SITE_ORIGIN = 'https://alkunt-app-production.up.railway.app';
export const SITE_TITLE = 'ALKUNT | تعلّم الذكاء الاصطناعي وطبّقه بذكاء';
export const SITE_DESCRIPTION = 'دورات عملية وكتيبات ومكتبة أوامر عربية لتعلّم الذكاء الاصطناعي وتطبيقه بثقة.';

const views = {
  home: ['الرئيسية', 'Home'], course: ['الكورسات', 'Courses'], book: ['الكتيبات', 'Booklets'],
  prompt: ['مكتبة الأوامر', 'Prompt library'], bundle: ['باقات الأوامر', 'Prompt bundles'],
  offers: ['العروض', 'Offers'], blog: ['المدونة', 'Blog'], about: ['عن الكونت', 'About ALKUNT'],
  contact: ['تواصل معنا', 'Contact'], faq: ['الأسئلة الشائعة', 'Frequently asked questions'],
  terms: ['شروط الاستخدام والشراء', 'Terms of use and purchase'], privacy: ['سياسة الخصوصية', 'Privacy policy'],
  search: ['نتائج البحث', 'Search results'], library: ['مكتبتي', 'My library'],
  favorites: ['المفضلة', 'Favorites'], cart: ['سلة المشتريات', 'Shopping cart'],
  checkout: ['إتمام الشراء', 'Checkout'], account: ['حسابي', 'My account'], admin: ['لوحة التحكم', 'Dashboard']
};
const privateViews = new Set(['search', 'library', 'favorites', 'cart', 'checkout', 'account', 'admin']);
const productViews = new Set(['blog', 'prompt', 'book', 'course', 'bundle', 'offer', 'offers']);

export function siteOrigin(value) {
  try {
    const url = new URL(value || DEFAULT_SITE_ORIGIN);
    if (url.username || url.password || !['https:', 'http:'].includes(url.protocol)) return DEFAULT_SITE_ORIGIN;
    return url.origin;
  } catch { return DEFAULT_SITE_ORIGIN; }
}

export function publiclyListed(product, now = Date.now()) {
  if (!product || !['published', 'coming'].includes(product.status)) return false;
  return !product.publishAt || new Date(product.publishAt).getTime() <= now;
}

function plainDescription(value) {
  return String(value || '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
}

export function buildPageMetadata(params = {}, product = null, options = {}) {
  const first = value => Array.isArray(value) ? value[0] : value;
  const view = first(params.view) || 'home';
  const item = first(params.item) || '';
  const language = first(params.lang) === 'en' ? 'en' : 'ar';
  const english = language === 'en';
  const origin = siteOrigin(options.origin);
  const canonical = new URL('/', origin);
  if (view !== 'home') canonical.searchParams.set('view', view);
  if (item) canonical.searchParams.set('item', item);
  const productType = view === 'offers' ? 'offer' : view;
  const publicProduct = Boolean(item && product?.id === item && product.type === productType && productViews.has(view) && publiclyListed(product, options.now));
  const unavailable = Boolean(item && !publicProduct);
  const known = Boolean(views[view] || view === 'offer');
  const index = !unavailable && known && !privateViews.has(view);
  const label = views[view]?.[english ? 1 : 0] || (view === 'offer' ? (english ? 'Offer' : 'عرض') : (english ? 'Page unavailable' : 'الصفحة غير متاحة'));
  const title = unavailable ? (english ? 'Content unavailable | ALKUNT' : 'المحتوى غير متاح | ALKUNT')
    : publicProduct ? localizedText(product, language) + ' | ALKUNT'
    : view === 'home' ? (english ? 'ALKUNT | Learn and apply AI' : SITE_TITLE) : label + ' | ALKUNT';
  // Metadata uses catalog descriptions only, never protected article bodies or files.
  const description = publicProduct ? plainDescription(localizedText(product, language, 'desc')) || title
    : view === 'home' ? (english ? 'Practical courses, booklets and prompts to learn and apply AI.' : SITE_DESCRIPTION)
    : title;
  const image = publicProduct ? contentCoverUrl(product,language,origin) : origin + '/alkunt-logo.png';
  const graphUrl = new URL(canonical);
  if (publicProduct && first(params.share)===contentCoverVersion(product,language)) {
    if (english) graphUrl.searchParams.set('lang','en');
    graphUrl.searchParams.set('share',contentCoverVersion(product,language));
  }
  return {
    title, description, alternates: {canonical: canonical.href}, robots: {index, follow: index},
    openGraph: {type: publicProduct && product.type === 'blog' ? 'article' : 'website',
      title, description, url: graphUrl.href, siteName: 'ALKUNT', locale: english ? 'en_US' : 'ar_KW',
      images: [{url: image, alt: publicProduct ? localizedText(product, language) : 'ALKUNT — الكونت'}]},
    twitter: {card: 'summary_large_image', title, description, images: [image]}
  };
}
