import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'ALKUNT | تعلّم الذكاء الاصطناعي وطبّقه بذكاء',description:'منصة الكونت للدورات والكتيبات والأوامر وتطبيقات الذكاء الاصطناعي',manifest:'/manifest.webmanifest',icons:{icon:'/icon-192.png',apple:'/icon-192.png'},appleWebApp:{capable:true,title:'ALKUNT',statusBarStyle:'default'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body>{children}</body></html>}
