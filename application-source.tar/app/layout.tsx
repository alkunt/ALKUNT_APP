import './rich-text.css';
import './marketing.css';
import type { Metadata } from 'next';
import './globals.css';
import PreviewNotice from './preview-notice';
const site='https://alkunt-app-production.up.railway.app';
const title='ALKUNT | تعلّم الذكاء الاصطناعي وطبّقه بذكاء';
const description='دورات عملية وكتيبات ومكتبة أوامر عربية لتعلّم الذكاء الاصطناعي وتطبيقه بثقة.';
export const metadata:Metadata={metadataBase:new URL(site),title,description,alternates:{canonical:site+'/'},openGraph:{type:'website',locale:'ar_KW',siteName:'ALKUNT',url:site,title,description,images:[{url:'/alkunt-logo.png',alt:'ALKUNT — الكونت'}]},twitter:{card:'summary_large_image',title,description,images:['/alkunt-logo.png']},manifest:'/manifest.webmanifest',icons:{icon:'/icon-192.png',apple:'/icon-192.png'},appleWebApp:{capable:true,title:'ALKUNT',statusBarStyle:'default'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="ar" dir="rtl"><body><PreviewNotice/>{children}</body></html>}
