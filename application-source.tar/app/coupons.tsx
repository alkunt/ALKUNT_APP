'use client';
import {useState} from 'react';

type Product={id:string;price?:number;[key:string]:any};
type Coupon={id:string;code:string;type:string;value:number;products?:string[];active:boolean;used?:number;maxUses?:number;[key:string]:any};
type Copy=(ar:string,en:string)=>string;
type Props={products:Product[];coupons:Coupon[];busy:boolean;t:Copy;txt:(product:Product)=>string;money:(value:number)=>string;act:(action:string,payload:any)=>Promise<any>};

function ProductPicker({products,scope,setScope,selected,setSelected,t,txt,money,busy}:Pick<Props,'products'|'t'|'txt'|'money'|'busy'>&{
  scope:string;setScope:(value:string)=>void;selected:string[];setSelected:(value:string[])=>void;
}) {
  const [search,setSearch]=useState('');
  const choices:Product[]=[...products,...selected.filter(id=>!products.some(product=>product.id===id)).map(id=>({id,missing:true}))];
  const name=(product:Product)=>product.missing?t('منتج محذوف أو غير متاح','Deleted or unavailable product')+' ('+product.id+')':txt(product);
  const matches=choices.filter(product=>name(product).toLocaleLowerCase().includes(search.trim().toLocaleLowerCase()));
  return <div className="coupon-scope-picker">
    <label>{t('المنتجات التي يشملها الكوبون','Products covered by the coupon')}
      <select aria-label={t('المنتجات التي يشملها الكوبون','Products covered by the coupon')} value={scope} onChange={event=>setScope(event.target.value)} disabled={busy}>
        <option value="all">{t('جميع المنتجات','All products')}</option>
        <option value="selected">{t('منتجات محددة','Selected products')}</option>
      </select>
    </label>
    {scope==='selected'&&<fieldset className="coupon-product-picker" disabled={busy}>
      <legend>{t('اختر منتجًا أو أكثر بالاسم','Choose one or more products by name')}</legend>
      <label>{t('البحث عن منتج','Find a product')}<input type="search" value={search} onChange={event=>setSearch(event.target.value)} placeholder={t('اكتب اسم المنتج…','Enter a product name…')}/></label>
      <p className="coupon-selection-count" aria-live="polite">{t('عدد المنتجات المحددة: ','Selected products: ')+selected.length}</p>
      <div className="coupon-product-options">
        {matches.map(product=><label className="coupon-product-option" key={product.id}>
          <input type="checkbox" value={product.id} checked={selected.includes(product.id)} onChange={event=>setSelected(event.target.checked?[...selected,product.id]:selected.filter(id=>id!==product.id))}/>
          <span>{name(product)}{!product.missing&&<small>{money(Number(product.price)||0)}</small>}</span>
        </label>)}
        {!matches.length&&<p>{t('لا توجد منتجات مطابقة للاسم.','No products match that name.')}</p>}
      </div>
    </fieldset>}
  </div>;
}

function ScopeEditor({coupon,onClose,...props}:Props&{coupon:Coupon;onClose:()=>void}) {
  const [scope,setScope]=useState(coupon.products?.length?'selected':'all');
  const [selected,setSelected]=useState<string[]>(coupon.products||[]);
  const [error,setError]=useState('');
  return <form className="coupon-scope-editor" onSubmit={async event=>{
    event.preventDefault();
    if(scope==='selected'&&!selected.length){setError(props.t('اختر منتجًا واحدًا على الأقل.','Choose at least one product.'));return;}
    setError('');
    if(await props.act('coupon',{data:{...coupon,products:scope==='all'?[]:selected}}))onClose();
  }}>
    <h3>{props.t('تعديل منتجات الكوبون','Edit coupon products')}: <bdi>{coupon.code}</bdi></h3>
    <ProductPicker {...props} scope={scope} setScope={setScope} selected={selected} setSelected={setSelected}/>
    {error&&scope==='selected'&&!selected.length&&<p role="alert">{error}</p>}
    <div className="coupon-actions"><button className="primary" disabled={props.busy}>{props.t('حفظ المنتجات','Save products')}</button><button type="button" className="secondary" onClick={onClose} disabled={props.busy}>{props.t('إلغاء','Cancel')}</button></div>
  </form>;
}

export default function Coupons(props:Props) {
  const {coupons,products,t,txt,act,busy}=props;
  const [scope,setScope]=useState('all'),[selected,setSelected]=useState<string[]>([]),[error,setError]=useState(''),[editing,setEditing]=useState<string|null>(null),[deleting,setDeleting]=useState<string|null>(null);
  const summary=(coupon:Coupon)=>coupon.products?.length?coupon.products.map(id=>{
    const product=products.find(product=>product.id===id);
    return product?txt(product):t('منتج محذوف أو غير متاح','Deleted or unavailable product')+' ('+id+')';
  }).join(t('، ', ', ')):t('جميع المنتجات','All products');
  return <section className="panel coupons-panel">
    <h2>{t('الكوبونات','Coupons')}</h2>
    <form className="coupon-create" onSubmit={async event=>{
      event.preventDefault();
      if(scope==='selected'&&!selected.length){setError(t('اختر منتجًا واحدًا على الأقل.','Choose at least one product.'));return;}
      setError('');const form=event.currentTarget,fields=new FormData(form);
      const data={code:String(fields.get('code')||''),type:fields.get('type'),value:Number(fields.get('value')),maxUses:Number(fields.get('maxUses'))||0,expires:String(fields.get('expires')||''),active:true,products:scope==='all'?[]:selected};
      if(await act('coupon',{data})){form.reset();setScope('all');setSelected([]);}
    }}>
      <div className="coupon-fields">
        <label>{t('رمز الكوبون','Coupon code')}<input name="code" required placeholder="CODE" dir="ltr" disabled={busy}/></label>
        <label>{t('نوع الخصم','Discount type')}<select name="type" disabled={busy}><option value="percent">{t('نسبة مئوية %','Percentage %')}</option><option value="fixed">{t('مبلغ ثابت','Fixed amount')}</option></select></label>
        <label>{t('قيمة الخصم','Discount value')}<input name="value" required type="number" min="0" step="any" disabled={busy}/></label>
        <label>{t('الحد الأقصى للاستخدام (اختياري)','Maximum uses (optional)')}<input name="maxUses" type="number" min="1" step="1" disabled={busy}/></label>
        <label>{t('تاريخ الانتهاء (اختياري)','Expiry date (optional)')}<input name="expires" type="date" disabled={busy}/></label>
      </div>
      <ProductPicker {...props} scope={scope} setScope={setScope} selected={selected} setSelected={setSelected}/>
      {error&&scope==='selected'&&!selected.length&&<p role="alert">{error}</p>}
      <button className="primary" disabled={busy}>{t('إنشاء كوبون','Create coupon')}</button>
    </form>
    <div className="coupon-list">{coupons.map(coupon=><article className="coupon-card" key={coupon.id}>
      <div className="coupon-card-heading"><strong><bdi>{coupon.code}</bdi></strong><span>{coupon.value}{coupon.type==='percent'?'%':''}</span><span>{coupon.used||0} / {coupon.maxUses||'∞'}</span><div className="coupon-actions">
        <button type="button" className="small-btn" disabled={busy} onClick={()=>{setDeleting(null);setEditing(editing===coupon.id?null:coupon.id)}}>{t('تعديل المنتجات','Edit products')}</button>
        <button type="button" className="small-btn" disabled={busy} onClick={()=>act('coupon',{data:{...coupon,active:!coupon.active}})}>{coupon.active?t('إيقاف','Disable'):t('تفعيل','Enable')}</button>
        <button type="button" className="small-btn destructive" disabled={busy} onClick={()=>{setEditing(null);setDeleting(deleting===coupon.id?null:coupon.id)}}>{t('حذف الكوبون','Delete coupon')}</button>
      </div></div>
      <p className="coupon-product-summary"><strong>{t('المنتجات: ','Products: ')}</strong>{summary(coupon)}</p>
      {editing===coupon.id&&<ScopeEditor {...props} coupon={coupon} onClose={()=>setEditing(null)}/>}
      {deleting===coupon.id&&<div className="coupon-delete-confirm" role="group" aria-label={t('تأكيد حذف الكوبون ','Confirm coupon deletion ')+coupon.code}>
        <h3>{t('حذف الكوبون','Delete coupon')} <bdi>{coupon.code}</bdi>؟</h3>
        <p>{t('سيُزال الكوبون من القائمة ولن يُقبل في طلبات جديدة. تبقى الطلبات السابقة والمشتريات وسجل استخداماته محفوظة.','The coupon will be removed from this list and cannot be used for new orders. Existing orders, purchases and usage history are preserved.')}</p>
        <div className="coupon-actions"><button type="button" className="primary destructive" disabled={busy} onClick={async()=>{if(await act('deleteCoupon',{id:coupon.id,confirmCode:coupon.code}))setDeleting(null)}}>{t('تأكيد حذف الكوبون','Confirm coupon deletion')}</button><button type="button" className="secondary" disabled={busy} onClick={()=>setDeleting(null)}>{t('إلغاء','Cancel')}</button></div>
      </div>}
    </article>)}</div>
  </section>;
}
