import {siteOrigin} from './page-metadata.mjs';
import {localizedText} from './localized-text.mjs';

export function contentShareUrl(product, origin) {
  const url = new URL('/', siteOrigin(origin));
  url.searchParams.set('view', product.type === 'offer' ? 'offers' : product.type);
  url.searchParams.set('item', product.id);
  return url.href;
}

export function contentShareData(product, language, origin) {
  const site = siteOrigin(origin);
  let image = new URL('/alkunt-logo.png', site).href;
  try {
    const cover = new URL(product.cover || image, site);
    if (!cover.username && !cover.password &&
        (cover.protocol === 'https:' || cover.protocol === 'http:' && cover.origin === site)) image = cover.href;
  } catch { /* Use the same public brand image as the page metadata. */ }
  const title = localizedText(product, language) || 'ALKUNT';
  const url = contentShareUrl(product, site);
  return {title, url, image, text: title + '\n' + url, language: language === 'en' ? 'en' : 'ar'};
}

const escapeHtml = value => String(value).replace(/[&<>"']/g, character =>
  ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[character]));

export function contentShareHtml(data, imageDataUrl) {
  if (!/^data:image\/png;base64,[a-z\d+/=]+$/i.test(imageDataUrl)) throw Error('A PNG cover is required.');
  const title = escapeHtml(data.title), url = escapeHtml(data.url);
  return `<div dir="${data.language === 'en' ? 'ltr' : 'rtl'}"><p><a href="${url}"><img src="${imageDataUrl}" alt="${title}" width="600" style="max-width:100%;height:auto"></a></p><p><strong>${title}</strong></p><p><a href="${url}">${url}</a></p></div>`;
}
