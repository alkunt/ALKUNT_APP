import {siteOrigin} from './page-metadata.mjs';
import {localizedText} from './localized-text.mjs';
import {contentCoverUrl,contentCoverVersion} from './content-cover.mjs';

export function contentShareUrl(product, origin, language = 'ar') {
  const url = new URL('/', siteOrigin(origin));
  url.searchParams.set('view', product.type === 'offer' ? 'offers' : product.type);
  url.searchParams.set('item', product.id);
  if (language==='en') url.searchParams.set('lang','en');
  // A stable presentation version gives previously cached logo previews a fresh URL.
  url.searchParams.set('share',contentCoverVersion(product,language));
  return url.href;
}

export function contentShareData(product, language, origin) {
  const site = siteOrigin(origin);
  const image = contentCoverUrl(product,language,site);
  const title = localizedText(product, language) || 'ALKUNT';
  const url = contentShareUrl(product, site, language);
  return {title, url, image, text: title + '\n' + url, language: language === 'en' ? 'en' : 'ar'};
}

const escapeHtml = value => String(value).replace(/[&<>"']/g, character =>
  ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[character]));

export function contentShareFileData(data, file) {
  if (!file || file.type !== 'image/png' || !file.size) throw Error('A PNG cover is required.');
  // File-share targets may ignore a separate URL member; keep it in the caption.
  return {title:data.title, text:data.text, files:[file]};
}

export function canShareContentFile(data, file, navigator) {
  if (typeof navigator?.share !== 'function' || typeof navigator?.canShare !== 'function') return false;
  try { return navigator.canShare(contentShareFileData(data,file)) === true; }
  catch { return false; }
}

export function shareContentFile(data, file, navigator) {
  if (!canShareContentFile(data,file,navigator)) throw Error('File sharing unavailable.');
  // Start during the click; the PNG is already prepared.
  return navigator.share(contentShareFileData(data,file));
}

export async function copyContentShareText(data, clipboard) {
  if (typeof clipboard?.writeText !== 'function') throw Error('Text copy unavailable.');
  // Clipboard formats are alternatives, not a photo attachment with a caption.
  await clipboard.writeText(data.text);
}

export function contentShareHtml(data, imageDataUrl) {
  if (!/^data:image\/png;base64,[a-z\d+/=]+$/i.test(imageDataUrl)) throw Error('A PNG cover is required.');
  const title = escapeHtml(data.title), url = escapeHtml(data.url);
  return `<div dir="${data.language === 'en' ? 'ltr' : 'rtl'}"><p><a href="${url}"><img src="${imageDataUrl}" alt="${title}" width="600" style="max-width:100%;height:auto"></a></p><p><strong>${title}</strong></p><p><a href="${url}">${url}</a></p></div>`;
}
