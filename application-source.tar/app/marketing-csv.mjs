export function parseMarketingCsv(text){
 if(typeof text!=='string'||text.length>80000)throw Error('ملف CSV أكبر من الحد المسموح (80 كيلوبايت).');
 text=text.replace(/^\uFEFF/,'');const first=text.split(/\r?\n/,1)[0],separator=first.includes(';')&&!first.includes(',')?';':',';
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else if(quoted||cell==='')quoted=!quoted;else throw Error('علامات الاقتباس في CSV غير صحيحة.');}else if(c===separator&&!quoted){row.push(cell);cell='';}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()))rows.push(row);cell='';row=[];}else cell+=c;}
 if(quoted)throw Error('يوجد اقتباس غير مغلق في CSV.');row.push(cell);if(row.some(v=>v.trim()))rows.push(row);
 const header=(rows.shift()||[]).map(s=>s.trim().toLowerCase());const email=header.findIndex(s=>['email','البريد الإلكتروني','البريد الالكتروني','البريد'].includes(s)),name=header.findIndex(s=>['name','الاسم'].includes(s)),country=header.findIndex(s=>['country','البلد','الدولة'].includes(s));
 if(email<0)throw Error('أضف عمود email في أول سطر من CSV.');if(!rows.length||rows.length>1000)throw Error('يجب أن يحتوي الملف على 1–1000 عنوان.');
 return rows.map(r=>({email:r[email]?.trim()||'',name:name>=0?r[name]?.trim()||'':'',country:country>=0?r[country]?.trim()||'':''}));
}
