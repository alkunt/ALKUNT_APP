import type {NextRequest} from 'next/server';
import {publicProductMetadata} from '../../../server/public-metadata.mjs';
import {generatedContentCover} from '../../../server/content-cover-image';

export const dynamic='force-dynamic';
export const runtime='nodejs';

export async function GET(request:NextRequest) {
  const item=request.nextUrl.searchParams.get('item');
  const product=publicProductMetadata(item);
  // Check visibility before consulting the image cache, including after unpublishing.
  if (!product) return new Response('Cover unavailable',{status:404,headers:{'Cache-Control':'no-store'}});
  const language=request.nextUrl.searchParams.get('lang')==='en'?'en':'ar';
  try {
    return new Response(await generatedContentCover(product,language),{headers:{'Content-Type':'image/png','Cache-Control':'public, max-age=60','X-Content-Type-Options':'nosniff'}});
  } catch {
    return new Response('Cover unavailable',{status:503,headers:{'Cache-Control':'no-store'}});
  }
}
