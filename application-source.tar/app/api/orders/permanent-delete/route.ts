import {getChatGPTUser} from '../../../chatgpt-auth';
import {permanentlyDeleteOrder} from '../../../../server/gumroad.mjs';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request:Request){
 try{
  if(!process.env.APP_ORIGIN||request.headers.get('origin')!==process.env.APP_ORIGIN)return json({error:'Invalid origin'},403);
  const user=await getChatGPTUser();if(!user)return json({error:'Sign in required'},401);
  if(user.email?.trim().toLowerCase()!=='alkunt@yahoo.com')return json({error:'المالك فقط يستطيع حذف الطلبات نهائيًا.'},403);
  if(Number(request.headers.get('content-length')||0)>4096)return json({error:'Request too large'},413);
  let input:any;try{input=await request.json();}catch{return json({error:'Invalid request'},400);}
  return json(await permanentlyDeleteOrder(user,input));
 }catch(error:any){return json({error:error.status?error.message:'تعذر حذف الطلب. لم يتم تأكيد الحذف؛ حدّث القائمة وحاول مجددًا.'},error.status||500);}
}
