import {env} from '../../runtime';
import {getChatGPTUser} from '../../chatgpt-auth';
import {isPublished,isPublicContent} from '../../content-rules';
export const dynamic='force-dynamic';
const db=()=>env.DB!;
async function record(id:string){const r:any=await db().prepare('SELECT * FROM records WHERE id=?').bind(id).first();return r?{...JSON.parse(r.data),kind:r.kind,owner:r.owner}:null;}
async function role(u:any){return u?.email?.toLowerCase()==='alkunt@yahoo.com'?'admin':u?(await record('profile:'+u.userId))?.role||'customer':'guest';}
const error=(message:string,status=400)=>Response.json({error:message},{status});
export async function POST(req:Request){
if(!process.env.APP_ORIGIN||req.headers.get('origin')!==process.env.APP_ORIGIN)return error('Forbidden',403);
const u=await getChatGPTUser();if(!u)return error('Unauthorized',401);
const r=await role(u);if((await record('profile:'+u.userId))?.blocked)return error('Forbidden',403);
if(Number(req.headers.get('content-length'))>42*1024*1024)return error('Maximum upload is 40MB');
const form=await req.formData();const file=form.get('file') as File;const purpose=String(form.get('purpose')||'receipt');
if(!['receipt','content','cover'].includes(purpose)||purpose!=='receipt'&&!['admin','editor'].includes(r))return error('Forbidden',403);
const limit=purpose==='receipt'?5:purpose==='cover'?10:40;
if(!file||typeof file.arrayBuffer!=='function'||!file.size||file.size>limit*1024*1024)return error('Maximum file size: '+limit+'MB');
const bytes=new Uint8Array(await file.arrayBuffer());const magic=String.fromCharCode(...bytes.slice(0,16));
let type='application/octet-stream';
if(bytes[0]===137&&magic.slice(1,4)==='PNG'&&bytes[4]===13&&bytes[5]===10)type='image/png';
else if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255)type='image/jpeg';
else if(magic.startsWith('RIFF')&&magic.slice(8,12)==='WEBP')type='image/webp';
else if(magic.startsWith('GIF87a')||magic.startsWith('GIF89a'))type='image/gif';
else if(magic.slice(4,8)==='ftyp'&&['avif','avis'].includes(magic.slice(8,12)))type='image/avif';
else if(magic.startsWith('%PDF-'))type='application/pdf';
else if(magic.slice(4,8)==='ftyp')type='video/mp4';
else if(bytes[0]===26&&bytes[1]===69&&bytes[2]===223&&bytes[3]===163)type='video/webm';
if(purpose==='cover'&&!type.startsWith('image/'))return error('Select a PNG, JPG, WebP, GIF or AVIF image');
if(purpose==='receipt'&&!['image/png','image/jpeg','image/webp','application/pdf'].includes(type))return error('Receipt must be a PNG, JPG, WebP or PDF file');
const id=crypto.randomUUID();await env.BUCKET!.put(id,bytes,{httpMetadata:{contentType:type}});
await db().prepare('INSERT INTO records VALUES(?,?,?,?,?)').bind(id,'file',u.userId,JSON.stringify({purpose,name:file.name.slice(0,250),type,size:file.size}),new Date().toISOString()).run();return Response.json({id,name:file.name});}
export async function GET(req:Request){
const u=await getChatGPTUser();if(u&&(await record('profile:'+u.userId))?.blocked)return error('Forbidden',403);
const key=new URL(req.url).searchParams.get('id')||'';const f=await record(key);if(!f||f.kind!=='file')return error('Not found',404);
const r=await role(u);let allowed=r==='admin'||f.purpose==='receipt'&&!!u&&(f.owner===u.userId||r==='support')||['content','cover'].includes(f.purpose)&&r==='editor';
if(!allowed&&['cover','content'].includes(f.purpose)){const rows=(await db().prepare('SELECT data FROM records WHERE kind=?').bind('product').all()).results;allowed=rows.some((x:any)=>{const p=JSON.parse(x.data);return f.purpose==='cover'?(isPublished(p)||p.status==='coming')&&p.cover==='/api/files?id='+key:isPublished(p)&&((isPublicContent(p)&&p.file===key)||(p.lessons||[]).some((l:any)=>l.preview&&(l.file===key||l.video===key))); });}
if(!allowed&&u&&f.purpose==='content'){const rows=(await db().prepare('SELECT r.data FROM records r JOIN grants g ON g.product=r.id WHERE g.user=? AND r.kind=?').bind(u.userId,'product').all()).results;allowed=rows.some((x:any)=>{const p=JSON.parse(x.data);return p.file===key||(p.lessons||[]).some((l:any)=>l.file===key||l.video===key);});}
if(!allowed&&u&&f.purpose==='content'){const bundle=await db().prepare('SELECT id FROM grants WHERE user=? AND product=?').bind(u.userId,'prompt-bundle').first();if(bundle){const rows=(await db().prepare('SELECT data FROM records WHERE kind=?').bind('product').all()).results;allowed=rows.some((x:any)=>{const p=JSON.parse(x.data);return p.type==='prompt'&&isPublished(p)&&p.file===key;});}}
if(!allowed)return error('Forbidden',u?403:401);
const obj=await env.BUCKET!.get(key);if(!obj)return error('Not found',404);
const inline=/^(image\/(png|jpeg|webp|gif|avif)|video\/(mp4|webm)|application\/pdf)$/.test(f.type);
return new Response(obj.body,{headers:{'Content-Type':f.type,'Content-Disposition':`${inline?'inline':'attachment'}; filename*=UTF-8''${encodeURIComponent(f.name)}`,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"sandbox; default-src 'none'"}});}
