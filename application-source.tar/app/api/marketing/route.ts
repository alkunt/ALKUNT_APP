import {getChatGPTUser} from '../../chatgpt-auth';
import {originAllowed} from '../../../server/auth.mjs';
import {requireOwner,initMarketing,dashboard,saveCampaign,cloneCampaign,testCampaign,launchCampaign,refreshCampaign,pauseCampaign,importContacts,connection,syncContacts,MarketingError} from '../../../server/marketing.mjs';
import {readMarketingBody as readBody} from '../../../server/marketing-http.mjs';
export const dynamic='force-dynamic';
export const runtime='nodejs';
export const maxDuration=120;
const reply=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){try{requireOwner(await getChatGPTUser());return reply(dashboard());}catch(e:any){return reply({error:e instanceof MarketingError?e.message:'تعذر تحميل التسويق بالبريد.'},e.status||500);}}
export async function POST(req:Request){try{
 if(!originAllowed(req))return reply({error:'Invalid origin'},403);
 const user=await getChatGPTUser();requireOwner(user);if(process.env.APP_PREVIEW_MODE==='true')return reply({error:'الإرسال والتعديل معطلان في المعاينة.'},403);initMarketing();
 const b=await readBody(req);if(!b||typeof b!=='object'||Array.isArray(b))throw new MarketingError('طلب غير صالح.');
 switch(b.action){
 case 'save':return reply({campaign:saveCampaign(b.campaign,user)});
 case 'duplicate':return reply({campaign:cloneCampaign(b.id,user)});
 case 'test':return reply({campaign:await testCampaign(b.id,b.version,user)});
 case 'launch':return reply({campaign:await launchCampaign(b.id,b.version,b.scheduledAt,b.confirm,user)});
 case 'refresh':return reply({campaign:await refreshCampaign(b.id,user)});
 case 'pause':return reply({campaign:await pauseCampaign(b.id,user)});
 case 'import':return reply(importContacts(b.contacts,b.consent,b.source,user));
 case 'connection':return reply(await connection());
 case 'sync-contacts':return reply(await syncContacts(user));
 default:throw new MarketingError('العملية غير متاحة.');
 }
 }catch(e:any){return reply({error:e instanceof MarketingError?e.message:'تعذر إتمام العملية. حدّث الحالة قبل إعادة الإرسال.'},e.status||500);}}
