import {getChatGPTUser} from '../../../chatgpt-auth';
import {originAllowed,limit} from '../../../../server/auth.mjs';
import {subscription,setSubscription,MarketingError} from '../../../../server/marketing.mjs';
import {readMarketingBody as readBody} from '../../../../server/marketing-http.mjs';
export const dynamic='force-dynamic';
const reply=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){try{return reply(subscription(await getChatGPTUser()));}catch(e:any){return reply({error:e instanceof MarketingError?e.message:'تعذر تحميل التفضيل.'},e.status||500);}}
export async function POST(req:Request){try{if(!originAllowed(req))return reply({error:'Invalid origin'},403);const user=await getChatGPTUser();if(!user)return reply({error:'تسجيل الدخول مطلوب.'},401);if(process.env.APP_PREVIEW_MODE==='true')return reply({error:'التعديل معطل في المعاينة.'},403);if(!limit('marketing:preference:'+user.userId,10))return reply({error:'انتظر قبل تغيير التفضيل مجدداً.'},429);const b=await readBody(req);if(!b||typeof b!=='object'||Array.isArray(b))throw new MarketingError('طلب غير صالح.');return reply(await setSubscription(user,b.subscribe,b.consent));}catch(e:any){return reply({error:e instanceof MarketingError?e.message:'تعذر حفظ التفضيل.'},e.status||500);}}
