import {getChatGPTUser} from '../../../chatgpt-auth';
import {originAllowed,limit} from '../../../../server/auth.mjs';
import {requireOwner,MarketingError} from '../../../../server/marketing.mjs';
import {uploadMarketingMedia,serveMarketingMedia} from '../../../../server/marketing-media.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
const error=(e:any)=>Response.json({error:e instanceof MarketingError?e.message:'تعذر إتمام رفع الملف.'},{status:e.status||500,headers:{'Cache-Control':'no-store'}});
export async function POST(req:Request){try{if(!originAllowed(req))return Response.json({error:'Forbidden'},{status:403});const user=await getChatGPTUser();requireOwner(user);if(process.env.APP_PREVIEW_MODE==='true')return Response.json({error:'الرفع معطل في المعاينة.'},{status:403});if(!limit('marketing:media:'+user!.userId,20))return Response.json({error:'انتظر قبل رفع ملفات أخرى.'},{status:429});return Response.json({media:await uploadMarketingMedia(req,user)},{headers:{'Cache-Control':'no-store'}});}catch(e){return error(e);}}
export async function GET(req:Request){try{return await serveMarketingMedia(req,await getChatGPTUser());}catch{return new Response(null,{status:404});}}
