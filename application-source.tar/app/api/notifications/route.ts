import {cookies} from 'next/headers';
import {env} from '../../runtime';import {getChatGPTUser} from '../../chatgpt-auth';import {validPushEndpoint} from '../../owner-notifications';import {notificationsFor} from '../../audience-notifications';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'no-store'};
export async function GET(){const user=await getChatGPTUser();return Response.json({notifications:await notificationsFor(user),publicKey:env.VAPID_PUBLIC_KEY||'',pushConfigured:!!(env.VAPID_PRIVATE_JWK&&env.VAPID_PUBLIC_KEY)},{headers});}
export async function POST(req:Request){
 if(!process.env.APP_ORIGIN||req.headers.get('origin')!==process.env.APP_ORIGIN)return Response.json({error:'Forbidden'},{status:403,headers});
 let b:any;try{b=await req.json()}catch{return Response.json({error:'Invalid request'},{status:400,headers});}
 if(!b||!['subscribe','unsubscribe'].includes(b.action)||typeof b.endpoint!=='string'||b.endpoint.length>4096||!validPushEndpoint(b.endpoint))return Response.json({error:'Invalid subscription'},{status:400,headers});
 const jar=await cookies(),user=await getChatGPTUser(),existing=jar.get('alkunt-alert-device')?.value;const device=existing&&/^[a-f0-9-]{36}$/.test(existing)?existing:crypto.randomUUID();
 const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(b.endpoint)))).map(x=>x.toString(16).padStart(2,'0')).join('');const id='visitor-push:'+hash;
 const old:any=await env.DB!.prepare('SELECT data FROM records WHERE id=?').bind(id).first();if(old&&JSON.parse(old.data).device!==device)return Response.json({error:'Subscription belongs to a different device'},{status:403,headers});
 if(b.action==='unsubscribe')await env.DB!.prepare('DELETE FROM records WHERE id=? AND kind=?').bind(id,'visitor-subscription').run();
 else await env.DB!.prepare('INSERT INTO records VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET owner=excluded.owner,data=excluded.data,created=excluded.created').bind(id,'visitor-subscription',user?.userId||'guest:'+device,JSON.stringify({endpoint:b.endpoint,device}),new Date().toISOString()).run();
 return Response.json({ok:true},{headers:{...headers,'Set-Cookie':'alkunt-alert-device='+device+'; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000'+(process.env.COOKIE_SECURE==='false'?'':'; Secure')}});
}
