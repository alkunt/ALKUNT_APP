import {authenticateWebhook,readPaymentBody,verifyPaymentSale} from '../../../../../server/gumroad.mjs';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function POST(request:Request){
 try{
  authenticateWebhook(new URL(request.url).searchParams.get('key'));
  const body=await readPaymentBody(request);
  if(body?.test===true||body?.test==='true'||body?.is_test_purchase===true||body?.is_test_purchase==='true')return json({ok:true,ignored:'test_event'});
  return json(await verifyPaymentSale(body?.sale_id||body?.id));
 }catch(error:any){return json({error:error.status===403?'Forbidden':error.status?'Payment verification incomplete':'Unable to verify payment'},error.status||500);}
}
