import {getChatGPTUser} from '../../../chatgpt-auth';
import {gumroadStatus,createPaymentQuote,startPayment,retryPayment,checkPayment,paymentConnection,readPaymentBody} from '../../../../server/gumroad.mjs';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){return json(gumroadStatus());}
export async function POST(request:Request){
 try{
  if(!process.env.APP_ORIGIN||request.headers.get('origin')!==process.env.APP_ORIGIN)return json({error:'Invalid origin'},403);
  const user=await getChatGPTUser();if(!user)return json({error:'سجّل الدخول لمتابعة الدفع.'},401);
  if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'Invalid content type'},415);
  const body=await readPaymentBody(request);if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid body'},400);
  if(body.action==='quote')return json(await createPaymentQuote(user,body));
  if(body.action==='checkout')return json(await startPayment(user,body));
  if(body.action==='retry')return json(await retryPayment(user,body.id));
  if(body.action==='check')return json(await checkPayment(user,body.id));
  if(body.action==='connection')return json(await paymentConnection(user));
  return json({error:'Unknown action'},400);
 }catch(error:any){return json({error:error.status?error.message:'تعذر إكمال الطلب. لم يتم تأكيد الدفع.',...(error.orderId?{orderId:error.orderId}:{})},error.status||500);}
}
