import {getChatGPTUser} from '../../../../chatgpt-auth';
import {readPaymentBody} from '../../../../../server/gumroad.mjs';
import {deliveryStatus,prepareProductDelivery} from '../../../../../server/gumroad-delivery.mjs';
export const dynamic='force-dynamic';
export const runtime='nodejs';
export const maxDuration=180;
const json=(data:any,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(request:Request){
 try{return json(deliveryStatus(await getChatGPTUser(),new URL(request.url).searchParams.get('product')));}
 catch(error:any){return json({error:error.status?error.message:'تعذر قراءة حالة التسليم.'},error.status||500);}
}
export async function POST(request:Request){
 try{
  if(!process.env.APP_ORIGIN||request.headers.get('origin')!==process.env.APP_ORIGIN)return json({error:'Invalid origin'},403);
  if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'Invalid content type'},415);
  const user=await getChatGPTUser(),body=await readPaymentBody(request);
  if(body?.action!=='prepare')return json({error:'Unknown action'},400);
  return json(await prepareProductDelivery(user,body.productId));
 }catch(error:any){return json({error:error.status?error.message:'تعذر تجهيز التسليم. أعد المحاولة.'},error.status||500);}
}
