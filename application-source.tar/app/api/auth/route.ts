import {randomUUID} from 'node:crypto';
import {sql} from '../../../server/runtime.mjs';
import {ownerEmail,originAllowed,passwordHash,passwordMatches,limit,createSession,sessionCookie,destroySession,cookieName,safeReturn,sessionUser} from '../../../server/auth.mjs';
import {supabaseEnabled,signupSupabase,resendSupabase,supabaseRequest,verifiedSupabaseUser,syncSupabaseUser,AuthServiceError} from '../../../server/supabase-auth.mjs';
import {notifyOwner} from '../../owner-notifications';
import {cookies} from 'next/headers';
import {mailConfigured} from '../../../server/mail.mjs';
import {requestLocalReset,resetLocalPassword,recordPasswordChange} from '../../../server/password-recovery.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
const headers={'Cache-Control':'no-store'};
const reply=(error:string,status=400)=>Response.json({error},{status,headers});
export function GET(){return Response.json({supabaseEnabled:supabaseEnabled(),emailConfirmationRequired:supabaseEnabled(),recoveryConfigured:mailConfigured()},{headers});}
async function finishRemote(accessToken:string,returnTo:unknown){
  const remote=await verifiedSupabaseUser(accessToken);
  const {user,created}=await syncSupabaseUser(remote);
  const profile:any=sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id);
  if(profile&&JSON.parse(profile.data).blocked)return reply('الحساب موقوف.',403);
  if(created)try{await notifyOwner('مسجل جديد في ALKUNT',user.name+'\n'+user.email+'\nتم تأكيد البريد الإلكتروني.','registration-'+user.id)}catch{console.error('Registration notification delivery failed');}
  return Response.json({ok:true,returnTo:safeReturn(returnTo)},{headers:{...headers,'Set-Cookie':sessionCookie(createSession(user.id,3600),false,3600)}});
}
export async function POST(req:Request){try{
  if(!originAllowed(req))return reply('طلب غير مسموح / Invalid origin',403);
  if(Number(req.headers.get('content-length'))>16384)return reply('Request too large',413);
  let b:any;try{b=await req.json()}catch{return reply('Invalid request')}
  if(!b||typeof b!=='object'||Array.isArray(b))return reply('Invalid request');
  if(b.action==='logout'){const jar=await cookies();destroySession(jar.get(cookieName)?.value);return Response.json({ok:true},{headers:{...headers,'Set-Cookie':sessionCookie('',true)}})}
  if(b.action==='change-password'){
    const jar=await cookies(),identity=sessionUser(jar.get(cookieName)?.value);if(!identity)return reply('سجّل الدخول أولاً.',401);
    if(!limit('change-password:'+identity.userId,5))return reply('محاولات كثيرة. حاول لاحقاً.',429);
    const current=String(b.currentPassword||''),next=String(b.newPassword||'');if(!current||current.length>128||next.length<12||next.length>128)return reply('أدخل كلمة المرور الحالية، والجديدة من 12 إلى 128 حرفاً.');
    if(current===next)return reply('اختر كلمة مرور جديدة مختلفة.');
    const account:any=sql.prepare('SELECT * FROM accounts WHERE id=?').get(identity.userId),mapping=sql.prepare('SELECT supabase_id FROM supabase_accounts WHERE account_id=?').get(identity.userId) as any;
    if(mapping){const session=await supabaseRequest('token?grant_type=password',{email:account.email,password:current});const remote=await verifiedSupabaseUser(session.access_token);if(remote.id!==mapping.supabase_id)return reply('بيانات الحساب غير متطابقة.',403);await supabaseRequest('user',{password:next},session.access_token,'PUT');}
    else{if(!await passwordMatches(current,account.password))return reply('كلمة المرور الحالية غير صحيحة.',401);const hash=await passwordHash(next);sql.prepare('UPDATE accounts SET password=? WHERE id=?').run(hash,identity.userId);}
    sql.prepare('DELETE FROM sessions WHERE user=?').run(identity.userId);sql.prepare('DELETE FROM password_resets WHERE user=?').run(identity.userId);recordPasswordChange(identity.userId);
    return Response.json({ok:true,message:'تم تغيير كلمة المرور. أُغلقت الجلسات السابقة.'},{headers:{...headers,'Set-Cookie':sessionCookie(createSession(identity.userId,mapping?3600:7*86400),false,mapping?3600:7*86400)}});
  }
  if(b.action==='reset-password'){
    if(!limit('reset-password:global',100))return reply('محاولات كثيرة. حاول لاحقاً.',429);
    const next=String(b.password||'');if(next.length<12||next.length>128)return reply('كلمة المرور الجديدة من 12 إلى 128 حرفاً.');
    if(b.recoveryAccessToken||b.recoveryTokenHash){let token=b.recoveryAccessToken;if(b.recoveryTokenHash){if(typeof b.recoveryTokenHash!=='string'||!/^[a-f0-9]{40,128}$/i.test(b.recoveryTokenHash))return reply('رابط غير صالح.');token=(await supabaseRequest('verify',{token_hash:b.recoveryTokenHash,type:'recovery'})).access_token;}const remote=await verifiedSupabaseUser(token);const map=sql.prepare('SELECT account_id FROM supabase_accounts WHERE supabase_id=?').get(remote.id) as any;if(!map)return reply('حساب الاستعادة غير مرتبط.',403);await supabaseRequest('user',{password:next},token,'PUT');sql.prepare('DELETE FROM sessions WHERE user=?').run(map.account_id);recordPasswordChange(map.account_id);}
    else if(!await resetLocalPassword(b.token,next))return reply('رابط الاستعادة منتهي أو سبق استخدامه. اطلب رابطاً جديداً.');
    return Response.json({ok:true},{headers:{...headers,'Set-Cookie':sessionCookie('',true)}});
  }
  if(['confirm-session','confirm-email'].includes(b.action)){
    if(!limit('confirmation:global',100))return reply('محاولات كثيرة. أعد المحاولة لاحقاً.',429);
    let accessToken=b.accessToken;
    if(b.action==='confirm-email'){
      if(typeof b.tokenHash!=='string'||!/^[a-f0-9]{40,128}$/i.test(b.tokenHash))return reply('رابط التأكيد غير صالح.');
      const session=await supabaseRequest('verify',{token_hash:b.tokenHash,type:'email'});accessToken=session.access_token;
    }
    return await finishRemote(accessToken,b.returnTo);
  }
  const email=String(b.email||'').trim().toLowerCase(),password=String(b.password||''),name=b.firstName||b.lastName?[String(b.firstName||'').trim(),String(b.lastName||'').trim()].join(' '):String(b.name||'').trim();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)return reply('أدخل بريداً إلكترونياً صحيحاً.');
  if(!limit('auth:'+email)||!limit('auth:global',100))return reply('محاولات كثيرة. أعد المحاولة بعد 15 دقيقة.',429);
  let user:any=sql.prepare('SELECT * FROM accounts WHERE lower(email)=?').get(email);
  if(b.action==='forgot-password'){
    if(!limit('forgot:'+email,3))return reply('انتظر قبل طلب رسالة استعادة أخرى.',429);
    if(!mailConfigured())return reply('خدمة إرسال روابط الاستعادة غير مهيأة بعد. حاول لاحقاً.',503);
    const mapping=user&&sql.prepare('SELECT supabase_id FROM supabase_accounts WHERE account_id=?').get(user.id);
    try{if(mapping)await supabaseRequest('recover?redirect_to='+encodeURIComponent(new URL('/auth/recovery',process.env.APP_ORIGIN).href),{email});else if(user)await requestLocalReset(user);}catch{console.error('Recovery email delivery failed');}
    return Response.json({ok:true,message:'إذا كان البريد مسجلاً، فستصلك رسالة لإعادة ضبط كلمة المرور. تحقق من البريد غير المرغوب فيه.'},{headers});
  }
  if(b.action==='resend-confirmation'){
    if(!limit('resend:'+email,3))return reply('انتظر قبل طلب رسالة أخرى.',429);
    if(email!==ownerEmail&&!user)await resendSupabase(email);
    return Response.json({ok:true,message:'إذا كان لديك طلب تسجيل غير مؤكد فستصلك رسالة تأكيد. تحقق من البريد غير المرغوب فيه.'},{headers});
  }
  if(!['register','login'].includes(b.action))return reply('Unknown action');
  if(password.length<(b.action==='register'?12:1)||password.length>128)return reply('الحساب الجديد يتطلب كلمة مرور من 12 إلى 128 حرفاً.');
  if(b.action==='register'){
    const details:any={};for(const key of ['firstName','lastName','country','callingCode','phone'])details[key]=String(b[key]||'').trim();
    details.phone=details.phone.replace(/[٠-٩]/g,(c:string)=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,(c:string)=>String(c.charCodeAt(0)-1776)).replace(/[ ()-]/g,'');
    if(!details.firstName||details.firstName.length>60||!details.lastName||details.lastName.length>60||!details.country||details.country.length>80||!/^\+[1-9][0-9]{0,3}$/.test(details.callingCode)||!/^\d{4,14}$/.test(details.phone)||(details.callingCode+details.phone).length>16)return reply('أكمل الاسم الأول والثاني والبلد ورقم الهاتف مع مفتاح البلد بشكل صحيح.');
    if(email===ownerEmail||user)return reply('هذا البريد مرتبط بحساب. استخدم تسجيل الدخول.');
    if(!name||name.length>120)return reply('الاسم مطلوب، بحد أقصى 120 حرفاً.');
    if(supabaseEnabled())return Response.json(await signupSupabase(email,password,name,details),{headers});
    const hash=await passwordHash(password);user={id:randomUUID(),email,name};
    try{sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run(user.id,email,name,hash);const profile=sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id) as any;sql.prepare('UPDATE records SET data=? WHERE id=?').run(JSON.stringify({...JSON.parse(profile.data),...details}),'profile:'+user.id)}catch{return reply('تعذر إنشاء الحساب.');}
  }else{
    const linked=user&&sql.prepare('SELECT supabase_id FROM supabase_accounts WHERE account_id=?').get(user.id);
    // Existing, unmapped accounts (especially the owner) always retain local credentials and IDs.
    if(email!==ownerEmail&&supabaseEnabled()&&(!user||linked)){
      const session=await supabaseRequest('token?grant_type=password',{email,password});
      return await finishRemote(session.access_token,b.returnTo);
    }
    const dummy='00000000000000000000000000000000:'+('00'.repeat(64));
    if(linked||!await passwordMatches(password,user?.password||dummy)||!user)return reply('بيانات الدخول غير صحيحة.',401);
  }
  const profile:any=sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id);
  if(profile&&JSON.parse(profile.data).blocked)return reply('الحساب موقوف.',403);
  return Response.json({ok:true,returnTo:safeReturn(b.returnTo)},{headers:{...headers,'Set-Cookie':sessionCookie(createSession(user.id))}});
}catch(error){if(error instanceof AuthServiceError)return reply(error.message,error.status);console.error('Authentication request failed');return reply('تعذر إتمام الطلب. حاول لاحقاً.',500);}}
