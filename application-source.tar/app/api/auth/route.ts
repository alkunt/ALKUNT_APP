import {randomUUID} from 'node:crypto';
import {sql} from '../../../server/runtime.mjs';
import {ownerEmail,originAllowed,passwordHash,passwordMatches,limit,createSession,sessionCookie,destroySession,cookieName,safeReturn} from '../../../server/auth.mjs';
import {cookies} from 'next/headers';
export const runtime='nodejs';
export async function POST(req:Request){
const reply=(error:string,status=400)=>Response.json({error},{status});
if(!originAllowed(req))return reply('طلب غير مسموح / Invalid origin',403);
if(Number(req.headers.get('content-length'))>16384)return reply('Request too large',413);
let b:any;try{b=await req.json()}catch{return reply('Invalid request')}
if(b.action==='logout'){const jar=await cookies();destroySession(jar.get(cookieName)?.value);return Response.json({ok:true},{headers:{'Set-Cookie':sessionCookie('',true),'Cache-Control':'no-store'}})}
const email=String(b.email||'').trim().toLowerCase(),password=String(b.password||''),name=String(b.name||'').trim();
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||password.length<12||password.length>128)return reply('أدخل بريدًا صحيحًا وكلمة مرور من 12 إلى 128 حرفًا.');
if(!limit('auth:'+email)||!limit('auth:global',100))return reply('محاولات كثيرة. أعد المحاولة بعد 15 دقيقة.',429);
let user=sql.prepare('SELECT * FROM accounts WHERE email=?').get(email) as any;
if(b.action==='register'){
if(email===ownerEmail||user)return reply('تعذر إنشاء الحساب بهذا البريد. استخدم تسجيل الدخول أو تواصل مع المالك.');
if(!name||name.length>120)return reply('الاسم مطلوب، بحد أقصى 120 حرفًا.');
const hash=await passwordHash(password);user={id:randomUUID(),email,name};try{sql.prepare('INSERT INTO accounts VALUES(?,?,?,?)').run(user.id,email,name,hash)}catch{return reply('تعذر إنشاء الحساب.')}
}else if(b.action==='login'){
// Always perform password work, including for unknown addresses.
const dummy='00000000000000000000000000000000:'+('00'.repeat(64));
if(!await passwordMatches(password,user?.password||dummy)||!user)return reply('بيانات الدخول غير صحيحة.',401);
}else return reply('Unknown action');
const profile=sql.prepare('SELECT data FROM records WHERE id=?').get('profile:'+user.id) as any;if(profile&&JSON.parse(profile.data).blocked)return reply('الحساب موقوف.',403);
return Response.json({ok:true,returnTo:safeReturn(b.returnTo)},{headers:{'Set-Cookie':sessionCookie(createSession(user.id)),'Cache-Control':'no-store'}});
}
