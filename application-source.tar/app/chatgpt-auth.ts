import {cookies} from 'next/headers';
import {redirect} from 'next/navigation';
import {sessionUser,cookieName,safeReturn} from '../server/auth.mjs';
export type ChatGPTUser={userId:string;email:string;displayName:string;fullName:string|null};
export async function getChatGPTUser():Promise<ChatGPTUser|null>{const jar=await cookies();return sessionUser(jar.get(cookieName)?.value) as ChatGPTUser|null}
export async function requireChatGPTUser(returnTo:string){const user=await getChatGPTUser();if(!user)redirect(chatGPTSignInPath(returnTo));return user}
export const chatGPTSignInPath=(returnTo:string)=>'/signin-with-chatgpt?return_to='+encodeURIComponent(safeReturn(returnTo));
export const chatGPTSignOutPath=()=>'/signout-with-chatgpt';
