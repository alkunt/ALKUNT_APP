export default function PolicyContent({text, language}:{text:string;language:string}) {
  const inline = (value:string) => value.split(/(https:\/\/gumroad\.com\/privacy)/g).map((part, index) =>
    part === 'https://gumroad.com/privacy' ? <a key={index} href={part} target="_blank" rel="noopener noreferrer">{part}</a> : part);
  return <div className="policy-content" lang={language} dir={language === 'en' ? 'ltr' : 'rtl'}>
    {text.split(/\n\s*\n/).map((block, index) => {
      const [heading, ...paragraphs] = block.split('\n');
      return /^\d+\.\s/.test(heading) && paragraphs.length
        ? <section key={index}><h2>{heading}</h2><p>{inline(paragraphs.join('\n'))}</p></section>
        : <p key={index}>{inline(block)}</p>;
    })}
  </div>;
}
