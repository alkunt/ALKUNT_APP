'use client';
import {useState} from 'react';
import {Mail, Copy, ZoomIn} from 'lucide-react';
import RichTextContent from './rich-text-content';
import {emailRegistrationRequest} from './offer-registration.mjs';
import {externalUrl} from './link-rules';

export default function OfferRegistration({product, ar, price}: {product:any; ar:boolean; price:string}) {
  const t = (arabic:string, english:string) => ar ? arabic : english;
  const [request, setRequest] = useState<any>(null), [error, setError] = useState(''), [copied, setCopied] = useState(false);
  const language = ar ? 'ar' : 'en';
  const coverHref = /^\/api\/files\?id=[a-f\d-]{36}$/i.test(product.cover || '') ? product.cover : externalUrl(product.cover);
  const coverImage = <img className="registration-offer-cover" src={product.cover} alt={t('غلاف الدورة', 'Course cover')}/>;
  return <section className="registration-offer" dir={ar ? 'rtl' : 'ltr'}>
    {product.cover && <figure className="registration-cover-frame">{coverHref ? <a className="registration-cover-link" href={coverHref} target="_blank" rel="noopener noreferrer" aria-label={t('عرض الغلاف بالحجم الكامل', 'View full-size cover')}>{coverImage}<span><ZoomIn size={17} aria-hidden="true"/>{t('عرض الغلاف بالحجم الكامل', 'View full-size cover')}</span></a> : coverImage}</figure>}
    <div className="registration-fee"><span>{t('رسوم الدورة', 'Course fee')}</span><strong>{price}</strong><small>{t('طلب تسجيل بالبريد؛ لا يُخصم مبلغ في هذه الصفحة.', 'Email registration request; this page does not take payment.')}</small></div>
    <RichTextContent document={product['bodyDoc_'+language] || product.bodyDoc_ar} text={product['body_'+language] || product.body_ar || ''}/>
    <form className="registration-form" aria-label={t('طلب التسجيل في الدورة بالبريد', 'Course registration by email')} onChange={()=>{setRequest(null);setCopied(false);setError('');}} onSubmit={event=>{
      event.preventDefault();
      const data = new FormData(event.currentTarget);
      try {setRequest(emailRegistrationRequest(product, Object.fromEntries(data), ar));setError('');} catch (e:any) {setError(e.message);}
    }}>
      <h3>{t('سجّل اهتمامك بالحضور', 'Request to attend')}</h3>
      <p>{t('أدخل بياناتك لتجهيز رسالة إلى الجهة المنظمة. أرسلها من تطبيق بريدك، وستصلك تفاصيل الحضور وطريقة السداد بردّ على طلبك. إرسال الطلب لا يؤكد حجز المقعد.', 'Prepare an email to the organizer, then send it from your email app. Attendance and payment details follow by reply. A request does not confirm a seat.')}</p>
      <label>{t('الاسم الكامل', 'Full name')}<input name="name" autoComplete="name" required maxLength={120}/></label>
      <label>{t('البريد الإلكتروني لاستقبال التفاصيل', 'Email for attendance details')}<input name="email" type="email" dir="ltr" autoComplete="email" required maxLength={254}/></label>
      <label>{t('رقم التواصل مع مفتاح الدولة', 'Phone including country code')}<input name="phone" type="tel" dir="ltr" autoComplete="tel" required pattern="[+0-9 ()-]{8,25}" maxLength={25} placeholder="+965 …"/></label>
      <small>{t('تُستخدم هذه البيانات لمتابعة طلب الدورة. لا تُحفظ في الموقع عند تجهيز الرسالة ولا تُضاف إلى الجمهور التسويقي.', 'These details are for this course request. Preparing the email does not save them on the site or subscribe you to marketing.')}</small>
      <button className="primary" type="submit"><Mail size={18}/>{t('تجهيز طلب التسجيل بالبريد', 'Prepare registration email')}</button>
      {error && <p role="alert">{error}</p>}
    </form>
    {request && <div className="registration-email-ready" role="status">
      <h3>{t('رسالتك جاهزة للإرسال', 'Your email is ready')}</h3>
      <p>{t('لم يُرسل الطلب بعد. افتح الرسالة وأرسلها بنفسك إلى:', 'The request has not been sent. Open the email and send it to:')} <b dir="ltr">{request.recipient}</b></p>
      <a className="primary" href={request.href}><Mail size={18}/>{t('فتح الرسالة في تطبيق البريد', 'Open in your email app')}</a>
      <details><summary>{t('عرض نص الطلب أو نسخه', 'View or copy the request')}</summary><p className="registration-request-text">{request.body}</p><button className="secondary" type="button" onClick={async()=>{try{await navigator.clipboard.writeText(request.subject+'\n\n'+request.body);setCopied(true);}catch{setError(t('يمكنك تحديد نص الطلب ونسخه يدويًا.', 'Select and copy the request manually.'));}}}><Copy size={16}/>{copied?t('تم نسخ النص', 'Text copied'):t('نسخ نص الطلب', 'Copy request text')}</button></details>
    </div>}
  </section>;
}
