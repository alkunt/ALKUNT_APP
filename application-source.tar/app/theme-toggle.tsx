'use client';

import {useEffect,useState} from 'react';
import {Moon,Sun} from 'lucide-react';
import {DEFAULT_THEME,resolveTheme,THEME_STORAGE_KEY,type Theme} from './theme';

export default function ThemeToggle({lang}:{lang:string}) {
  const [theme,setTheme] = useState<Theme>(DEFAULT_THEME);
  const dark = theme === 'dark';
  const label = lang === 'ar'
    ? (dark ? 'تفعيل المظهر النهاري' : 'تفعيل المظهر الداكن')
    : (dark ? 'Switch to light appearance' : 'Switch to dark appearance');

  function apply(next:Theme) {
    document.documentElement.dataset.theme = next;
    setTheme(next);
  }

  useEffect(()=>{
    try {
      apply(resolveTheme(localStorage.getItem(THEME_STORAGE_KEY)));
    } catch {
      apply(resolveTheme(document.documentElement.dataset.theme));
    }
    const sync = (event:StorageEvent)=>{
      if(event.key===THEME_STORAGE_KEY || event.key===null) {
        apply(resolveTheme(event.newValue));
      }
    };
    window.addEventListener('storage',sync);
    return ()=>window.removeEventListener('storage',sync);
  },[]);

  return <button type="button" className="theme-toggle" aria-label={label} title={label} onClick={()=>{
    const next = dark?'light':'dark';
    apply(next);
    try { localStorage.setItem(THEME_STORAGE_KEY,next); } catch { /* The choice still works for this visit. */ }
  }}>
    {dark?<Sun size={18} aria-hidden="true"/>:<Moon size={18} aria-hidden="true"/>}
    <span>{lang==='ar'?(dark?'نهاري':'داكن'):(dark?'Light':'Dark')}</span>
  </button>;
}
