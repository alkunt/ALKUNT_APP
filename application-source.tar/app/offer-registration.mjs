export function registrationEmail(value) {
  if (typeof value !== 'string') return '';
  const address = value.trim();
  return address.length <= 254 && /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}$/.test(address) ? address : '';
}

export function isEmailRegistrationOffer(product) {
  return product?.type === 'offer' && product.registrationMode === 'email' && !!registrationEmail(product.registrationEmail);
}

export function validateOfferRegistration(product) {
  if (!product.registrationMode || product.registrationMode === 'digital') {
    delete product.registrationEmail;
    return;
  }
  if (!isEmailRegistrationOffer(product)) throw Error('أدخل بريد تسجيل صالحًا لعرض التسجيل بالبريد.');
  if (product.file || product.lessons?.length || product.inBundle || product.externalUrl) {
    throw Error('عرض التسجيل بالبريد مستقل عن مرفقات البيع الرقمي والروابط الخارجية.');
  }
  product.registrationEmail = registrationEmail(product.registrationEmail);
}

export function emailRegistrationRequest(product, details, ar = true) {
  if (!isEmailRegistrationOffer(product)) throw Error('Registration is unavailable.');
  const name = String(details.name || '').trim(), email = registrationEmail(details.email);
  const phone = String(details.phone || '').trim();
  if (!name || name.length > 120 || /[\r\n\u0000-\u001f]/.test(name) || !email || !/^\+?[0-9 ()-]{8,25}$/.test(phone)) {
    throw Error(ar ? 'تحقق من الاسم والبريد ورقم التواصل مع مفتاح الدولة.' : 'Check your name, email and phone number including country code.');
  }
  const title = String(ar ? product.title_ar : product.title_en || product.title_ar).replace(/[\r\n\u0000-\u001f]/g, ' ').slice(0, 180);
  const subject = (ar ? 'طلب التسجيل — ' : 'Registration request — ') + title;
  const body = ar
    ? `أرغب في التسجيل في: ${title}\n\nالاسم الكامل: ${name}\nالبريد الإلكتروني: ${email}\nرقم التواصل: ${phone}\n\nيرجى تأكيد التسجيل وإرسال تفاصيل الحضور وطريقة سداد الرسوم إلى بريدي الإلكتروني.\nشكرًا لكم.`
    : `I would like to register for: ${title}\n\nFull name: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nPlease confirm registration and email the attendance details and payment instructions.\nThank you.`;
  const recipient = registrationEmail(product.registrationEmail);
  return {recipient, subject, body, href: 'mailto:' + encodeURIComponent(recipient) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body)};
}
