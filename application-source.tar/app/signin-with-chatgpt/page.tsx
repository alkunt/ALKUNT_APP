import AuthForm from '../auth-form';
export default function SignInPage(){return <AuthForm/>;}
