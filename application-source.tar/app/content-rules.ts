export const isPublished=(p:any)=>p.status==='published'&&(!p.publishAt||new Date(p.publishAt).getTime()<=Date.now());
export const isPublicContent=(p:any)=>isPublished(p)&&(['blog','prompt'].includes(p.type)&&!p.inBundle&&Number(p.price)===0);
export function publicProduct(p:any){return {...p,body_ar:'',body_en:'',extended_ar:'',extended_en:'',instructions_ar:'',instructions_en:'',file:'',lessons:(p.lessons||[]).map((l:any)=>({id:l.id,title_ar:l.title_ar,title_en:l.title_en,preview:l.preview,...l.preview?{video:l.video,file:l.file}:{}}))};}
