import {localizedText} from './localized-text.mjs';

// Cache identities contain only public catalog presentation, never article bodies or files.
export function contentCoverVersion(product, language = 'ar') {
  const value = JSON.stringify([product.id,product.type,localizedText(product,language),
    localizedText(product,language,'category'),product.cover || '',product.theme || 'blue']);
  let hash = 2166136261;
  for (let i=0;i<value.length;i++) hash = Math.imul(hash ^ value.charCodeAt(i),16777619);
  return 'cover2-' + (hash >>> 0).toString(36);
}

export function uploadedContentCover(product, origin) {
  if (!product.cover) return null;
  try {
    const image = new URL(String(product.cover),origin);
    if (image.username || image.password ||
        !(image.protocol==='https:' || image.protocol==='http:' && image.origin===origin)) return null;
    if (image.origin===origin && /^\/(?:alkunt-logo(?:-dark)?|icon-192|icon-512)\.png$/i.test(image.pathname)) return null;
    return image.href;
  } catch { return null; }
}

export function contentCoverUrl(product, language, origin) {
  const uploaded = uploadedContentCover(product,origin);
  if (uploaded) return uploaded;
  const image = new URL('/api/content-cover',origin);
  image.searchParams.set('item',product.id);
  if (language==='en') image.searchParams.set('lang','en');
  image.searchParams.set('v',contentCoverVersion(product,language));
  return image.href;
}
