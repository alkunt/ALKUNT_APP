export function localizedText(item, language = 'ar', field = 'title') {
  if (!item) return '';
  // The original Arabic category is stored without a language suffix.
  if (field === 'category') {
    return language === 'en'
      ? item.category_en || item.category || item.category_ar || ''
      : item.category_ar || item.category || item.category_en || '';
  }
  return item[field + '_' + language] || item[field + '_ar'] || item[field + '_en'] || item[field] || '';
}
