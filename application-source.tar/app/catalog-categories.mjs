const clean = value => typeof value === 'string'
  ? value.normalize('NFKC').replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '').replace(/\s+/g, ' ').trim()
  : '';

function categoryKey(value) {
  return clean(value).replace(/[\u0640\u064B-\u065F\u0670]/g, '').replace(/[أإآٱ]/g, 'ا').toLowerCase();
}

export function isCatalogView(view) {
  return ['blog', 'course', 'book', 'prompt', 'offers'].includes(view);
}

export function catalogItems(products, view, now = Date.now()) {
  return products.filter(product => view === 'offers'
    ? (product.type === 'offer' || Number(product.oldPrice) > Number(product.price))
      && (!product.offerEnd || Date.parse(product.offerEnd) > now)
    : product.type === view);
}

export function catalogCategory(product) {
  const ar = clean(product?.category_ar) || clean(product?.category);
  const en = clean(product?.category_en);
  const name = ar || en;
  const key = categoryKey(name);
  if (!name || key === 'تعلم وتطور' || key === 'learn & grow') {
    return {id:'category:general', ar:'تعلّم وتطوّر', en:'Learn & grow'};
  }
  if (/^ادوات .*الذكاء الاصطناعي(?: |$)/u.test(key)
    || /^(?:ai|artificial intelligence)(?: .+)? tools$/.test(key)) {
    return {id:'category:ai-tools', ar:'أدوات الذكاء الاصطناعي', en:'AI tools'};
  }
  return {id:'category:'+key, ar:name, en:en || name};
}

export function catalogCategories(products, view, now = Date.now()) {
  const groups = new Map();
  for (const product of catalogItems(products, view, now)) {
    const category = catalogCategory(product);
    const existing = groups.get(category.id);
    if (!existing) groups.set(category.id, category);
    else if (clean(product.category_en)) existing.en = category.en;
  }
  return [...groups.values()];
}

export function matchesCatalogCategory(product, selected) {
  return selected === 'all' || catalogCategory(product).id === selected;
}
