export function visibleInLibrary(p:any,owned:string[],manager:boolean){return manager||owned.includes(p.id)||(p.type==='prompt'&&owned.includes('prompt-bundle'));}
export function contentStatus(p:any){if(p.status==='published'&&p.publishAt&&new Date(p.publishAt).getTime()>Date.now())return 'scheduled';return p.status;}
