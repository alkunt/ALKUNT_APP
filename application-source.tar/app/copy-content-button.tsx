'use client';

import {createContext,useCallback,useContext,useEffect,useId,useRef,useState,type ReactNode} from 'react';
import {Copy,Download,Share2,X} from 'lucide-react';
import {contentShareData,canShareContentFile,shareContentFile,copyContentShareText} from './content-share.mjs';

type ShareData = {title:string;url:string;image:string;text:string;language:string};
type ShareRequest = {data:ShareData;trigger:HTMLButtonElement};
const ShareContext = createContext<((request:ShareRequest)=>void)|null>(null);

function coverPng(url:string):Promise<Blob> {
  return new Promise((resolve,reject)=>{
    const image = new Image();
    const timer = window.setTimeout(()=>reject(Error('Cover timed out')),12000);
    image.crossOrigin = 'anonymous';
    image.onload = ()=>{
      window.clearTimeout(timer);
      try {
        if (!image.naturalWidth || !image.naturalHeight) throw Error('Empty cover');
        const scale = Math.min(1,1600/Math.max(image.naturalWidth,image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1,Math.round(image.naturalWidth*scale));
        canvas.height = Math.max(1,Math.round(image.naturalHeight*scale));
        const context = canvas.getContext('2d');
        if (!context) throw Error('Canvas unavailable');
        context.drawImage(image,0,0,canvas.width,canvas.height);
        canvas.toBlob(blob=>blob ? resolve(blob) : reject(Error('Cover conversion failed')),'image/png');
      } catch (error) { reject(error); }
    };
    image.onerror = ()=>{window.clearTimeout(timer);reject(Error('Cover unavailable'));};
    image.src = url;
  });
}

// Host the dialog outside cards, which can remount on catalog and toast updates.
export function ContentShareProvider({children}:{children:ReactNode}) {
  const [request,setRequest] = useState<ShareRequest|null>(null);
  const openShare = useCallback((next:ShareRequest)=>setRequest(next),[]);
  function closeShare() {
    const previous = request;
    setRequest(null);
    window.setTimeout(()=>{
      const trigger = previous?.trigger.isConnected ? previous.trigger :
        [...document.querySelectorAll<HTMLButtonElement>('button[data-share-content]')].find(button=>button.dataset.shareContent===previous?.data.url);
      trigger?.focus();
    },0);
  }
  return <ShareContext.Provider value={openShare}>{children}{request&&<ContentShareDialog key={request.data.url} data={request.data} onClose={closeShare}/>}</ShareContext.Provider>;
}

function ContentShareDialog({data,onClose}:{data:ShareData;onClose:()=>void}) {
  const dialog = useRef<HTMLDialogElement>(null),caption = useRef<HTMLTextAreaElement>(null);
  const headingId = useId(),helpId = useId();
  const [file,setFile] = useState<File|null>(null),[preparing,setPreparing] = useState(true);
  const [coverError,setCoverError] = useState(false);
  const [copying,setCopying] = useState(false),[sharing,setSharing] = useState(false),[downloading,setDownloading] = useState(false),[message,setMessage] = useState('');
  const t = (ar:string,en:string)=>data.language==='ar'?ar:en;
  const nativeSharing = typeof navigator!=='undefined' && typeof navigator.share==='function';
  const canShareFile = !!file && canShareContentFile(data,file,navigator);

  useEffect(()=>{
    if (dialog.current && !dialog.current.open) dialog.current.showModal();
    let cancelled = false;
    coverPng(data.image).then(blob=>{
      if (!cancelled) setFile(new File([blob],'ALKUNT-cover.png',{type:'image/png'}));
    }).catch(()=>{if (!cancelled) setCoverError(true);}).finally(()=>{if (!cancelled) setPreparing(false);});
    return ()=>{cancelled=true;};
  },[data.image]);

  async function copyCaption() {
    setCopying(true);
    try {
      await copyContentShareText(data,navigator.clipboard);
      setMessage(t('تم نسخ العنوان والرابط. الصقهما في رسالتك لتظهر معاينة الغلاف في التطبيقات الداعمة.','Title and link copied. Paste them into your message for a cover preview in supported apps.'));
    } catch {
      caption.current?.focus();caption.current?.select();
      setMessage(t('نص المشاركة محدد أدناه. انسخه يدويًا ليبقى العنوان والرابط معًا.','The share text is selected below. Copy it manually to keep the title and link together.'));
    } finally {setCopying(false);}
  }

  async function shareCover() {
    if (!file || sharing) return;
    setSharing(true);
    try {
      await shareContentFile(data,file,navigator);
      setMessage(t('سُلّم الغلاف والنص إلى قائمة المشاركة. راجع التعليق في التطبيق قبل الإرسال.','Cover and text handed to sharing. Check the caption in your chosen app before sending.'));
    } catch (error:any) {
      setMessage(error?.name==='AbortError' ? t('أُغلقت نافذة المشاركة.','The share window was closed.') :
        t('تعذّر فتح المشاركة. انسخ العنوان والرابط واحفظ الغلاف لإرفاقه مع النص.','Sharing could not open. Copy the title and link, then save the cover to attach it with the text.'));
    } finally {setSharing(false);}
  }

  async function downloadCover() {
    setDownloading(true);
    try {
      const blob = file || await coverPng(data.image),url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href=url;anchor.download='ALKUNT-cover.png';
      document.body.append(anchor);anchor.click();anchor.remove();
      window.setTimeout(()=>URL.revokeObjectURL(url),10000);
      setMessage(t('جُهّز الغلاف للتنزيل. أرفقه مع نص المشاركة الظاهر أدناه.','Cover prepared for download. Attach it with the share text shown below.'));
    } catch {
      setCoverError(true);
      setMessage(t('تعذّر تنزيل الغلاف. افتح صورته من المعاينة واحفظها، ثم أرفق نص المشاركة.','Cover download failed. Open the preview image to save it, then include the share text.'));
    } finally {setDownloading(false);}
  }

  return <dialog ref={dialog} role="dialog" className="content-share-dialog" aria-labelledby={headingId} aria-describedby={helpId} dir={data.language==='ar'?'rtl':'ltr'} onCancel={event=>{event.preventDefault();onClose();}}>
    <div className="content-share-heading"><h2 id={headingId}>{t('مشاركة البطاقة','Share card')}</h2><button type="button" className="small-btn" aria-label={t('إغلاق','Close')} onClick={onClose}><X size={19}/></button></div>
    <p id={helpId}>{t('شارك العنوان والرابط مع معاينة الغلاف، أو أرفق الغلاف مع نص المشاركة.','Share the title and link with a cover preview, or attach the cover with the share text.')}</p>
    <a className="content-share-card" href={data.url} target="_blank" rel="noopener noreferrer" aria-label={t('فتح البطاقة: ','Open card: ')+data.title}>
      <img className="content-share-preview" src={data.image} alt=""/>
      <div><strong className="content-share-title">{data.title}</strong><span className="content-share-domain" dir="ltr">{new URL(data.url).hostname}</span></div>
    </a>
    <label className="content-share-caption">{t('نص المشاركة — العنوان والرابط','Share text — title and link')}<textarea ref={caption} readOnly rows={3} value={data.text} dir="auto" onFocus={event=>event.currentTarget.select()}/></label>
    <div className="content-share-buttons">
      <button type="button" className="primary" disabled={copying} onClick={copyCaption}><Copy size={16}/>{t('نسخ العنوان والرابط','Copy title and link')}</button>
      <a className="secondary" href={'https://wa.me/?text='+encodeURIComponent(data.text)} target="_blank" rel="noopener noreferrer">{t('مشاركة عبر واتساب','Share on WhatsApp')}</a>
      {nativeSharing&&(preparing||canShareFile)&&<button type="button" className="secondary" disabled={preparing||!canShareFile||sharing} onClick={shareCover}><Share2 size={16}/>{preparing?t('جارٍ تجهيز الغلاف…','Preparing cover…'):t('مشاركة الغلاف مع النص','Share cover with text')}</button>}
      <button type="button" className="small-btn" disabled={downloading} onClick={downloadCover}><Download size={16}/>{t('حفظ صورة الغلاف','Save cover image')}</button>
    </div>
    {coverError&&<a className="content-share-image-link" href={data.image} target="_blank" rel="noopener noreferrer">{t('فتح صورة الغلاف','Open cover image')}</a>}
    <p className="content-share-status" role="status" aria-live="polite">{message}</p>
  </dialog>;
}

type Props = {product:any;lang:string;origin?:string;notify:(message:string)=>void;className?:string;iconOnly?:boolean};
export default function CopyContentButton({product,lang,origin,className='secondary',iconOnly=false}:Props) {
  const openShare = useContext(ShareContext);
  const data = contentShareData(product,lang,origin);
  const label = lang==='ar'?'مشاركة البطاقة':'Share card';
  return <button type="button" className={className} aria-label={label} title={label} data-share-content={data.url} onClick={event=>openShare?.({data,trigger:event.currentTarget})}>
    <Share2 size={iconOnly?15:16} aria-hidden="true"/>{!iconOnly&&label}
  </button>;
}
