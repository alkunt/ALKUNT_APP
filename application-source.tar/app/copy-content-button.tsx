'use client';

import {useEffect,useId,useRef,useState} from 'react';
import {Copy,Download,X} from 'lucide-react';
import {contentShareData,contentShareHtml} from './content-share.mjs';

function coverPng(url:string):Promise<Blob> {
  return new Promise((resolve,reject)=>{
    const image = new Image();
    const timer = window.setTimeout(()=>reject(Error('Cover timed out')),12000);
    image.crossOrigin = 'anonymous';
    image.onload = ()=>{
      window.clearTimeout(timer);
      try {
        if (!image.naturalWidth || !image.naturalHeight) throw Error('Empty cover');
        const scale = Math.min(1,1600/Math.max(image.naturalWidth,image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1,Math.round(image.naturalWidth*scale));
        canvas.height = Math.max(1,Math.round(image.naturalHeight*scale));
        const context = canvas.getContext('2d');
        if (!context) throw Error('Canvas unavailable');
        context.drawImage(image,0,0,canvas.width,canvas.height);
        canvas.toBlob(blob=>blob ? resolve(blob) : reject(Error('Cover conversion failed')),'image/png');
      } catch (error) { reject(error); }
    };
    image.onerror = ()=>{window.clearTimeout(timer);reject(Error('Cover unavailable'));};
    image.src = url;
  });
}

function dataUrl(blob:Blob):Promise<string> {
  return new Promise((resolve,reject)=>{
    const reader = new FileReader();
    reader.onload = ()=>resolve(String(reader.result));
    reader.onerror = ()=>reject(Error('Cover unreadable'));
    reader.readAsDataURL(blob);
  });
}

type Props = {product:any;lang:string;origin?:string;notify:(message:string)=>void;className?:string;iconOnly?:boolean};

export default function CopyContentButton({product,lang,origin,notify,className='secondary',iconOnly=false}:Props) {
  const [busy,setBusy] = useState(false),[fallback,setFallback] = useState(false),[message,setMessage] = useState('');
  const [downloading,setDownloading] = useState(false);
  const dialog = useRef<HTMLDialogElement>(null),linkInput = useRef<HTMLInputElement>(null);
  const headingId = useId();
  const data = contentShareData(product,lang,origin);
  const t = (ar:string,en:string)=>lang==='ar'?ar:en;
  const label = t('نسخ الرابط والغلاف','Copy link and cover');

  useEffect(()=>{
    if (fallback && dialog.current && !dialog.current.open) dialog.current.showModal();
  },[fallback]);

  async function copyContent() {
    if (busy) return;
    setBusy(true);
    try {
      if (!navigator.clipboard?.write || typeof ClipboardItem==='undefined' ||
          typeof ClipboardItem.supports==='function' &&
          (!ClipboardItem.supports('image/png') || !ClipboardItem.supports('text/html'))) throw Error('Rich copy unavailable');
      const png = coverPng(data.image);
      const html = png.then(dataUrl).then(image=>new Blob([contentShareHtml(data,image)],{type:'text/html'}));
      // Promised representations let the write start within the user's click,
      // even when downloading or converting the cover takes a moment.
      void png.catch(()=>{}); void html.catch(()=>{});
      await navigator.clipboard.write([new ClipboardItem({
        'text/plain':new Blob([data.text],{type:'text/plain'}),
        'text/html':html,
        'image/png':png
      })]);
      notify(t('تم نسخ الغلاف والعنوان والرابط.','Cover, title and link copied.'));
    } catch {
      setMessage('');
      setFallback(true);
    } finally { setBusy(false); }
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(data.text);
      setMessage(t('تم نسخ العنوان والرابط. أرفق صورة الغلاف معهما.','Title and link copied. Attach the cover image with them.'));
    } catch {
      linkInput.current?.focus();linkInput.current?.select();
      setMessage(t('حدّد الرابط وانسخه من الحقل أدناه.','Select and copy the link from the field below.'));
    }
  }

  async function downloadCover() {
    setDownloading(true);
    try {
      const blob = await coverPng(data.image),url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;anchor.download = 'ALKUNT-cover.png';
      document.body.append(anchor);anchor.click();anchor.remove();
      window.setTimeout(()=>URL.revokeObjectURL(url),10000);
      setMessage(t('جُهّز الغلاف للتنزيل. انسخ الرابط وأرفقه معه.','Cover prepared for download. Copy the link and include it with the image.'));
    } catch {
      setMessage(t('تعذّر تنزيل الغلاف. يمكنك فتح الصورة وحفظها من الرابط أدناه.','Cover download failed. Open the image below to save it.'));
    } finally { setDownloading(false); }
  }

  return <>
    <button type="button" className={className} aria-label={label} title={label} aria-busy={busy} disabled={busy} onClick={copyContent}>
      <Copy size={iconOnly?15:16} aria-hidden="true"/>{!iconOnly&&label}
    </button>
    {fallback&&<dialog ref={dialog} className="content-share-dialog" aria-labelledby={headingId} dir={lang==='ar'?'rtl':'ltr'} onCancel={()=>setFallback(false)} onClose={()=>setFallback(false)}>
      <div className="content-share-heading"><h2 id={headingId}>{t('مشاركة الغلاف والرابط','Share the cover and link')}</h2><button type="button" className="small-btn" aria-label={t('إغلاق','Close')} onClick={()=>setFallback(false)}><X size={19}/></button></div>
      <p>{t('تعذّر نسخهما معًا في هذا المتصفح. احفظ الغلاف وانسخ الرابط لإرفاقهما في رسالتك.','This browser could not copy both together. Save the cover and copy the link to include them in your message.')}</p>
      <img className="content-share-preview" src={data.image} alt={data.title}/>
      <strong className="content-share-title">{data.title}</strong>
      <label className="content-share-link">{t('رابط المحتوى','Content link')}<input ref={linkInput} readOnly value={data.url} dir="ltr" onFocus={event=>event.currentTarget.select()}/></label>
      <div className="content-share-buttons"><button type="button" className="primary" onClick={copyLink}><Copy size={16}/>{t('نسخ العنوان والرابط','Copy title and link')}</button><button type="button" className="secondary" disabled={downloading} onClick={downloadCover}><Download size={16}/>{t('حفظ صورة الغلاف','Save cover image')}</button></div>
      <a href={data.image} target="_blank" rel="noopener noreferrer">{t('فتح صورة الغلاف','Open cover image')}</a>
      <p className="content-share-status" role="status" aria-live="polite">{message}</p>
    </dialog>}
  </>;
}
