'use client';
import {useEffect} from 'react';
import {buildPageMetadata} from './page-metadata.mjs';

export default function DocumentMetadata({view, item, product, language, origin, loading}:any) {
  useEffect(() => {
    if (loading) return;
    const metadata = buildPageMetadata({view, item, lang: language}, product, {origin});
    document.title = metadata.title;
    const meta = (attribute:string, key:string, content:string) => {
      const nodes = Array.from(document.querySelectorAll<HTMLMetaElement>(`meta[${attribute}="${key}"]`));
      const element = nodes.shift() || document.createElement('meta');
      element.setAttribute(attribute, key);
      element.content = content;
      if (!element.isConnected) document.head.append(element);
      nodes.forEach(node => node.remove());
    };
    const canonicals = Array.from(document.querySelectorAll<HTMLLinkElement>('link[rel="canonical"]'));
    const canonical = canonicals.shift() || document.createElement('link');
    canonical.rel = 'canonical';
    canonical.href = metadata.alternates.canonical;
    if (!canonical.isConnected) document.head.append(canonical);
    canonicals.forEach(node => node.remove());
    meta('name', 'description', metadata.description);
    meta('name', 'robots', metadata.robots.index ? 'index, follow' : 'noindex, nofollow');
    for (const [name, value] of Object.entries({title: metadata.title, description: metadata.description,
      url: metadata.alternates.canonical, type: metadata.openGraph.type, locale: metadata.openGraph.locale,
      image: metadata.openGraph.images[0].url, 'image:alt': metadata.openGraph.images[0].alt})) {
      meta('property', 'og:' + name, value);
    }
    for (const [name, value] of Object.entries({card: 'summary_large_image', title: metadata.title,
      description: metadata.description, image: metadata.twitter.images[0]})) meta('name', 'twitter:' + name, value);
  }, [view, item, product, language, origin, loading]);
  return null;
}
