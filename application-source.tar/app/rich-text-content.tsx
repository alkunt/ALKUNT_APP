import {normalizeRichDoc,richDocHtml} from './rich-text.mjs';
export default function RichTextContent({document,text='',className=''}:{document?:any;text?:string;className?:string}){
 let html='';try{if(document)html=richDocHtml(normalizeRichDoc(document));}catch{}
 return html?<div className={'rich-text-content '+className} dir="auto" dangerouslySetInnerHTML={{__html:html}}/>:<div className={'rich-text-content '+className} dir="auto">{text.split(/\n\s*\n/).map((p,i)=><p key={i}>{p}</p>)}</div>;
}
